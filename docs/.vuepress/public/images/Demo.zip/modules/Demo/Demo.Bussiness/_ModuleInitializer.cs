﻿namespace Demo.Bussiness
{
    using Config.Core.Consts;
    using Data.AspNetCore;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Hosting;
    using Module.AspNetCore;
    using System;
    using System.Collections.Generic;
    using System.Reflection;

    public class ModuleInitializer : IModuleInitializer
    {
        public void ConfigureServices(IServiceCollection services, IHostEnvironment env)
        {
            //数据库
            //添加数据配置,登录信息,基础服务,仓储层
            List<ConnectionBase> connections = new List<ConnectionBase>
            {
               new ConnectionBase{
                ConfigId=0,
                ConnectionString="Data Source=10.1.0.131;Initial Catalog=SAAS_HR2;Persist Security Info=True;User ID=sa;password=90-=op[]"
               },
                new ConnectionBase{
                ConfigId=1,
                ConnectionString="Data Source=10.1.0.131;Initial Catalog=SAAS;Persist Security Info=True;User ID=sa;password=90-=op[]"
               }
            };
            services.AddDataConfig(env, connections);

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("执行ConfigureServices");
            Console.ForegroundColor = ConsoleColor.White;
        }


        public void Configure(IApplicationBuilder app, IHostEnvironment env)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("执行Configure");
            Console.ForegroundColor = ConsoleColor.White;
        }


    }
}
