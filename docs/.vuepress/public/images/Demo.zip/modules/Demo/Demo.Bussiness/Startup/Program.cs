﻿namespace Demo.Bussiness
{
    using Host.Web;

    public class Program
    {
        public static void Main(string[] args)
        {
            new HostBootstrap(args).Run<Startup>();
        }
    }
}
