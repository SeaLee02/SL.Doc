﻿namespace Demo.Student.Controllers
{
    using Auth.Web;
    using Config.Core.Consts;
    using Demo.Core.Application.Student;
    using Demo.Core.Application.Student.Dto;
    using Microsoft.AspNetCore.Mvc;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Utils.Core;
    using Microsoft.AspNetCore.Http;


    [Description("学生表管理")]
    public class StudentController : ControllersAbstract
    {
        private readonly IStudentService _service;
        public StudentController(IStudentService service)
        {
            _service = service;
        }

        /// <summary>
        /// 列表
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPatch]
        public async Task<IResultModel> GetList(StudentQueryDto dto)
        {
            return await _service.GetList(dto);
        }

        /// <summary>
        ///  查询单条数据
        /// </summary>
        /// <param name="PostId">公司编号</param>
        /// <returns></returns>
        [HttpPost("{primaryKey}")]
        public async Task<IResultModel> GetViewById(Guid? primaryKey)
        {
            return await this._service.GetViewById(primaryKey);
        }

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPatch]
        public async Task<IResultModel> Add(StudentAddDto dto)
        {

            return await _service.Add(dto);
        }

        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPatch]
        public async Task<IResultModel> Update(StudentAddDto dto)
        {

            return await _service.Update(dto);
        }


        /// <summary>
        /// 删除
        /// </summary>
        /// <returns></returns>
        [HttpPost("{primaryKey}")]
        public async Task<IResultModel> Del(Guid primaryKey)
        {
            return await _service.Del(primaryKey);
        }

          /// <summary>
        /// 导出文件
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPatch]
        public async Task<FileContentResult> ExportExcel(StudentQueryDto dto)
        {
            var buff = await _service.ExportExcel(dto);
            FileContentResult returnFile = new FileContentResult(buff, AppConfigConsts.Excel);
            returnFile.FileDownloadName = "学生表.xlsx";
            return returnFile;
        }

        /// <summary>
        /// 导入数据
        /// </summary>
        /// <param name="formFile"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IResultModel> ImportExcel(IFormFile formFile)
        {
            return await _service.ImportExcel(formFile);
        }



    }
}
