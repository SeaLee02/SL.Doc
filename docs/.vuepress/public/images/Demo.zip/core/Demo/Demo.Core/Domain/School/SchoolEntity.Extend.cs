﻿namespace Demo.Core.Domain.School
{
  using SqlSugar;
  using System;

/// <summary>
/// 学校
/// </summary>
 public partial class SchoolEntity
 {


  }

}