﻿namespace Demo.Core.Application.School2Student
{
    using Data.Abstractions.Repository;
    using Data.AspNetCore.Services;
    using Demo.Core.Application.School2Student.Dto;
    using Demo.Core.Domain.School2Student;
    using SqlSugar;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Dynamic;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Text;
    using System.Threading.Tasks;
    using Utils.Core;
    using Utils.Core.Entity;
    using Utils.Core.Map;
    using Auth.AspectCore.UnitWork;
    using Excel.Aspose;
    using Microsoft.AspNetCore.Http;
    using System.IO;
    using Utils.Core.Helper;
    using Utils.Core.DataModel;

    /// <summary>
    /// 学校和学生关系
    /// </summary>
    public class School2StudentService :ISchool2StudentService
    {
        private readonly ISchool2StudentRepository _school2StudentRepository;
        private readonly IObjectMapper _mapper;
        public School2StudentService(ISchool2StudentRepository school2StudentRepository, IObjectMapper mapper)
        {
            this._school2StudentRepository = school2StudentRepository;
            this._mapper = mapper;
        }

        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<IResultModel> GetList(School2StudentQueryDto dto)
        {
            Expression<Func<School2StudentEntity, bool>> whereExpression = x => 1 == 1;
            //whereExpression = whereExpression.And(x => x.AAA == dto.AAA, dto.AAA.NotNull());
            //01直接走实体映射
            var result = await  this._school2StudentRepository.QueryPage(dto, whereExpression);
            PageModel<School2StudentListDto> resultDto= _mapper.Map<PageModel<School2StudentListDto>>(result);
            //02或者使用select,不需要mapper
            //var result = await  this._rankRepository.QueryPage(dto, whereExpression,selectExpression:(a)=>new RankListDto {             
            //});
            return ResultModel.Success(resultDto);
        }


        /// <summary>
        /// 导出
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<byte[]> ExportExcel(School2StudentQueryDto dto)
        {
           byte[] buff = null;
            dto.PageSize = 999999;
            dto.PageIndex = 1;
            ResultModel<PageModel<School2StudentListDto>> _cdata = (ResultModel<PageModel<School2StudentListDto>>)await this.GetList(dto);
            if (_cdata != null)
            {
                if (_cdata.Data != null)
                {
                    var date = _mapper.Map<List<School2StudentExportDto>>(_cdata.Data.Data);
                    buff = ExcelHelper.GetExcelForList(date);
                }
            }
            return buff;
        }


          /// <summary>
        /// 导入
        /// </summary>
        /// <param name="formFile"></param>
        /// <returns></returns>
        [TransactionInterceptor]
        public async Task<IResultModel> ImportExcel(IFormFile formFile)
        {
            DataTable dt = new DataTable();
            List<School2StudentImportDto> data = new List<School2StudentImportDto>();
            try
            {
                using MemoryStream stream = new MemoryStream();
                await formFile.CopyToAsync(stream);
                dt = ExcelHelper.Excel2Table(stream);
                dt.ReplaceColumnName<School2StudentImportDto>();
                data = dt.Mapper<School2StudentImportDto>(true);
            }
            catch (Exception ex)
            {
                throw new Exception($"请上传正确的模板数据");
            }
           
            //验证必填问题
            var _va = data.ValidationNotNull();
            if (!_va.isOk)
            {
                return ResultModel.Failed(_va.errorMsg);
            }

            var result = _mapper.Map<List<School2StudentEntity>>(data);
            await this._school2StudentRepository.Add(result);
            return ResultModel.Success($"导入成功数据: {data.Count} ");
        }

        /// <summary>
        /// 获取详情
        /// </summary>
        /// <param name="primaryKey"></param>
        /// <returns></returns>
        public async Task<IResultModel> GetViewById(Guid? primaryKey)
        {
            var view = await this._school2StudentRepository.QueryById(primaryKey);
            var result= _mapper.Map<School2StudentDto>(view);
            return ResultModel.Success(result);
        }

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<IResultModel> Add(School2StudentAddDto dto)
        {
            var entity = _mapper.Map<School2StudentEntity>(dto);
            entity.SchoolId = Guid.NewGuid();          
            await  this._school2StudentRepository.Add(entity);
            return ResultModel.Success("添加成功");
        }

        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<IResultModel> Update(School2StudentAddDto dto)
        {
             var entity = await _school2StudentRepository.QueryById(dto.SchoolId);
            _mapper.Map(dto, entity);
            await this._school2StudentRepository.Update(entity);
            return ResultModel.Success("更新成功");
        }

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="primaryKey"></param>
        /// <returns></returns>
        public async Task<IResultModel> Del(Guid primaryKey)
        {
            await  this._school2StudentRepository.SoftDeleteById(primaryKey);
            return ResultModel.Success("删除成功");
        }



    }
}
