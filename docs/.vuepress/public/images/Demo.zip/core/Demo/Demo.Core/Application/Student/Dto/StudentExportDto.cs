﻿namespace Demo.Core.Application.Student.Dto
{
    using SqlSugar;
    using System;
    using System.ComponentModel.DataAnnotations;
    using Utils.Core;
    using Utils.Core.Entity;
    using Utils.Core.Annotations;
    using Demo.Core.Domain.Student;
    using Excel.Aspose.Annotations;

    /// <summary>
    /// 学生表
    /// </summary>
    [ImporterHeader("学生表")]
    public  class StudentExportDto
    {

		      
        /// <summary>
		/// 学生姓名
		/// </summary>	
		[ImporterHeader("学生姓名")]
        public string StudentName { get; set; }
		      
        /// <summary>
		/// 年龄
		/// </summary>	
		[ImporterHeader("年龄")]
        public int StudentAge { get; set; }
		      
        /// <summary>
		/// 备注
		/// </summary>	
		[ImporterHeader("备注")]
        public string Remark { get; set; }
		      
		      
        /// <summary>
		/// 创建时间
		/// </summary>	
		[ImporterHeader("创建时间")]
        public DateTime CreateTime { get; set; }
		      
		      
        /// <summary>
		/// 创建用户
		/// </summary>	
		[ImporterHeader("创建用户")]
        public string CreateUser { get; set; }
		      
        /// <summary>
		/// 更新时间
		/// </summary>	
		[ImporterHeader("更新时间")]
        public DateTime LastUpTime { get; set; }
		      
        /// <summary>
		/// 更新用户
		/// </summary>	
		[ImporterHeader("更新用户")]
        public string LastUpUser { get; set; }
		      
    }
}