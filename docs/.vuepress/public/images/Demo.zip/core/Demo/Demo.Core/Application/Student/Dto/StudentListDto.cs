﻿namespace Demo.Core.Application.Student.Dto
{
    using SqlSugar;
    using System;
    using System.ComponentModel.DataAnnotations;
    using Utils.Core;
    using Utils.Core.Entity;
    using Utils.Core.Annotations;
    using Demo.Core.Domain.Student;

    /// <summary>
    /// 学生表
    /// </summary>
    public  class StudentListDto:EntityBase
    {

	    /// <summary>
	    /// 主键
	    /// </summary>		
	    public Guid StudentId { get; set; }
	          
	    /// <summary>
	    /// 学生姓名
	    /// </summary>		
	    public string StudentName { get; set; }
	          
	    /// <summary>
	    /// 年龄
	    /// </summary>		
	    public int StudentAge { get; set; }

        /// <summary>
        /// 学校名称
        /// </summary>	
        public string SchoolName { get; set; }

    }

}