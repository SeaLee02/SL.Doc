﻿namespace Demo.Core.Application.School2Student.Dto
{
    using SqlSugar;
    using System;
    using System.ComponentModel.DataAnnotations;
    using Utils.Core;
    using Utils.Core.Entity;
    using Utils.Core.Annotations;
    using Demo.Core.Domain.School2Student;

    /// <summary>
    /// 学校和学生关系
    /// </summary>
    public  class School2StudentImportDto
    {

		      
		      
    }
}

