﻿
namespace Demo.Core.Domain.Student
{
    using SqlSugar;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Utils.Core;

    /// <summary>
    /// 学生表
    /// </summary>
    [SugarTable("Demo_Student")]
    [TenantAttribute(1)]
    public partial class StudentEntity : EntityBase
    {

        /// <summary>
        /// 主键
        /// </summary>	
        [SugarColumn(IsPrimaryKey = true)]
        public Guid StudentId { get; set; }

        /// <summary>
        /// 学生姓名
        /// </summary>	
        public string StudentName { get; set; }

        /// <summary>
        /// 年龄
        /// </summary>	
        public int StudentAge { get; set; }



    }


}