﻿
namespace Demo.Core.Domain.School
{
    using SqlSugar;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Utils.Core;

    /// <summary>
    /// 学校
    /// </summary>
    [SugarTable("Demo_School")]
    public partial class SchoolEntity : EntityBase
    {

        /// <summary>
        /// 主键
        /// </summary>	
        [SugarColumn(IsPrimaryKey = true)]
        public Guid SchoolId { get; set; }

        /// <summary>
        /// 学校名称
        /// </summary>	
        public string SchoolName { get; set; }

    }


}