﻿namespace Demo.Core.Application.Student
{
    using Data.Abstractions.Repository;
    using Data.AspNetCore.Services;
    using Demo.Core.Application.Student.Dto;
    using Demo.Core.Domain.Student;
    using SqlSugar;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Dynamic;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Text;
    using System.Threading.Tasks;
    using Utils.Core;
    using Utils.Core.Entity;
    using Utils.Core.Map;
    using Auth.AspectCore.UnitWork;
    using Excel.Aspose;
    using Microsoft.AspNetCore.Http;
    using System.IO;
    using Utils.Core.Helper;
    using Utils.Core.DataModel;
    using Demo.Core.Domain.School2Student;
    using Demo.Core.Domain.School;
    using SqlSugar.Extensions;

    /// <summary>
    /// 学生表
    /// </summary>
    public class StudentService : IStudentService
    {
        private readonly IStudentRepository _studentRepository;
        private readonly IObjectMapper _mapper;

        private readonly ISchool2StudentRepository _school2StudentRepository;
        private readonly ISchoolRepository _schoolRepository;

        public StudentService(IStudentRepository studentRepository, IObjectMapper mapper, ISchool2StudentRepository school2StudentRepository, ISchoolRepository schoolRepository)
        {
            this._studentRepository = studentRepository;
            this._mapper = mapper;
            this._school2StudentRepository = school2StudentRepository;
            this._schoolRepository = schoolRepository;
        }

        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<IResultModel> GetList(StudentQueryDto dto)
        {
            //跨库查询,不跨库的时候使用封装的分页
            RefAsync<int> totalCount = 0;
            var list = await this._studentRepository.Queryable()
                 .LeftJoin<School2StudentEntity>((a, b) => a.StudentId == b.StudentId)
                 .LeftJoin<SchoolEntity>((a, b, c) => b.SchoolId == c.SchoolId)
                 .AS<School2StudentEntity>("SAAS_HR2.dbo.Demo_School2Student")
                .AS<SchoolEntity>("SAAS_HR2.dbo.Demo_School")
                 .Select((a, b, c) => new StudentListDto
                 {
                     StudentId = a.StudentId.SelectAll(),
                     SchoolName = c.SchoolName
                 })
                   .ToPageListAsync(dto.PageIndex, dto.PageSize, totalCount);

            int pageCount = 0;
            if (list != null && list.Count > 0)
            {
                pageCount = (Math.Ceiling(totalCount.ObjToDecimal() / dto.PageSize.ObjToDecimal())).ObjToInt();
            }
            var result = new PageModel<StudentListDto>() { DataCount = totalCount, PageCount = pageCount, Page = dto.PageIndex, PageSize = dto.PageSize, Data = list };
            return ResultModel.Success(result);
        }


        /// <summary>
        /// 导出
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<byte[]> ExportExcel(StudentQueryDto dto)
        {
            byte[] buff = null;
            dto.PageSize = 999999;
            dto.PageIndex = 1;
            ResultModel<PageModel<StudentListDto>> _cdata = (ResultModel<PageModel<StudentListDto>>)await this.GetList(dto);
            if (_cdata != null)
            {
                if (_cdata.Data != null)
                {
                    var date = _mapper.Map<List<StudentExportDto>>(_cdata.Data.Data);
                    buff = ExcelHelper.GetExcelForList(date);
                }
            }
            return buff;
        }


        /// <summary>
        /// 导入
        /// </summary>
        /// <param name="formFile"></param>
        /// <returns></returns>
        [TransactionInterceptor]
        public async Task<IResultModel> ImportExcel(IFormFile formFile)
        {
            DataTable dt = new DataTable();
            List<StudentImportDto> data = new List<StudentImportDto>();
            try
            {
                using MemoryStream stream = new MemoryStream();
                await formFile.CopyToAsync(stream);
                dt = ExcelHelper.Excel2Table(stream);
                dt.ReplaceColumnName<StudentImportDto>();
                data = dt.Mapper<StudentImportDto>(true);
            }
            catch (Exception ex)
            {
                throw new Exception($"请上传正确的模板数据");
            }

            //验证必填问题
            var _va = data.ValidationNotNull();
            if (!_va.isOk)
            {
                return ResultModel.Failed(_va.errorMsg);
            }

            var result = _mapper.Map<List<StudentEntity>>(data);
            await this._studentRepository.Add(result);
            return ResultModel.Success($"导入成功数据: {data.Count} ");
        }

        /// <summary>
        /// 获取详情
        /// </summary>
        /// <param name="primaryKey"></param>
        /// <returns></returns>
        public async Task<IResultModel> GetViewById(Guid? primaryKey)
        {
            var view = await this._studentRepository.QueryById(primaryKey);
            var result = _mapper.Map<StudentDto>(view);
            return ResultModel.Success(result);
        }

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [TransactionInterceptor]
        public async Task<IResultModel> Add(StudentAddDto dto)
        {
            var entity = _mapper.Map<StudentEntity>(dto);
            //entity.StudentId = Guid.NewGuid();
            await this._studentRepository.Add(entity);

            //添加关系,实现分库事务
            School2StudentEntity school2StudentEntity = new School2StudentEntity
            {
                SchoolId = dto.SchoolId,
                StudentId = entity.StudentId
            };
            await this._school2StudentRepository.Add(school2StudentEntity);

            return ResultModel.Success("添加成功");
        }

        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [TransactionInterceptor]
        public async Task<IResultModel> Update(StudentAddDto dto)
        {
            var entity = await _studentRepository.QueryById(dto.StudentId);
            _mapper.Map(dto, entity);
            await this._studentRepository.Update(entity);

            //多主键不要这样做更新
            var school2StudentEntity = await _school2StudentRepository.GetEntityByStudentId(dto.StudentId);
            if (school2StudentEntity.SchoolId != dto.SchoolId)
            {
                await this._school2StudentRepository.Delete(school2StudentEntity);
                School2StudentEntity school2StudentEntityAdd = new School2StudentEntity
                {
                    SchoolId = dto.SchoolId,
                    StudentId = dto.StudentId
                };
                await this._school2StudentRepository.Add(school2StudentEntityAdd);
            }



            return ResultModel.Success("更新成功");
        }

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="primaryKey"></param>
        /// <returns></returns>
        [TransactionInterceptor]
        public async Task<IResultModel> Del(Guid primaryKey)
        {
            await this._studentRepository.SoftDeleteById(primaryKey);
            await this._school2StudentRepository.DeleteByStudentId(primaryKey);
            return ResultModel.Success("删除成功");
        }



    }
}
