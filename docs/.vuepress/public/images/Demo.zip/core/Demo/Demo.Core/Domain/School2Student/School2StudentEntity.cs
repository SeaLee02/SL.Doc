﻿
namespace Demo.Core.Domain.School2Student
{
    using SqlSugar;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Utils.Core;

    /// <summary>
    /// 学校和学生关系
    /// </summary>
    [SugarTable("Demo_School2Student")]
    public partial class School2StudentEntity
    {

        /// <summary>
        /// 学校Id
        /// </summary>	
        [SugarColumn(IsPrimaryKey = true)]
        public Guid SchoolId { get; set; }

        /// <summary>
        /// 学生Id
        /// </summary>	
        [SugarColumn(IsPrimaryKey = true)]
        public Guid StudentId { get; set; }

    }


}