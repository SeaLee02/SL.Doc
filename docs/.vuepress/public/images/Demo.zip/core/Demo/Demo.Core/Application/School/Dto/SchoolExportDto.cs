﻿namespace Demo.Core.Application.School.Dto
{
    using SqlSugar;
    using System;
    using System.ComponentModel.DataAnnotations;
    using Utils.Core;
    using Utils.Core.Entity;
    using Utils.Core.Annotations;
    using Demo.Core.Domain.School;
    using Excel.Aspose.Annotations;

    /// <summary>
    /// 学校
    /// </summary>
    [ImporterHeader("学校")]
    public  class SchoolExportDto
    {

		      
        /// <summary>
		/// 学校名称
		/// </summary>	
		[ImporterHeader("学校名称")]
        public string SchoolName { get; set; }
		      
        /// <summary>
		/// 备注
		/// </summary>	
		[ImporterHeader("备注")]
        public string Remark { get; set; }
		      
        /// <summary>
		/// 状态|0-删除|1-禁用|2-启用
		/// </summary>	
		[ImporterHeader("状态|0-删除|1-禁用|2-启用")]
        public byte Status { get; set; }
		      
        /// <summary>
		/// 创建时间
		/// </summary>	
		[ImporterHeader("创建时间")]
        public DateTime CreateTime { get; set; }
		      
		      
        /// <summary>
		/// 创建用户
		/// </summary>	
		[ImporterHeader("创建用户")]
        public string CreateUser { get; set; }
		      
        /// <summary>
		/// 更新时间
		/// </summary>	
		[ImporterHeader("更新时间")]
        public DateTime LastUpTime { get; set; }
		      
        /// <summary>
		/// 更新用户
		/// </summary>	
		[ImporterHeader("更新用户")]
        public string LastUpUser { get; set; }
		      
    }
}