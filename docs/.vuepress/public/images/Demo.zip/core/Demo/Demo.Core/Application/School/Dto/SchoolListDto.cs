﻿namespace Demo.Core.Application.School.Dto
{
    using SqlSugar;
    using System;
    using System.ComponentModel.DataAnnotations;
    using Utils.Core;
    using Utils.Core.Entity;
    using Utils.Core.Annotations;
    using Demo.Core.Domain.School;

    /// <summary>
    /// 学校
    /// </summary>
    public  class SchoolListDto
    {

	    /// <summary>
	    /// 主键
	    /// </summary>		
	    public Guid SchoolId { get; set; }
	          
	    /// <summary>
	    /// 学校名称
	    /// </summary>		
	    public string SchoolName { get; set; }

	}

}