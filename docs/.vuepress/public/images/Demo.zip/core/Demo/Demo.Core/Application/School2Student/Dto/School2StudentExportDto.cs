﻿namespace Demo.Core.Application.School2Student.Dto
{
    using SqlSugar;
    using System;
    using System.ComponentModel.DataAnnotations;
    using Utils.Core;
    using Utils.Core.Entity;
    using Utils.Core.Annotations;
    using Demo.Core.Domain.School2Student;
    using Excel.Aspose.Annotations;

    /// <summary>
    /// 学校和学生关系
    /// </summary>
    [ImporterHeader("学校和学生关系")]
    public  class School2StudentExportDto
    {

		      
		      
    }
}