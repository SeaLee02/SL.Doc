﻿
namespace Demo.Core.Infrastructure.Repositories
{
    using Data.Abstractions.Login;
    using Data.Abstractions.UnitOfWork;
    using Data.AspNetCore.Repository;
    using Demo.Core.Domain.School2Student;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class School2StudentRepository : BaseRepository<School2StudentEntity>, ISchool2StudentRepository
    {
        public School2StudentRepository(IUnitOfWork unitOfWork, ILoginInfo loginInfo) : base(unitOfWork, loginInfo)
        {

        }

        /// <summary>
        /// 根据学生Id查询数据
        /// </summary>
        /// <param name="studentId"></param>
        /// <returns></returns>
        public async Task<School2StudentEntity> GetEntityByStudentId(Guid studentId)
        {
            //过滤单表查询条件,关系表中没有Status字段
            var entity = await this.Queryable().Filter(null, true).Where(a => a.StudentId == studentId).FirstAsync();
            return entity;
        }

        /// <summary>
        /// 根据学生Id删除关系数据
        /// </summary>
        /// <param name="studentId"></param>
        /// <returns></returns>
        public async Task<bool> DeleteByStudentId(Guid studentId)
        {
            //过滤单表查询条件,关系表中没有Status字段
            var entity = await GetEntityByStudentId(studentId);
            return await this.Delete(entity);
        }



    }

}