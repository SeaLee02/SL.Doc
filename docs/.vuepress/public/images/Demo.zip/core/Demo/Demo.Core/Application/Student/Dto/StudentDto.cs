﻿namespace Demo.Core.Application.Student.Dto
{
    using SqlSugar;
    using System;
    using System.ComponentModel.DataAnnotations;
    using Utils.Core;
    using Utils.Core.Entity;
    using Utils.Core.Annotations;
    using Demo.Core.Domain.Student;

    /// <summary>
    /// 学生表
    /// </summary>
    public  class StudentDto
    {

	    /// <summary>
	    /// 主键
	    /// </summary>		
	    public Guid StudentId { get; set; }
	          
	    /// <summary>
	    /// 学生姓名
	    /// </summary>		
	    public string StudentName { get; set; }
	          
	    /// <summary>
	    /// 年龄
	    /// </summary>		
	    public int StudentAge { get; set; }
	          
	    /// <summary>
	    /// 备注
	    /// </summary>		
	    public string Remark { get; set; }
	          
	    /// <summary>
	    /// 状态|0-删除|1-禁用|2-启用
	    /// </summary>		
	    public byte Status { get; set; }
	          
	    /// <summary>
	    /// 创建时间
	    /// </summary>		
	    public DateTime CreateTime { get; set; }
	          
	    /// <summary>
	    /// 创建Id
	    /// </summary>		
	    public Guid CreateUserId { get; set; }
	          
	    /// <summary>
	    /// 创建用户
	    /// </summary>		
	    public string CreateUser { get; set; }
	          
	    /// <summary>
	    /// 更新时间
	    /// </summary>		
	    public DateTime LastUpTime { get; set; }
	          
	    /// <summary>
	    /// 更新用户
	    /// </summary>		
	    public string LastUpUser { get; set; }
	          
    }

}