﻿namespace Demo.Core.Domain.Student
{
  using SqlSugar;
  using System;

/// <summary>
/// 学生表
/// </summary>
 public partial class StudentEntity
 {


  }

}