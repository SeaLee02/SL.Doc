﻿namespace Demo.Core.Application.School
{
    using Utils.Core.Map;
    using Mapper.AutoMapper;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using AutoMapper;
    using Demo.Core.Application.School.Dto;
    using Demo.Core.Domain.School;



    public class MapperConfig : IMapperConfig
    {
        /// <summary>
        /// 进行映射设置
        /// </summary>
        /// <param name="cfg"></param>
        public void Bind(IMapperConfigurationExpression cfg)
        {
            //走注解映射
            //cfg.CreateMap<SchoolAddDto, SchoolEntity>()
            //.ForMember(dest => dest.xx, opt => opt.MapFrom(src => src.xx));;

            //列表
             cfg.CreateMap<SchoolEntity,SchoolListDto>();
            //详情
             cfg.CreateMap<SchoolEntity,SchoolDto>();

            //导入
            cfg.CreateMap<SchoolImportDto, SchoolEntity>();

            //导出  
            cfg.CreateMap<SchoolListDto,SchoolExportDto >();

        }
    }
}
