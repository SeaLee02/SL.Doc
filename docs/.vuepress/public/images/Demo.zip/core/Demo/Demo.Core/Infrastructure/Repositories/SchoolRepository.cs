﻿
namespace Demo.Core.Infrastructure.Repositories
{
    using Data.Abstractions.Login;
    using Data.Abstractions.UnitOfWork;
    using Data.AspNetCore.Repository;
    using Demo.Core.Domain.School;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class SchoolRepository : BaseRepository<SchoolEntity>, ISchoolRepository
    {
        public SchoolRepository(IUnitOfWork unitOfWork, ILoginInfo loginInfo) : base(unitOfWork, loginInfo)
        {

        }



    }

}