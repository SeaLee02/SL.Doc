﻿
namespace Demo.Core.Domain.School2Student
{
    using Data.Abstractions.Repository;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public interface ISchool2StudentRepository : IBaseRepository<School2StudentEntity>
    {
        /// <summary>
        /// 根据学生Id查询数据
        /// </summary>
        /// <param name="studentId"></param>
        /// <returns></returns>
        Task<School2StudentEntity> GetEntityByStudentId(Guid studentId);

        /// <summary>
        /// 根据学生Id删除关系数据
        /// </summary>
        /// <param name="studentId"></param>
        /// <returns></returns>
        Task<bool> DeleteByStudentId(Guid studentId);
    }


}
