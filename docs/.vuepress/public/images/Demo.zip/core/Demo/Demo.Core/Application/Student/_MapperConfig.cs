﻿namespace Demo.Core.Application.Student
{
    using Utils.Core.Map;
    using Mapper.AutoMapper;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using AutoMapper;
    using Demo.Core.Application.Student.Dto;
    using Demo.Core.Domain.Student;



    public class MapperConfig : IMapperConfig
    {
        /// <summary>
        /// 进行映射设置
        /// </summary>
        /// <param name="cfg"></param>
        public void Bind(IMapperConfigurationExpression cfg)
        {
            //走注解映射
            //cfg.CreateMap<StudentAddDto, StudentEntity>()
            //.ForMember(dest => dest.xx, opt => opt.MapFrom(src => src.xx));;

            //列表
             cfg.CreateMap<StudentEntity,StudentListDto>();
            //详情
             cfg.CreateMap<StudentEntity,StudentDto>();

            //导入
            cfg.CreateMap<StudentImportDto, StudentEntity>();

            //导出  
            cfg.CreateMap<StudentListDto,StudentExportDto >();

        }
    }
}
