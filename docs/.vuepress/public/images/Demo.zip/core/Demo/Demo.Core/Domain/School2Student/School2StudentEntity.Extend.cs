﻿namespace Demo.Core.Domain.School2Student
{
  using SqlSugar;
  using System;

/// <summary>
/// 学校和学生关系
/// </summary>
 public partial class School2StudentEntity
 {


  }

}