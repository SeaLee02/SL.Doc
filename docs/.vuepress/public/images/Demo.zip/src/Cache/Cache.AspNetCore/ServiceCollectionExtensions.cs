﻿using Cache.Abstractions;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utils.Core.Helper;

namespace Cache.AspNetCore
{
    public static class ServiceCollectionExtensions
    {
        /// <summary>
        /// 添加缓存
        /// </summary>
        /// <param name="services"></param>
        /// <param name="cfg"></param>
        /// <returns></returns>
        public static IServiceCollection AddCache(this IServiceCollection services)
        {

            services.AddSingleton<IMemoryCache>(factory =>
            {
                var cache = new Microsoft.Extensions.Caching.Memory.MemoryCache(new MemoryCacheOptions());
                return cache;
            });

            var assembly = AssemblyHelper.LoadByNameEndString("Cache.MemoryCache").GetTypes();
            var handlerType = assembly.FirstOrDefault(m => typeof(ICacheHandler).IsAssignableFrom(m));
            if (handlerType != null)
            {
                services.AddScoped(typeof(ICacheHandler), handlerType);
            }
            return services;
        }
    }
}