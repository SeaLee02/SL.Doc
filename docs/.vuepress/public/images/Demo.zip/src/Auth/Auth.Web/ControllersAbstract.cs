﻿using Auth.Web.Attributes;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Auth.Web
{
    /// <summary>
    /// 抽象接口基类
    /// </summary>
    [ApiController]
    [Authorize]
    [Route("api/[controller]/[action]")]
    //[Auditing]
    public abstract class ControllersAbstract : ControllerBase
    {

        public ControllersAbstract()
        {

        }
    }
}
