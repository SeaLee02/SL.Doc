﻿using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utils.Core.Inject;

namespace Auth.Web.Audit
{
    public interface IAuditingHandler
    {
        /// <summary>
        /// 处理
        /// </summary>
        /// <param name="context">请求上下文</param>
        /// <param name="next">请求委托</param>
        /// <returns></returns>
        Task Hand(ActionExecutingContext context, ActionExecutionDelegate next);
    }
}
