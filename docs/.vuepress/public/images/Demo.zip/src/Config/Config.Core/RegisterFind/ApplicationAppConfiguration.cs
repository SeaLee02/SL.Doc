﻿using System;
using System.Collections.Generic;
using System.Text;
using Com.Ctrip.Framework.Apollo;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
namespace Config.Core.RegisterFind
{
    public static class ApplicationAppConfiguration
    {
        public static IHostBuilder AppConfiguration(this IHostBuilder hostBuilder)
        {
            hostBuilder.ConfigureAppConfiguration((hostBuilderContext, configurationBuilder) =>
            {
                //注入配置
                //把阿波罗的日志级别调整为最低
                Com.Ctrip.Framework.Apollo.Logging.LogManager.UseConsoleLogging(Com.Ctrip.Framework.Apollo.Logging.LogLevel.Trace);
                //从已加载的配置文件中读取，阿波罗的基础配置，并注入
                configurationBuilder.AddApollo(configurationBuilder.Build().GetSection("Apollo"))
                .AddDefault(Com.Ctrip.Framework.Apollo.Enums.ConfigFileFormat.Properties);
            });
            return hostBuilder;
        }
    }
}
