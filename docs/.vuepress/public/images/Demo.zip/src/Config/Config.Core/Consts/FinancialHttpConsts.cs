﻿using Config.Core.Configuration;
using System;
using System.Collections.Generic;
using System.Text;
using Utils.Core;

namespace Config.Core.Consts
{
    public class FinancialHttpConsts
    {
        public static string trantype { get; set; }

        public static string system { get; set; }

        public static string password { get; set; }

        public static string usercode { get; set; }

        public static string U8C_API { get; set; }

        public static string U8C_API2 { get; set; }

        public static string username { get; set; }

        public static string SeeYon_API { get; set; }

        public string json { get; set; } = "";

        public string urlservice { get; set; } = "";

        /// <summary>
        /// 是否开启U8C
        /// </summary>
        public static bool IsEnable { get; set; }
    }
}