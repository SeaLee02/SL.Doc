﻿using Config.Core.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utils.Core;

namespace Config.Core.Consts
{
    public class AppConfigConsts
    {
        public static string PermissionService { get; private set; } = "新系统";


        /// <summary>
        /// 00000000-0000-0000-0000-000000000000
        /// </summary> 
        public static string GuidEmpty { get; private set; } = "00000000-0000-0000-0000-000000000000";

        /// <summary>
        /// 
        /// </summary>
        public static Guid GEmpty { get; private set; } = Guid.Empty;

        /// <summary>
        /// 下载Excel类型
        /// </summary>
        public static string Excel { get; set; } = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

        /// <summary>
        /// 数据库地址
        /// </summary>
        public static string HRSQLConnection { get; set; } 

        /// <summary>
        /// 服务发现地址
        /// </summary>
        public static string NginxURL { get; set; }



        /// <summary>
        /// 文件的类型限制
        /// </summary>
        public static Dictionary<string, string> FileTypes
        { get;  set; }

    }
}
