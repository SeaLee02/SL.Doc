﻿using Config.Core.Consts;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Primitives;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Config.Core.Configuration
{
    /// <summary>
    /// 监听配置更改
    /// </summary>
    public static class ConfigChange
    {
        public static void CheckChangeToken(this IServiceCollection services, IConfiguration configuration)
        {

            ChangeToken.OnChange(() => configuration.GetReloadToken(), () =>
            {
                //重新注入操作类
                ConfigInit.Init();
                //管理全局配置文件
                //需要做的操作
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine("配置发生了变化");
                Console.ForegroundColor = ConsoleColor.White;
            });



        }

    }
}
