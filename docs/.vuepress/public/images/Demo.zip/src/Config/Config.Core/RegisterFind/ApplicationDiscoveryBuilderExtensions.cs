﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Steeltoe.Discovery.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Config.Core.RegisterFind
{
    public static class ApplicationDiscoveryBuilderExtensions
    {
        public static IApplicationBuilder DiscoveryClient(this IApplicationBuilder app)
        {
            app.UseDiscoveryClient();
            return app;
        }
    }
}
