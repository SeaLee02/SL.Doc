﻿using Config.Core.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utils.Core;
using System.Text.Json;

namespace Config.Core.Consts
{
    /// <summary>
    /// 配置初始化---此方法待优化--todo
    /// </summary>
    public class ConfigInit
    {
        /// <summary>
        /// 静态字段需要重新赋值
        /// </summary>
        public static void Init()
        {
            #region 基础设置
            /// <summary>
            /// 数据库地址
            /// </summary>
            AppConfigConsts.HRSQLConnection = Appsettings.app(new string[] { "HRSQLConnection" });

            /// <summary>
            /// 服务发现地址
            /// </summary>
            AppConfigConsts.NginxURL = Appsettings.app(new string[] { "NginxURL" });


            //文件扩展
            string fileTypeJson = Appsettings.app(new string[] { "FileType_Extension" });
            if (fileTypeJson.NotNull())
            {
                AppConfigConsts.FileTypes = JsonSerializer.Deserialize<Dictionary<string, string>>(fileTypeJson);

            }



            /// <summary>
            /// 图片文件路径
            /// </summary>
            CustomConsts.PictureRootDirectoryPath = Appsettings.app(new string[] { "PictureRootDirectoryPath" });

            //文件模板
            CustomConsts.FileTemplate = Appsettings.app(new string[] { "FileTemplate" });

            /// <summary>
            /// AD域控地址
            /// </summary>
            CustomConsts.ADURL = Appsettings.app(new string[] { "ADURL" });

            /// <summary>
            /// 名片扫描接口秘钥
            /// </summary>
            CustomConsts.OCR_AppCode = Appsettings.app(new string[] { "OCR_AppCode" });

            #endregion

            #region AD
            ADConsts.DomainName = Appsettings.app(new string[] { "DomainName" });

            ADConsts.UserName = Appsettings.app(new string[] { "UserName" });

            /// <summary>
            /// AD服务器账号
            /// </summary>
            /// <summary>
            /// AD服务器密码
            /// </summary>
            ADConsts.UserPwd = Appsettings.app(new string[] { "UserPwd" });
            /// <summary>
            /// ADAPI地址
            /// </summary>
            ADConsts.ADApiUrl = Appsettings.app(new string[] { "ADURL" });
            /// <summary>
            /// ADAPI地址
            /// </summary>
            ADConsts.ApiScopeName = Appsettings.app(new string[] { "ApiScopeName" });
            ADConsts.ApiScopeDescribe = Appsettings.app(new string[] { "ApiScopeDescribe" });
            ADConsts.ClientId = Appsettings.app(new string[] { "ClientId" });
            ADConsts.ClientSecrets = Appsettings.app(new string[] { "ClientSecrets" });
            /// <summary>
            /// 是否开启AD
            /// </summary>
            ADConsts.IsEnable = Appsettings.app(new string[] { "AD_IsEnable" }).ToBool();
            #endregion

            #region 企业邮箱

            /// <summary>
            /// KEY
            /// </summary> 
            EnterpriseExmailConsts.Corpid = Appsettings.app(new string[] { "em_Corpid" });

            /// <summary>
            /// Corpsecret
            /// </summary> 
            EnterpriseExmailConsts.Corpsecret = Appsettings.app(new string[] { "em_Corpsecret" });


            EnterpriseExmailConsts.IsEnable = Appsettings.app(new string[] { "em_IsEnable" }).ToBool();

            EnterpriseExmailConsts.Domain = Appsettings.app(new string[] { "em_Domain" });
            EnterpriseExmailConsts.ParentId = Appsettings.app(new string[] { "em_ParentId" }).ToLong();
            #endregion

            #region u8c
            FinancialHttpConsts.trantype = Appsettings.app(new string[] { "U8C_Trantype" });

            FinancialHttpConsts.system = Appsettings.app(new string[] { "U8C_System" });

            FinancialHttpConsts.password = Appsettings.app(new string[] { "U8C_Password" });

            FinancialHttpConsts.usercode = Appsettings.app(new string[] { "U8C_Usercode" });

            FinancialHttpConsts.U8C_API = Appsettings.app(new string[] { "U8C_API" });

            FinancialHttpConsts.U8C_API2 = Appsettings.app(new string[] { "U8C_API2" });

            FinancialHttpConsts.username = Appsettings.app(new string[] { "SeeYon_Username" });

            FinancialHttpConsts.SeeYon_API = Appsettings.app(new string[] { "SeeYon_API" });


            /// <summary>
            /// 是否开启U8C
            /// </summary>
            FinancialHttpConsts.IsEnable = Appsettings.app(new string[] { "U8C_IsEnable" }).ToBool();
            #endregion

            #region 业务中心
            //业务中心数据库字符串
            ConfigSettings.BussinessSQLConnection = Appsettings.app(new string[] { "BussinessSQLConnection" });
            #endregion

        }


    }
}