﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Steeltoe.Discovery.Client;
using Steeltoe.Discovery.Eureka;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Config.Core.RegisterFind
{
    public static class ServiceDiscoveryCollectionExtensions
    {
        public static IServiceCollection AddRegisterFind(this IServiceCollection services, IConfiguration config)
        {
            services.AddDiscoveryClient(config);
            services.AddServiceDiscovery(options => options.UseEureka());
            return services;
        }
    }
}
