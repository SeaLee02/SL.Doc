﻿using Config.Core.Configuration;
using System;
using System.Collections.Generic;
using System.Text;
using Utils.Core;

namespace Config.Core.Consts
{
    public class ADConsts
    {
        /// <summary>
        /// AD服务器IP
        /// </summary>
        public static string DomainName { get; set; }
        /// <summary>
        /// AD服务器账号
        /// </summary>
        public static string UserName { get; set; }
        /// <summary>
        /// AD服务器密码
        /// </summary>
        public static string UserPwd { get; set; }

        /// <summary>
        /// ADAPI地址
        /// </summary>
        public static string ADApiUrl { get; set; }

        /// <summary>
        /// ADAPI地址
        /// </summary>
        public static string ApiScopeName { get; set; }
        public static string ApiScopeDescribe { get; set; }
        public static string ClientId { get; set; }
        public static string ClientSecrets { get; set; }

        /// <summary>
        /// 是否开启AD
        /// </summary>
        public static bool IsEnable { get; set; }
    }
}
