﻿using Config.Core.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Config.Core.Consts
{
    /// <summary>
    /// 定义常量
    /// </summary>
    public class CustomConsts
    {
        /// <summary>
        /// 图片文件路径
        /// </summary>
        public static string PictureRootDirectoryPath { get; set; }

        /// <summary>
        /// AD域控地址
        /// </summary>
        public static string ADURL { get; set; }

        /// <summary>
        /// 模板集合
        /// </summary>
        public static string FileTemplate { get; set; }

        /// <summary>
        /// 名片扫描接口秘钥
        /// </summary>
        public static string OCR_AppCode { get; set; }
    }
}
