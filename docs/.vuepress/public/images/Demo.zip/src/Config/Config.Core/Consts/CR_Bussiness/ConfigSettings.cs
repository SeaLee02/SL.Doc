﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Config.Core.Consts
{
    public class ConfigSettings
    {
        public static string BussinessSQLConnection { get; set; }
    }
}
