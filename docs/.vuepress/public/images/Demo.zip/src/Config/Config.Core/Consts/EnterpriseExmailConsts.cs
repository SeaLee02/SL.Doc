﻿using Config.Core.Configuration;
using System;
using Utils.Core;

namespace Config.Core.Consts
{
    /// <summary>
    /// 缓存常量
    /// </summary>
    public class EnterpriseExmailConsts
    {

        /// <summary>
        /// 用户缓存
        /// </summary> 
        public static string ExmailToken { get; private set; } = "ExmailToken";

        /// <summary>
        /// KEY
        /// </summary> 
        public static string Corpid { get;  set; }

        /// <summary>
        /// Corpsecret
        /// </summary> 
        public static string Corpsecret { get;  set; } 


        public static bool IsEnable { get;  set; }

        public static string Domain { get;  set; } 
        public static long ParentId { get;  set; }


    }
}
