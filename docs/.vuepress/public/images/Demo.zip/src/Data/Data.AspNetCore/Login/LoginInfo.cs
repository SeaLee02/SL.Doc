﻿using Data.Abstractions.Login;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utils.Core;

namespace Data.AspNetCore.Login
{
    public class LoginInfo : ILoginInfo
    {

        private readonly IHttpContextAccessor _accessor;
        public LoginInfo(IHttpContextAccessor accessor)
        {
            this._accessor = accessor;
            //InitData();
        }

        //public void InitData()
        //{
        //    var claims = this._accessor.HttpContext.User;
        //    if (claims.Claims.Count() > 0)
        //    {
        //        Guid.TryParse(claims.FindFirst("UserId").Value, out EmployeeId);
        //        EmployeeName = claims.FindFirst("RealName").Value;
        //        EmployeeCompany = claims.FindFirst("CompanyId").Value;
        //        bool.TryParse(claims.FindFirst("IsSuperManager").Value, out _isSuperManager);
        //        this.UserId = EmployeeId;
        //        this.RealName = EmployeeName;
        //        this.CompanyId = EmployeeCompany;
        //        this.IsSuperManager = _isSuperManager;
        //    }
        //}


        public Guid UserId
        {
            get
            {
                var userId = _accessor?.HttpContext?.User?.FindFirst("UserId");

                if (userId != null && userId.Value.NotNull())
                {
                    return new Guid(userId.Value);
                }

                return Guid.Empty;
            }
        }
        public string RealName
        {
            get
            {
                var realName = _accessor?.HttpContext?.User?.FindFirst("RealName");
                if (realName == null || realName.Value.IsNull())
                {
                    return "";
                }

                return realName.Value;
            }
        }
        public string CompanyId
        {
            get
            {
                var companyId = _accessor?.HttpContext?.User?.FindFirst("CompanyId");
                if (companyId == null || companyId.Value.IsNull())
                {
                    return "";
                }

                return companyId.Value;
            }
        }

        public bool IsSuperManager
        {
            get
            {
                var isSuperManager = _accessor?.HttpContext?.User?.FindFirst("IsSuperManager");
                if (isSuperManager != null || isSuperManager.Value.NotNull())
                {
                    return isSuperManager.Value.ToBool();
                }

                return false;
            }
        }
    }
}
