﻿using Data.Abstractions.Login;
using Data.Abstractions.Repository;
using Data.Abstractions.Services;
using Data.Abstractions.UnitOfWork;
using Data.AspNetCore.Login;
using Data.AspNetCore.Repository;
using Data.AspNetCore.Services;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using SqlSugar;
using System;
using System.Collections.Generic;

namespace Data.AspNetCore
{
    public static class ServiceCollectionExtensions
    {
        /// <summary>
        /// 添加配置管理(使用Redis)
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        public static IServiceCollection AddDataConfig(this IServiceCollection services, IHostEnvironment env, List<ConnectionBase> connections)
        {
            services.AddScoped<ILoginInfo, LoginInfo>();
            services.AddScoped(typeof(IBaseRepository<>), typeof(BaseRepository<>));
            services.AddScoped(typeof(IBaseServices<>), typeof(BaseServices<>));
            services.AddScoped<IUnitOfWork, UnitOfWork>();

            List<ConnectionConfig> connectionList = new List<ConnectionConfig>();
            foreach (var item in connections)
            {
                ConnectionConfig config = new ConnectionConfig();
                config.ConnectionString = item.ConnectionString;
                config.DbType = item.DbType;
                config.ConfigId = item.ConfigId;
                config.IsAutoCloseConnection = true;
                config.MoreSettings = new ConnMoreSettings()
                {
                    IsWithNoLockQuery = true//看这里
                };
                connectionList.Add(config);
            }

            // 把多个连接对象注入服务，这里必须采用Scope，因为有事务操作
            services.AddScoped<ISqlSugarClient>(o =>
            {
                //string ConnectionString = AppConfigConsts.HRSQLConnection;
                //"Data Source=10.1.0.131;Initial Catalog=SAAS;Persist Security Info=True;User ID=sa;password=90-=op[]";
                //AppConfigConsts.HRSQLConnection;
                var db = new SqlSugarScope(connectionList,
                db =>
                {
                    foreach (var item in connections)
                    {
                        if (item.IsFilter)
                        {
                            db.GetConnection(item.ConfigId).QueryFilter.Add(new SqlFilterItem
                            {
                                FilterValue = filter =>
                                {
                                    return new SqlFilterResult { Sql = " Status=2 " };
                                }
                            });

                            db.GetConnection(item.ConfigId).QueryFilter.Add(new SqlFilterItem
                            {
                                FilterName = "NotDel",
                                FilterValue = filter =>
                                {
                                    return new SqlFilterResult { Sql = " Status!=0 " };
                                }
                            });

                            db.GetConnection(item.ConfigId).QueryFilter.Add(new SqlFilterItem
                            {
                                //多表过滤,多表统一设置 a,b.c...以此类推
                                FilterValue = filter =>
                                {
                                    return new SqlFilterResult { Sql = " a.Status=2 " };
                                },
                                IsJoinQuery = true
                            });

                            db.GetConnection(item.ConfigId).QueryFilter.Add(new SqlFilterItem
                            {
                                //多表过滤,多表统一设置 a,b.c...以此类推
                                FilterName = "NotDels",
                                FilterValue = filter =>
                                {
                                    return new SqlFilterResult { Sql = " a.Status!=0 " };
                                },
                                IsJoinQuery = true
                            });
                        }

                        if (env.IsDevelopment())
                        {
                            if (item.IsLogSql)
                            {

                                db.GetConnection((int)item.ConfigId).Aop.OnLogExecuting = (sql, p) =>
                                {
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine(sql);
                                    Console.ForegroundColor = ConsoleColor.White;
                                };
                            }
                        }
                    }
                }

                );

                return db;
            });

            return services;
        }
    }
}