﻿using Utils.Core.DataModel;
using Data.Abstractions.Repository;
using Data.Abstractions.Services;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Data.AspNetCore.Services
{
    public class BaseServices<TEntity> : IBaseServices<TEntity>
        where TEntity : class, new()
    {
        public IBaseRepository<TEntity> _baseRepository;//通过在子类的构造函数中注入，这里是基类，不用构造函数

        public BaseServices(IBaseRepository<TEntity> baseRepository)
        {
            this._baseRepository = baseRepository;
        }

        /// <summary>
        /// 返回内存数据
        /// </summary>
        /// <returns></returns>
        public ISugarQueryable<TEntity> Queryable()
        {
            return _baseRepository.Queryable();
        }

        #region 查询

        /// <summary>
        /// 根据ID查询一条数据
        /// </summary>
        /// <param name="objId"></param>
        /// <returns></returns>
        public async Task<TEntity> QueryById(dynamic objId)
        {
            return await _baseRepository.QueryById(objId);
        }

        /// <summary>
        /// 根据ID查询一条数据
        /// </summary>
        /// <param name="objId"></param>
        /// <param name="blnUseCache"></param>
        /// <returns></returns>
        public async Task<TEntity> QueryById(dynamic objId, bool blnUseCache = false)
        {
            return await _baseRepository.QueryById(objId, blnUseCache);
        }

        /// <summary>
        /// 根据ID查询数据
        /// </summary>
        /// <param name="lstIds"></param>
        /// <returns></returns>
        public async Task<List<TEntity>> QueryByIDs(dynamic[] lstIds)
        {
            return await _baseRepository.QueryByIDs(lstIds);
        }

        /// <summary>
        /// 动态组装查询
        /// </summary>
        /// <param name="conditionals"></param>
        /// <returns></returns>
        public async Task<List<TEntity>> Query(List<ConditionalModel> conditionals)
        {
            return await _baseRepository.Query(conditionals);
        }

        /// <summary>
        /// 查询所有数据
        /// </summary>
        /// <returns></returns>
        public async Task<List<TEntity>> Query()
        {
            return await _baseRepository.Query();
        }

        /// <summary>
        /// 查询数据列表
        /// </summary>
        /// <param name="strWhere"></param>
        /// <returns></returns>
        public async Task<List<TEntity>> Query(string strWhere)
        {
            return await _baseRepository.Query(strWhere);
        }

        /// <summary>
        /// 查询数据列表
        /// </summary>
        /// <param name="whereExpression"></param>
        /// <returns></returns>
        public async Task<List<TEntity>> Query(Expression<Func<TEntity, bool>> whereExpression)
        {
            return await _baseRepository.Query(whereExpression);
        }

        /// <summary>
        /// 按照特定列查询数据列表
        /// </summary>
        /// <typeparam name="TResult"></typeparam>
        /// <param name="expression"></param>
        /// <returns></returns>
        public async Task<List<TResult>> Query<TResult>(Expression<Func<TEntity, TResult>> expression)
        {
            return await _baseRepository.Query(expression);
        }

        /// <summary>
        /// 按照特定列查询数据列表带条件排序
        /// </summary>
        /// <typeparam name="TResult"></typeparam>
        /// <param name="expression"></param>
        /// <param name="whereExpression"></param>
        /// <param name="strOrderByFileds"></param>
        /// <returns></returns>
        public async Task<List<TResult>> Query<TResult>(Expression<Func<TEntity, TResult>> expression, Expression<Func<TEntity, bool>> whereExpression, string strOrderByFileds)
        {
            return await _baseRepository.Query(expression, whereExpression, strOrderByFileds);
        }

        /// <summary>
        /// 查询一个列表
        /// </summary>
        /// <param name="whereExpression"></param>
        /// <param name="orderByExpression"></param>
        /// <param name="isAsc"></param>
        /// <returns></returns>
        public async Task<List<TEntity>> Query(Expression<Func<TEntity, bool>> whereExpression, Expression<Func<TEntity, object>> orderByExpression, bool isAsc = true)
        {
            return await _baseRepository.Query(whereExpression, orderByExpression, isAsc);
        }

        /// <summary>
        /// 查询集合
        /// </summary>
        /// <param name="whereExpression"></param>
        /// <param name="strOrderByFileds"></param>
        /// <returns></returns>
        public async Task<List<TEntity>> Query(Expression<Func<TEntity, bool>> whereExpression, string strOrderByFileds)
        {
            return await _baseRepository.Query(whereExpression, strOrderByFileds);
        }

        /// <summary>
        /// 查询一个列表
        /// </summary>
        /// <param name="strWhere"></param>
        /// <param name="strOrderByFileds"></param>
        /// <returns></returns>
        public async Task<List<TEntity>> Query(string strWhere, string strOrderByFileds)
        {
            return await _baseRepository.Query(strWhere, strOrderByFileds);
        }

        /// <summary>
        /// 根据sql语句查询
        /// </summary>
        /// <param name="strSql">完整的sql语句</param>
        /// <param name="parameters">参数</param>
        /// <returns>泛型集合</returns>
        public async Task<List<TEntity>> QuerySql(string strSql, SugarParameter[] parameters = null)
        {
            return await _baseRepository.QuerySql(strSql, parameters);
        }

        /// <summary>
        /// 根据sql语句查询
        /// </summary>
        /// <param name="strSql">完整的sql语句</param>
        /// <param name="parameters">参数</param>
        /// <returns>DataTable</returns>
        public async Task<DataTable> QueryTable(string strSql, SugarParameter[] parameters = null)
        {
            return await _baseRepository.QueryTable(strSql, parameters);
        }

        /// <summary>
        /// 功能描述:查询前N条数据
        /// </summary>
        /// <param name="whereExpression">条件表达式</param>
        /// <param name="intTop">前N条</param>
        /// <param name="strOrderByFileds">排序字段，如name asc,age desc</param>
        /// <returns>数据列表</returns>
        public async Task<List<TEntity>> Query(Expression<Func<TEntity, bool>> whereExpression, int intTop, string strOrderByFileds)
        {
            return await _baseRepository.Query(whereExpression, intTop, strOrderByFileds);
        }

        /// <summary>
        /// 功能描述:查询前N条数据
        /// </summary>
        /// <param name="strWhere">条件</param>
        /// <param name="intTop">前N条</param>
        /// <param name="strOrderByFileds">排序字段，如name asc,age desc</param>
        /// <returns>数据列表</returns>
        public async Task<List<TEntity>> Query(
            string strWhere,
            int intTop,
            string strOrderByFileds)
        {
            return await _baseRepository.Query(strWhere, intTop, strOrderByFileds);
        }

        /// <summary>
        /// 功能描述:分页查询
        /// </summary>
        /// <param name="whereExpression">条件表达式</param>
        /// <param name="intPageIndex">页码（下标0）</param>
        /// <param name="intPageSize">页大小</param>
        /// <param name="strOrderByFileds">排序字段，如name asc,age desc</param>
        /// <returns>数据列表</returns>
        public async Task<List<TEntity>> Query(
            Expression<Func<TEntity, bool>> whereExpression,
            int intPageIndex,
            int intPageSize,
            string strOrderByFileds)
        {
            return await _baseRepository.Query(
              whereExpression,
              intPageIndex,
              intPageSize,
              strOrderByFileds);
        }

        /// <summary>
        /// 功能描述:分页查询
        /// </summary>
        /// <param name="strWhere">条件</param>
        /// <param name="intPageIndex">页码（下标0）</param>
        /// <param name="intPageSize">页大小</param>
        /// <param name="strOrderByFileds">排序字段，如name asc,age desc</param>
        /// <returns>数据列表</returns>
        public async Task<List<TEntity>> Query(
          string strWhere,
          int intPageIndex,
          int intPageSize,
          string strOrderByFileds)
        {
            return await _baseRepository.Query(
            strWhere,
            intPageIndex,
            intPageSize,
            strOrderByFileds);
        }

        public async Task<PageModel<TEntity>> QueryPage(Expression<Func<TEntity, bool>> whereExpression,
        int intPageIndex = 1, int intPageSize = 10, string strOrderByFileds = null)
        {
            return await _baseRepository.QueryPage(whereExpression,
         intPageIndex, intPageSize, strOrderByFileds);
        }

        public async Task<List<TResult>> QueryMuch<T, T2, T3, TResult>(Expression<Func<T, T2, T3, object[]>> joinExpression, Expression<Func<T, T2, T3, TResult>> selectExpression, Expression<Func<T, T2, T3, bool>> whereLambda = null) where T : class, new()
        {
            return await _baseRepository.QueryMuch(joinExpression, selectExpression, whereLambda);
        }

        #endregion 查询

        #region 新增

        /// <summary>
        /// 判断是否存在
        /// </summary>
        /// <param name="whereExpression"></param>
        /// <returns></returns>
        public async Task<bool> Any(Expression<Func<TEntity, bool>> whereExpression)
        {
            return await _baseRepository.Any(whereExpression);
        }

        /// <summary>
        /// 写入实体数据
        /// </summary>
        /// <param name="entity">博文实体类</param>
        /// <returns></returns>
        public async Task<TEntity> Add(TEntity entity)
        {
            return await _baseRepository.Add(entity);
        }

        /// <summary>
        /// 批量插入实体(速度快)
        /// </summary>
        /// <param name="listEntity">实体集合</param>
        /// <returns>影响行数</returns>
        public async Task<int> Add(List<TEntity> listEntity)
        {
            return await _baseRepository.Add(listEntity);
        }

        #endregion 新增

        #region 更新

        /// <summary>
        /// 更新实体数据
        /// </summary>
        /// <param name="entity">博文实体类</param>
        /// <returns></returns>
        public async Task<bool> Update(TEntity entity)
        {
            return await _baseRepository.Update(entity);
        }

        public async Task<bool> Update(TEntity entity, string strWhere)
        {
            return await _baseRepository.Update(entity, strWhere);
        }

        public async Task<bool> Update(dynamic operateAnonymousObjects)
        {
            return await _baseRepository.Update(operateAnonymousObjects);
        }

        public async Task<bool> Update(
         TEntity entity,
         List<string> lstColumns = null,
         List<string> lstIgnoreColumns = null,
         string strWhere = ""
            )
        {
            return await _baseRepository.Update(entity, lstColumns, lstIgnoreColumns, strWhere);
        }

        #endregion 更新

        #region 删除

        /// <summary>
        /// 根据实体删除一条数据
        /// </summary>
        /// <param name="entity">博文实体类</param>
        /// <returns></returns>
        public async Task<bool> Delete(TEntity entity)
        {
            return await _baseRepository.Delete(entity);
        }

        /// <summary>
        /// 删除指定ID的数据
        /// </summary>
        /// <param name="id">主键ID</param>
        /// <returns></returns>
        public async Task<bool> DeleteById(dynamic id)
        {
            return await _baseRepository.DeleteById(id);
        }

        /// <summary>
        /// 删除指定ID集合的数据(批量删除)
        /// </summary>
        /// <param name="ids">主键ID集合</param>
        /// <returns></returns>
        public async Task<bool> DeleteByIds(dynamic[] ids)
        {
            return await _baseRepository.DeleteByIds(ids);
        }

        /// <summary>
        /// 根据条实体删除
        /// </summary>
        /// <param name="whereExpression"></param>
        /// <returns></returns>
        public async Task<bool> Delete(Expression<Func<TEntity, bool>> whereExpression)
        {
            return await _baseRepository.Delete(whereExpression);
        }

        /// <summary>
        /// 软删除
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<bool> SoftDeleteById(dynamic id)
        {
            return await _baseRepository.SoftDeleteById(id);
        }

        /// <summary>
        /// 软删除集合
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        public async Task<bool> SoftDeleteByIds(dynamic[] ids)
        {
            return await _baseRepository.SoftDeleteByIds(ids);
        }

        /// <summary>
        /// 软删除
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public async Task<bool> SoftDelete(TEntity entity)
        {
            return await _baseRepository.SoftDelete(entity);
        }

        #endregion 删除

        /// <summary>
        /// 检查名称
        /// </summary>
        /// <param name="whereExpression"></param>
        /// <param name="PrimaryKey"></param>
        /// <returns></returns>
        public async Task<int> CheckName(Expression<Func<TEntity, bool>> whereExpression)
        {
            return await _baseRepository.CheckName(whereExpression);
        }
    }
}