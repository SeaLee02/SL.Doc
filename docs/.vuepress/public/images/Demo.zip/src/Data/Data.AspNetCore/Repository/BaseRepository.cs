﻿using Utils.Core.DataModel;
using Data.Abstractions.Login;
using Data.Abstractions.Repository;
using Data.Abstractions.UnitOfWork;
using SqlSugar;
using SqlSugar.Extensions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq.Expressions;
using System.Reflection;
using System.Threading.Tasks;
using Utils.Core;

namespace Data.AspNetCore.Repository
{
    public class BaseRepository<TEntity> : IBaseRepository<TEntity>
        where TEntity : class, new()
    {
        private readonly IUnitOfWork _unitOfWork;
        private SqlSugarScope _dbBase;
        private ILoginInfo _loginInfo;

        private ISqlSugarClient _db
        {
            get; set;
        }

        public ISqlSugarClient Db
        {
            get { return _db; }
        }

        public BaseRepository(IUnitOfWork unitOfWork, ILoginInfo loginInfo)
        {
            _unitOfWork = unitOfWork;
            var configId = typeof(TEntity).GetCustomAttribute<TenantAttribute>()?.configId ?? 0;
            _dbBase = unitOfWork.GetDbClient();
            //SqlSugarProvider
            _db = _dbBase.GetConnection(configId);
            _loginInfo = loginInfo;
        }

        /// <summary>
        /// 返回内存数据(这时不查询数据库,注意用法)
        /// </summary>
        /// <returns></returns>
        public ISugarQueryable<TEntity> Queryable()
        {
            return _db.Queryable<TEntity>();
        }

        #region 单个实体查询

        /// <summary>
        /// 根据id查询实体
        /// </summary>
        /// <param name="objId"></param>
        /// <returns></returns>
        public async Task<TEntity> QueryById(dynamic objId)
        {
            return await _db.Queryable<TEntity>().In(objId).SingleAsync();
        }

        /// <summary>
        /// 功能描述:根据ID查询一条数据
        /// </summary>
        /// <param name="objId">id（必须指定主键特性 [SugarColumn(IsPrimaryKey=true)]），如果是联合主键，请使用Where条件</param>
        /// <param name="blnUseCache">是否使用缓存</param>
        /// <returns>数据实体</returns>
        public async Task<TEntity> QueryById(dynamic objId, bool blnUseCache = false)
        {
            return await _db.Queryable<TEntity>().WithCacheIF(blnUseCache).In(objId).SingleAsync();
        }

        /// <summary>
        /// 功能描述:根据ID查询数据
        /// </summary>
        /// <param name="lstIds">id列表（必须指定主键特性 [SugarColumn(IsPrimaryKey=true)]），如果是联合主键，请使用Where条件</param>
        /// <returns>数据实体列表</returns>
        public async Task<List<TEntity>> QueryByIDs(dynamic lstIds)
        {
            return await _db.Queryable<TEntity>().In(lstIds).ToListAsync();
        }

        /// <summary>
        /// 判断是否存在
        /// </summary>
        /// <param name="whereExpression"></param>
        /// <returns></returns>
        public async Task<bool> Any(Expression<Func<TEntity, bool>> whereExpression)
        {
            return await _db.Queryable<TEntity>().AnyAsync(whereExpression);
        }

        public async Task<List<TEntity>> Query(List<ConditionalModel> conditionals)
        {
            List<IConditionalModel> _conditional = new List<IConditionalModel>();
            _conditional.AddRange(conditionals);
            return await _db.Queryable<TEntity>().Where(_conditional).ToListAsync();
        }

        /// <summary>
        /// 功能描述:查询所有数据
        /// </summary>
        /// <returns>数据列表</returns>
        public async Task<List<TEntity>> Query()
        {
            return await _db.Queryable<TEntity>().ToListAsync();
        }

        /// <summary>
        /// 功能描述:查询数据列表
        /// </summary>
        /// <param name="strWhere">条件</param>
        /// <returns>数据列表</returns>
        public async Task<List<TEntity>> Query(string strWhere)
        {
            return await _db.Queryable<TEntity>().WhereIF(!string.IsNullOrEmpty(strWhere), strWhere).ToListAsync();
        }

        /// <summary>
        /// 功能描述:查询数据列表
        /// </summary>
        /// <param name="whereExpression">whereExpression</param>
        /// <returns>数据列表</returns>
        public async Task<List<TEntity>> Query(Expression<Func<TEntity, bool>> whereExpression)
        {
            return await _db.Queryable<TEntity>().WhereIF(whereExpression != null, whereExpression).ToListAsync();
        }

        /// <summary>
        /// 功能描述:按照特定列查询数据列表
        /// </summary>
        /// <typeparam name="TResult"></typeparam>
        /// <param name="expression"></param>
        /// <returns></returns>
        public async Task<List<TResult>> Query<TResult>(Expression<Func<TEntity, TResult>> expression)
        {
            return await _db.Queryable<TEntity>().Select(expression).ToListAsync();
        }

        /// <summary>
        /// 功能描述:按照特定列查询数据列表带条件排序
        /// </summary>
        /// <typeparam name="TResult"></typeparam>
        /// <param name="whereExpression">过滤条件</param>
        /// <param name="expression">查询实体条件</param>
        /// <param name="strOrderByFileds">排序条件</param>
        /// <returns></returns>
        public async Task<List<TResult>> Query<TResult>(Expression<Func<TEntity, TResult>> expression, Expression<Func<TEntity, bool>> whereExpression, string strOrderByFileds)
        {
            return await _db.Queryable<TEntity>().OrderByIF(!string.IsNullOrEmpty(strOrderByFileds), strOrderByFileds).WhereIF(whereExpression != null, whereExpression).Select(expression).ToListAsync();
        }

        /// <summary>
        /// 功能描述:查询一个列表
        /// </summary>
        /// <param name="whereExpression">条件表达式</param>
        /// <param name="strOrderByFileds">排序字段，如name asc,age desc</param>
        /// <returns>数据列表</returns>
        public async Task<List<TEntity>> Query(Expression<Func<TEntity, bool>> whereExpression, string strOrderByFileds)
        {
            return await _db.Queryable<TEntity>().WhereIF(whereExpression != null, whereExpression).OrderByIF(strOrderByFileds != null, strOrderByFileds).ToListAsync();
        }

        /// <summary>
        /// 功能描述:查询一个列表
        /// </summary>
        /// <param name="whereExpression"></param>
        /// <param name="orderByExpression"></param>
        /// <param name="isAsc"></param>
        /// <returns></returns>
        public async Task<List<TEntity>> Query(Expression<Func<TEntity, bool>> whereExpression, Expression<Func<TEntity, object>> orderByExpression, bool isAsc = true)
        {
            return await _db.Queryable<TEntity>().OrderByIF(orderByExpression != null, orderByExpression, isAsc ? OrderByType.Asc : OrderByType.Desc).WhereIF(whereExpression != null, whereExpression).ToListAsync();
        }

        /// <summary>
        /// 功能描述:查询一个列表
        /// </summary>
        /// <param name="strWhere">条件</param>
        /// <param name="strOrderByFileds">排序字段，如name asc,age desc</param>
        /// <returns>数据列表</returns>
        public async Task<List<TEntity>> Query(string strWhere, string strOrderByFileds)
        {
            return await _db.Queryable<TEntity>().OrderByIF(!string.IsNullOrEmpty(strOrderByFileds), strOrderByFileds).WhereIF(!string.IsNullOrEmpty(strWhere), strWhere).ToListAsync();
        }

        /// <summary>
        /// 功能描述:查询前N条数据
        /// </summary>
        /// <param name="whereExpression">条件表达式</param>
        /// <param name="intTop">前N条</param>
        /// <param name="strOrderByFileds">排序字段，如name asc,age desc</param>
        /// <returns>数据列表</returns>
        public async Task<List<TEntity>> Query(
            Expression<Func<TEntity, bool>> whereExpression,
            int intTop,
            string strOrderByFileds)
        {
            return await _db.Queryable<TEntity>().OrderByIF(!string.IsNullOrEmpty(strOrderByFileds), strOrderByFileds).WhereIF(whereExpression != null, whereExpression).Take(intTop).ToListAsync();
        }

        /// <summary>
        /// 功能描述:查询前N条数据
        /// </summary>
        /// <param name="strWhere">条件</param>
        /// <param name="intTop">前N条</param>
        /// <param name="strOrderByFileds">排序字段，如name asc,age desc</param>
        /// <returns>数据列表</returns>
        public async Task<List<TEntity>> Query(
            string strWhere,
            int intTop,
            string strOrderByFileds)
        {
            return await _db.Queryable<TEntity>().OrderByIF(!string.IsNullOrEmpty(strOrderByFileds), strOrderByFileds).WhereIF(!string.IsNullOrEmpty(strWhere), strWhere).Take(intTop).ToListAsync();
        }

        /// <summary>
        /// 根据sql语句查询
        /// </summary>
        /// <param name="strSql">完整的sql语句</param>
        /// <param name="parameters">参数</param>
        /// <returns>泛型集合</returns>
        public async Task<List<TEntity>> QuerySql(string strSql, SugarParameter[] parameters = null)
        {
            return await _db.Ado.SqlQueryAsync<TEntity>(strSql, parameters);
        }

        /// <summary>
        /// 根据sql语句查询
        /// </summary>
        /// <param name="strSql">完整的sql语句</param>
        /// <param name="parameters">参数</param>
        /// <returns>DataTable</returns>
        public async Task<DataTable> QueryTable(string strSql, SugarParameter[] parameters = null)
        {
            return await _db.Ado.GetDataTableAsync(strSql, parameters);
        }

        /// <summary>
        /// 功能描述:分页查询
        /// </summary>
        /// <param name="whereExpression">条件表达式</param>
        /// <param name="intPageIndex">页码（下标0）</param>
        /// <param name="intPageSize">页大小</param>
        /// <param name="strOrderByFileds">排序字段，如name asc,age desc</param>
        /// <returns>数据列表</returns>
        public async Task<List<TEntity>> Query(
            Expression<Func<TEntity, bool>> whereExpression,
            int intPageIndex,
            int intPageSize,
            string strOrderByFileds)
        {
            return await _db.Queryable<TEntity>()
                .OrderByIF(!string.IsNullOrEmpty(strOrderByFileds), strOrderByFileds)
                .WhereIF(whereExpression != null, whereExpression)
                .ToPageListAsync(intPageIndex, intPageSize);
        }

        /// <summary>
        /// 功能描述:分页查询
        /// </summary>
        /// <param name="strWhere">条件</param>
        /// <param name="intPageIndex">页码（下标0）</param>
        /// <param name="intPageSize">页大小</param>
        /// <param name="strOrderByFileds">排序字段，如name asc,age desc</param>
        /// <returns>数据列表</returns>
        public async Task<List<TEntity>> Query(
          string strWhere,
          int intPageIndex,
          int intPageSize,
          string strOrderByFileds)
        {
            return await _db.Queryable<TEntity>().OrderByIF(!string.IsNullOrEmpty(strOrderByFileds), strOrderByFileds).WhereIF(!string.IsNullOrEmpty(strWhere), strWhere).ToPageListAsync(intPageIndex, intPageSize);
        }

        /// <summary>
        /// 多表联查-3
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="T2"></typeparam>
        /// <typeparam name="T3"></typeparam>
        /// <param name="query"></param>
        /// <param name="joinExpressio"></param>
        /// <param name="whereExpression"></param>
        /// <param name="selectExpression"></param>
        /// <param name="isDisabledGobalFilter"></param>
        /// <returns></returns>
        public async Task<List<T>> Query<T, T2, T3>(QueryPageModel query,
            Expression<Func<T, T2, T3, JoinQueryInfos>> joinExpressio, Expression<Func<T, T2, T3, bool>> whereExpression,
             Expression<Func<T, T2, T3, T>> selectExpression, bool isDisabledGobalFilter = false)
        {
            if (query != null)
            {
                return await _db.Queryable<T, T2, T3>(joinExpressio).Filter(null, isDisabledGobalFilter: isDisabledGobalFilter)
                .Where(whereExpression)
                .OrderByIF(query.OrderByFileds.NotNull(), query.OrderByFileds)
                .Select(selectExpression)
                .ToListAsync();
            }
            else
            {
                return await _db.Queryable<T, T2, T3>(joinExpressio).Filter(null, isDisabledGobalFilter: isDisabledGobalFilter)
                .Where(whereExpression)
                .Select(selectExpression)
                .ToListAsync();
            }
        }

        /// <summary>
        ///  多表联查-4
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="T2"></typeparam>
        /// <typeparam name="T3"></typeparam>
        /// <typeparam name="T4"></typeparam>
        /// <param name="query"></param>
        /// <param name="joinExpressio"></param>
        /// <param name="whereExpression"></param>
        /// <param name="selectExpression"></param>
        /// <param name="isDisabledGobalFilter"></param>
        /// <returns></returns>
        public async Task<List<T>> Query<T, T2, T3, T4>(QueryPageModel query,
            Expression<Func<T, T2, T3, T4, JoinQueryInfos>> joinExpressio, Expression<Func<T, T2, T3, T4, bool>> whereExpression,
             Expression<Func<T, T2, T3, T4, T>> selectExpression, bool isDisabledGobalFilter = false)
        {
            var list = await _db.Queryable<T, T2, T3, T4>(joinExpressio).Filter(null, isDisabledGobalFilter: isDisabledGobalFilter)
                .Where(whereExpression)
             .OrderByIF(query.OrderByFileds.NotNull(), query.OrderByFileds)
             .Select(selectExpression)
             .ToListAsync();
            return list;
        }

        /// <summary>
        /// 多表联查-5
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="T2"></typeparam>
        /// <typeparam name="T3"></typeparam>
        /// <typeparam name="T4"></typeparam>
        /// <typeparam name="T5"></typeparam>
        /// <param name="query"></param>
        /// <param name="joinExpressio"></param>
        /// <param name="whereExpression"></param>
        /// <param name="selectExpression"></param>
        /// <returns></returns>
        public async Task<List<T>> Query<T, T2, T3, T4, T5>(QueryPageModel query,
            Expression<Func<T, T2, T3, T4, T5, JoinQueryInfos>> joinExpressio, Expression<Func<T, bool>> whereExpression,
             Expression<Func<T, T2, T3, T4, T5, T>> selectExpression)
        {
            var list = await _db.Queryable<T, T2, T3, T4, T5>(joinExpressio)
                .Where(whereExpression)
             .OrderByIF(query.OrderByFileds.NotNull(), query.OrderByFileds)
             .Select(selectExpression)
             .ToListAsync();
            return list;
        }

        /// <summary>
        /// 分页查询
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="T2"></typeparam>
        /// <typeparam name="T3"></typeparam>
        /// <typeparam name="T4"></typeparam>
        /// <typeparam name="T5"></typeparam>
        /// <param name="query"></param>
        /// <param name="joinExpressio"></param>
        /// <param name="whereExpression"></param>
        /// <param name="selectExpression"></param>
        /// <param name="isDisabledGobalFilter"></param>
        /// <returns></returns>
        public async Task<List<T>> Query<T, T2, T3, T4, T5>(QueryPageModel query,
            Expression<Func<T, T2, T3, T4, T5, JoinQueryInfos>> joinExpressio, Expression<Func<T, T2, T3, T4, T5, bool>> whereExpression,
             Expression<Func<T, T2, T3, T4, T5, T>> selectExpression, bool isDisabledGobalFilter = false)
        {
            var list = await _db.Queryable<T, T2, T3, T4, T5>(joinExpressio).Filter(null, isDisabledGobalFilter: isDisabledGobalFilter)
                .Where(whereExpression)
             .OrderByIF(query.OrderByFileds.NotNull(), query.OrderByFileds)
             .Select(selectExpression)
             .ToListAsync();
            return list;
        }

        #endregion 单个实体查询

        #region 分页查询

        /// <summary>
        /// 分页查询-1
        /// </summary>
        /// <param name="whereExpression">条件表达式</param>
        /// <param name="intPageIndex">页码（下标0）</param>
        /// <param name="intPageSize">页大小</param>
        /// <param name="strOrderByFileds">排序字段，如name asc,age desc</param>
        /// <returns></returns>
        public async Task<PageModel<TEntity>> QueryPage(Expression<Func<TEntity, bool>> whereExpression, int intPageIndex = 1, int intPageSize = 20, string strOrderByFileds = null)
        {
            RefAsync<int> totalCount = 0;
            var list = await _db.Queryable<TEntity>()
             .OrderByIF(!string.IsNullOrEmpty(strOrderByFileds), strOrderByFileds)
             .WhereIF(whereExpression != null, whereExpression)
             .ToPageListAsync(intPageIndex, intPageSize, totalCount);

            int pageCount = 0;
            if (list != null && list.Count > 0)
            {
                pageCount = (Math.Ceiling(totalCount.ObjToDecimal() / intPageSize.ObjToDecimal())).ObjToInt();
            }
            return new PageModel<TEntity>() { DataCount = totalCount, PageCount = pageCount, Page = intPageIndex, PageSize = intPageSize, Data = list };
        }

        /// <summary>
        ///  分页查询-1
        /// </summary>
        /// <param name="query"></param>
        /// <param name="whereExpression"></param>
        /// <returns></returns>
        public async Task<PageModel<TEntity>> QueryPage(QueryPageModel query, Expression<Func<TEntity, bool>> whereExpression)
        {
            RefAsync<int> totalCount = 0;
            var list = await _db.Queryable<TEntity>()
             .OrderByIF(query.OrderByFileds.NotNull(), query.OrderByFileds)
             .Where(whereExpression)
             .ToPageListAsync(query.PageIndex, query.PageSize, totalCount);

            int pageCount = 0;
            if (list != null && list.Count > 0)
            {
                pageCount = (Math.Ceiling(totalCount.ObjToDecimal() / query.PageSize.ObjToDecimal())).ObjToInt();
            }
            return new PageModel<TEntity>() { DataCount = totalCount, PageCount = pageCount, Page = query.PageIndex, PageSize = query.PageSize, Data = list };
        }

        /// <summary>
        /// 分页查询-1
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="TResult"></typeparam>
        /// <param name="query"></param>
        /// <param name="whereExpression"></param>
        /// <param name="selectExpression"></param>
        /// <returns></returns>
        public async Task<PageModel<TResult>> QueryPage<T, TResult>(QueryPageModel query,
            Expression<Func<T, bool>> whereExpression, Expression<Func<T, TResult>> selectExpression)
        {
            RefAsync<int> totalCount = 0;
            var list = await _db.Queryable<T>()
             .OrderByIF(query.OrderByFileds.NotNull(), query.OrderByFileds)
             .Where(whereExpression)
             .Select(selectExpression)
             .ToPageListAsync(query.PageIndex, query.PageSize, totalCount);

            int pageCount = 0;
            if (list != null && list.Count > 0)
            {
                pageCount = (Math.Ceiling(totalCount.ObjToDecimal() / query.PageSize.ObjToDecimal())).ObjToInt();
            }
            return new PageModel<TResult>() { DataCount = totalCount, PageCount = pageCount, Page = query.PageIndex, PageSize = query.PageSize, Data = list };
        }


        /// <summary>
        /// 分页查询-2
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="T2"></typeparam>
        /// <typeparam name="TResult"></typeparam>
        /// <param name="query"></param>
        /// <param name="joinExpressio"></param>
        /// <param name="whereExpression"></param>
        /// <param name="selectExpression"></param>
        /// <returns></returns>
        public async Task<PageModel<TResult>> QueryPage<T, T2, TResult>(QueryPageModel query,
            Expression<Func<T, T2, JoinQueryInfos>> joinExpressio, Expression<Func<T, bool>> whereExpression,
             Expression<Func<T, T2, TResult>> selectExpression)
        {
            RefAsync<int> totalCount = 0;
            var list = await _db.Queryable<T, T2>(joinExpressio)
                .Where(whereExpression)
             .OrderByIF(query.OrderByFileds.NotNull(), query.OrderByFileds)
             .Select(selectExpression)
             .ToPageListAsync(query.PageIndex, query.PageSize, totalCount);

            int pageCount = 0;
            if (list != null && list.Count > 0)
            {
                pageCount = (Math.Ceiling(totalCount.ObjToDecimal() / query.PageSize.ObjToDecimal())).ObjToInt();
            }
            return new PageModel<TResult>() { DataCount = totalCount, PageCount = pageCount, Page = query.PageIndex, PageSize = query.PageSize, Data = list };
        }

        /// <summary>
        /// 分页查询-2
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="T2"></typeparam>
        /// <param name="query"></param>
        /// <param name="joinExpressio"></param>
        /// <param name="whereExpression"></param>
        /// <param name="selectExpression"></param>
        /// <returns></returns>
        public async Task<PageModel<T>> QueryPage<T, T2>(QueryPageModel query,
            Expression<Func<T, T2, JoinQueryInfos>> joinExpressio, Expression<Func<T, T2, bool>> whereExpression,
             Expression<Func<T, T2, T>> selectExpression)
        {
            RefAsync<int> totalCount = 0;
            var list = await _db.Queryable<T, T2>(joinExpressio)
                .Where(whereExpression)
             .OrderByIF(query.OrderByFileds.NotNull(), query.OrderByFileds)
             .Select(selectExpression)
             .ToPageListAsync(query.PageIndex, query.PageSize, totalCount);

            int pageCount = 0;
            if (list != null && list.Count > 0)
            {
                pageCount = (Math.Ceiling(totalCount.ObjToDecimal() / query.PageSize.ObjToDecimal())).ObjToInt();
            }
            return new PageModel<T>() { DataCount = totalCount, PageCount = pageCount, Page = query.PageIndex, PageSize = query.PageSize, Data = list };
        }

        /// <summary>
        /// 分页查询-2
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="T2"></typeparam>
        /// <param name="query"></param>
        /// <param name="joinExpressio"></param>
        /// <param name="whereExpression"></param>
        /// <param name="selectExpression"></param>
        /// <returns></returns>
        public async Task<PageModel<T>> QueryPage<T, T2>(QueryPageModel query,
            Expression<Func<T, T2, JoinQueryInfos>> joinExpressio, Expression<Func<T, bool>> whereExpression,
             Expression<Func<T, T2, T>> selectExpression)
        {
            RefAsync<int> totalCount = 0;
            var list = await _db.Queryable<T, T2>(joinExpressio)
                .Where(whereExpression)
             .OrderByIF(query.OrderByFileds.NotNull(), query.OrderByFileds)
             .Select(selectExpression)
             .ToPageListAsync(query.PageIndex, query.PageSize, totalCount);

            int pageCount = 0;
            if (list != null && list.Count > 0)
            {
                pageCount = (Math.Ceiling(totalCount.ObjToDecimal() / query.PageSize.ObjToDecimal())).ObjToInt();
            }
            return new PageModel<T>() { DataCount = totalCount, PageCount = pageCount, Page = query.PageIndex, PageSize = query.PageSize, Data = list };
        }

        /// <summary>
        /// 分页查询-3(标准,推荐写法)
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="T2"></typeparam>
        /// <typeparam name="T3"></typeparam>
        /// <typeparam name="TResult"></typeparam>
        /// <param name="query"></param>
        /// <param name="joinExpressio"></param>
        /// <param name="whereExpression"></param>
        /// <param name="selectExpression"></param>
        /// <returns></returns>
        public async Task<PageModel<TResult>> QueryPage<T, T2, T3, TResult>(QueryPageModel query,
            Expression<Func<T, T2, T3, JoinQueryInfos>> joinExpressio, Expression<Func<T, T2, T3, bool>> whereExpression,
             Expression<Func<T, T2, T3, TResult>> selectExpression)
        {
            RefAsync<int> totalCount = 0;
            var list = await _db.Queryable<T, T2, T3>(joinExpressio)
                .Where(whereExpression)
             .OrderByIF(query.OrderByFileds.NotNull(), query.OrderByFileds)
             .Select(selectExpression)
             .ToPageListAsync(query.PageIndex, query.PageSize, totalCount);

            int pageCount = 0;
            if (list != null && list.Count > 0)
            {
                pageCount = (Math.Ceiling(totalCount.ObjToDecimal() / query.PageSize.ObjToDecimal())).ObjToInt();
            }
            return new PageModel<TResult>() { DataCount = totalCount, PageCount = pageCount, Page = query.PageIndex, PageSize = query.PageSize, Data = list };
        }

        /// <summary>
        /// 分页查询-4(标准,推荐写法)
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="T2"></typeparam>
        /// <typeparam name="T3"></typeparam>
        /// <typeparam name="T4"></typeparam>
        /// <param name="query"></param>
        /// <param name="joinExpressio"></param>
        /// <param name="whereExpression"></param>
        /// <param name="selectExpression"></param>
        /// <param name="isDisabledGobalFilter"></param>
        /// <param name="filter"></param>
        /// <returns></returns>
        public async Task<PageModel<T>> QueryPage<T, T2, T3, T4>(QueryPageModel query,
            Expression<Func<T, T2, T3, T4, JoinQueryInfos>> joinExpressio, Expression<Func<T, T2, T3, T4, bool>> whereExpression,
             Expression<Func<T, T2, T3, T4, T>> selectExpression, bool isDisabledGobalFilter = false, string filter = null)
        {
            RefAsync<int> totalCount = 0;
            var list = await _db.Queryable<T, T2, T3, T4>(joinExpressio).Filter(filter, isDisabledGobalFilter: isDisabledGobalFilter)
                .Where(whereExpression)
             .OrderByIF(query.OrderByFileds.NotNull(), query.OrderByFileds)
             .Select(selectExpression)
             .ToPageListAsync(query.PageIndex, query.PageSize, totalCount);

            int pageCount = 0;
            if (list != null && list.Count > 0)
            {
                pageCount = (Math.Ceiling(totalCount.ObjToDecimal() / query.PageSize.ObjToDecimal())).ObjToInt();
            }
            return new PageModel<T>() { DataCount = totalCount, PageCount = pageCount, Page = query.PageIndex, PageSize = query.PageSize, Data = list };
        }

        /// <summary>
        /// 分页查询-5(标准,推荐写法)
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="T2"></typeparam>
        /// <typeparam name="T3"></typeparam>
        /// <typeparam name="T4"></typeparam>
        /// <typeparam name="T5"></typeparam>
        /// <param name="query"></param>
        /// <param name="joinExpressio"></param>
        /// <param name="whereExpression"></param>
        /// <param name="selectExpression"></param>
        /// <param name="isDisabledGobalFilter"></param>
        /// <param name="filter"></param>
        /// <returns></returns>
        public async Task<PageModel<T>> QueryPage<T, T2, T3, T4, T5>(QueryPageModel query,
            Expression<Func<T, T2, T3, T4, T5, JoinQueryInfos>> joinExpressio, Expression<Func<T, T2, T3, T4, T5, bool>> whereExpression,
             Expression<Func<T, T2, T3, T4, T5, T>> selectExpression, bool isDisabledGobalFilter = false, string filter = null)
        {
            RefAsync<int> totalCount = 0;
            var list = await _db.Queryable<T, T2, T3, T4, T5>(joinExpressio).Filter(filter, isDisabledGobalFilter: isDisabledGobalFilter)
                .Where(whereExpression)
             .OrderByIF(query.OrderByFileds.NotNull(), query.OrderByFileds)
             .Select(selectExpression)
             .ToPageListAsync(query.PageIndex, query.PageSize, totalCount);

            int pageCount = 0;
            if (list != null && list.Count > 0)
            {
                pageCount = (Math.Ceiling(totalCount.ObjToDecimal() / query.PageSize.ObjToDecimal())).ObjToInt();
            }
            return new PageModel<T>() { DataCount = totalCount, PageCount = pageCount, Page = query.PageIndex, PageSize = query.PageSize, Data = list };
        }

        /// <summary>
        /// 分页查询-5
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="T2"></typeparam>
        /// <typeparam name="T3"></typeparam>
        /// <typeparam name="T4"></typeparam>
        /// <typeparam name="T5"></typeparam>
        /// <param name="query"></param>
        /// <param name="joinExpressio"></param>
        /// <param name="whereExpression"></param>
        /// <param name="selectExpression"></param>
        /// <returns></returns>
        public async Task<PageModel<T>> QueryPage<T, T2, T3, T4, T5>(QueryPageModel query,
            Expression<Func<T, T2, T3, T4, T5, JoinQueryInfos>> joinExpressio, Expression<Func<T, bool>> whereExpression,
             Expression<Func<T, T2, T3, T4, T5, T>> selectExpression)
        {
            RefAsync<int> totalCount = 0;
            var list = await _db.Queryable<T, T2, T3, T4, T5>(joinExpressio)
                .Where(whereExpression)
             .OrderByIF(query.OrderByFileds.NotNull(), query.OrderByFileds)
             .Select(selectExpression)
             .ToPageListAsync(query.PageIndex, query.PageSize, totalCount);

            int pageCount = 0;
            if (list != null && list.Count > 0)
            {
                pageCount = (Math.Ceiling(totalCount.ObjToDecimal() / query.PageSize.ObjToDecimal())).ObjToInt();
            }
            return new PageModel<T>() { DataCount = totalCount, PageCount = pageCount, Page = query.PageIndex, PageSize = query.PageSize, Data = list };
        }

        /// <summary>
        /// 分页查询-6(标准,推荐写法)
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="T2"></typeparam>
        /// <typeparam name="T3"></typeparam>
        /// <typeparam name="T4"></typeparam>
        /// <typeparam name="T5"></typeparam>
        /// <typeparam name="T6"></typeparam>
        /// <param name="query"></param>
        /// <param name="joinExpressio"></param>
        /// <param name="whereExpression"></param>
        /// <param name="selectExpression"></param>
        /// <param name="isDisabledGobalFilter"></param>
        /// <param name="filter"></param>
        /// <returns></returns>
        public async Task<PageModel<T6>> QueryPage<T, T2, T3, T4, T5, T6>(QueryPageModel query,
            Expression<Func<T, T2, T3, T4, T5, JoinQueryInfos>> joinExpressio, Expression<Func<T, T2, T3, T4, T5, bool>> whereExpression,
             Expression<Func<T, T2, T3, T4, T5, T6>> selectExpression, bool isDisabledGobalFilter = false, string filter = null)
        {
            RefAsync<int> totalCount = 0;
            var list = await _db.Queryable<T, T2, T3, T4, T5>(joinExpressio).Filter(filter, isDisabledGobalFilter: isDisabledGobalFilter)
                .Where(whereExpression)
             .OrderByIF(query.OrderByFileds.NotNull(), query.OrderByFileds)
             .Select(selectExpression)
             .ToPageListAsync(query.PageIndex, query.PageSize, totalCount);

            int pageCount = 0;
            if (list != null && list.Count > 0)
            {
                pageCount = (Math.Ceiling(totalCount.ObjToDecimal() / query.PageSize.ObjToDecimal())).ObjToInt();
            }
            return new PageModel<T6>() { DataCount = totalCount, PageCount = pageCount, Page = query.PageIndex, PageSize = query.PageSize, Data = list };
        }

        /// <summary>
        /// 分页查询-7(标准,推荐写法)
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="T2"></typeparam>
        /// <typeparam name="T3"></typeparam>
        /// <typeparam name="T4"></typeparam>
        /// <typeparam name="T5"></typeparam>
        /// <typeparam name="T6"></typeparam>
        /// <typeparam name="T7"></typeparam>
        /// <param name="query"></param>
        /// <param name="joinExpressio"></param>
        /// <param name="whereExpression"></param>
        /// <param name="selectExpression"></param>
        /// <param name="isDisabledGobalFilter"></param>
        /// <param name="filter"></param>
        /// <returns></returns>
        public async Task<PageModel<T7>> QueryPage<T, T2, T3, T4, T5, T6, T7>(QueryPageModel query,
            Expression<Func<T, T2, T3, T4, T5, T6, JoinQueryInfos>> joinExpressio, Expression<Func<T, T2, T3, T4, T5, T6, bool>> whereExpression,
             Expression<Func<T, T2, T3, T4, T5, T6, T7>> selectExpression, bool isDisabledGobalFilter = false, string filter = null)
        {
            RefAsync<int> totalCount = 0;
            var list = await _db.Queryable<T, T2, T3, T4, T5, T6>(joinExpressio).Filter(filter, isDisabledGobalFilter: isDisabledGobalFilter)
                .Where(whereExpression)
             .OrderByIF(query.OrderByFileds.NotNull(), query.OrderByFileds)
             .Select(selectExpression)
             .ToPageListAsync(query.PageIndex, query.PageSize, totalCount);

            int pageCount = 0;
            if (list != null && list.Count > 0)
            {
                pageCount = (Math.Ceiling(totalCount.ObjToDecimal() / query.PageSize.ObjToDecimal())).ObjToInt();
            }
            return new PageModel<T7>() { DataCount = totalCount, PageCount = pageCount, Page = query.PageIndex, PageSize = query.PageSize, Data = list };
        }

        /// <summary>
        /// 分页查询-8,子查询(标准,推荐写法)
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="T2"></typeparam>
        /// <typeparam name="T3"></typeparam>
        /// <typeparam name="T4"></typeparam>
        /// <typeparam name="T5"></typeparam>
        /// <typeparam name="T6"></typeparam>
        /// <typeparam name="T7"></typeparam>
        /// <typeparam name="T8"></typeparam>
        /// <typeparam name="T9"></typeparam>
        /// <param name="query"></param>
        /// <param name="joinExpressio"></param>
        /// <param name="whereExpression"></param>
        /// <param name="selectExpression"></param>
        /// <param name="mapperObject"></param>
        /// <param name="mapperField"></param>
        /// <param name="isDisabledGobalFilter"></param>
        /// <param name="filter"></param>
        /// <returns></returns>
        public async Task<PageModel<T8>> QueryPage<T, T2, T3, T4, T5, T6, T7, T8, T9>(QueryPageModel query,
            Expression<Func<T, T2, T3, T4, T5, T6, T7, JoinQueryInfos>> joinExpressio, Expression<Func<T, T2, T3, T4, T5, T6, T7, bool>> whereExpression,
             Expression<Func<T, T2, T3, T4, T5, T6, T7, T8>> selectExpression,
             Expression<Func<T8, List<T9>>> mapperObject, Expression<Func<T8, object>> mapperField,
             bool isDisabledGobalFilter = false, string filter = null)
        {
            RefAsync<int> totalCount = 0;
            var list = await _db.Queryable<T, T2, T3, T4, T5, T6, T7>(joinExpressio).Filter(filter, isDisabledGobalFilter: isDisabledGobalFilter)
                .Where(whereExpression)
             .OrderByIF(query.OrderByFileds.NotNull(), query.OrderByFileds)
             .Select(selectExpression)
             .Mapper(mapperObject:mapperObject,mapperField:mapperField)
             .ToPageListAsync(query.PageIndex, query.PageSize, totalCount);

            int pageCount = 0;
            if (list != null && list.Count > 0)
            {
                pageCount = (Math.Ceiling(totalCount.ObjToDecimal() / query.PageSize.ObjToDecimal())).ObjToInt();
            }
            return new PageModel<T8>() { DataCount = totalCount, PageCount = pageCount, Page = query.PageIndex, PageSize = query.PageSize, Data = list };
        }


        /// <summary>
        /// 分页查询-8(标准,推荐写法)
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="T2"></typeparam>
        /// <typeparam name="T3"></typeparam>
        /// <typeparam name="T4"></typeparam>
        /// <typeparam name="T5"></typeparam>
        /// <typeparam name="T6"></typeparam>
        /// <typeparam name="T7"></typeparam>
        /// <typeparam name="T8"></typeparam>
        /// <param name="query"></param>
        /// <param name="joinExpressio"></param>
        /// <param name="whereExpression"></param>
        /// <param name="selectExpression"></param>
        /// <param name="isDisabledGobalFilter"></param>
        /// <param name="filter"></param>
        /// <returns></returns>
        public async Task<PageModel<T8>> QueryPage<T, T2, T3, T4, T5, T6, T7, T8>(QueryPageModel query,
            Expression<Func<T, T2, T3, T4, T5, T6, T7, JoinQueryInfos>> joinExpressio, Expression<Func<T, T2, T3, T4, T5, T6, T7, bool>> whereExpression,
             Expression<Func<T, T2, T3, T4, T5, T6, T7, T8>> selectExpression, bool isDisabledGobalFilter = false, string filter = null)
        {
            RefAsync<int> totalCount = 0;
            var list = await _db.Queryable<T, T2, T3, T4, T5, T6, T7>(joinExpressio).Filter(filter, isDisabledGobalFilter: isDisabledGobalFilter)
                .Where(whereExpression)
             .OrderByIF(query.OrderByFileds.NotNull(), query.OrderByFileds)
             .Select(selectExpression)
             .ToPageListAsync(query.PageIndex, query.PageSize, totalCount);

            int pageCount = 0;
            if (list != null && list.Count > 0)
            {
                pageCount = (Math.Ceiling(totalCount.ObjToDecimal() / query.PageSize.ObjToDecimal())).ObjToInt();
            }
            return new PageModel<T8>() { DataCount = totalCount, PageCount = pageCount, Page = query.PageIndex, PageSize = query.PageSize, Data = list };
        }

        /// <summary>
        /// 分页查询-9(标准,推荐写法)
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="T2"></typeparam>
        /// <typeparam name="T3"></typeparam>
        /// <typeparam name="T4"></typeparam>
        /// <typeparam name="T5"></typeparam>
        /// <typeparam name="T6"></typeparam>
        /// <typeparam name="T7"></typeparam>
        /// <typeparam name="T8"></typeparam>
        /// <typeparam name="T9"></typeparam>
        /// <param name="query"></param>
        /// <param name="joinExpressio"></param>
        /// <param name="whereExpression"></param>
        /// <param name="selectExpression"></param>
        /// <param name="isDisabledGobalFilter"></param>
        /// <param name="filter"></param>
        /// <returns></returns>
        public async Task<PageModel<T9>> QueryPage<T, T2, T3, T4, T5, T6, T7, T8, T9>(QueryPageModel query,
            Expression<Func<T, T2, T3, T4, T5, T6, T7, T8, JoinQueryInfos>> joinExpressio, Expression<Func<T, T2, T3, T4, T5, T6, T7, T8, bool>> whereExpression,
             Expression<Func<T, T2, T3, T4, T5, T6, T7, T8, T9>> selectExpression, bool isDisabledGobalFilter = false, string filter = null)
        {
            RefAsync<int> totalCount = 0;
            var list = await _db.Queryable<T, T2, T3, T4, T5, T6, T7, T8>(joinExpressio).Filter(filter, isDisabledGobalFilter: isDisabledGobalFilter)
                .Where(whereExpression)
             .OrderByIF(query.OrderByFileds.NotNull(), query.OrderByFileds)
             .Select(selectExpression)
             .ToPageListAsync(query.PageIndex, query.PageSize, totalCount);

            int pageCount = 0;
            if (list != null && list.Count > 0)
            {
                pageCount = (Math.Ceiling(totalCount.ObjToDecimal() / query.PageSize.ObjToDecimal())).ObjToInt();
            }
            return new PageModel<T9>() { DataCount = totalCount, PageCount = pageCount, Page = query.PageIndex, PageSize = query.PageSize, Data = list };
        }

        /// <summary>
        ///查询-多表查询
        /// </summary>
        /// <typeparam name="T">实体1</typeparam>
        /// <typeparam name="T2">实体2</typeparam>
        /// <typeparam name="T3">实体3</typeparam>
        /// <typeparam name="TResult">返回对象</typeparam>
        /// <param name="joinExpression">关联表达式 (join1,join2) => new object[] {JoinType.Left,join1.UserNo==join2.UserNo}</param>
        /// <param name="selectExpression">返回表达式 (s1, s2) => new { Id =s1.UserNo, Id1 = s2.UserNo}</param>
        /// <param name="whereLambda">查询表达式 (w1, w2) =>w1.UserNo == "")</param>
        /// <returns>值</returns>
        public async Task<List<TResult>> QueryMuch<T, T2, T3, TResult>(
            Expression<Func<T, T2, T3, object[]>> joinExpression,
            Expression<Func<T, T2, T3, TResult>> selectExpression,
            Expression<Func<T, T2, T3, bool>> whereLambda = null) where T : class, new()
        {
            if (whereLambda == null)
            {
                return await _db.Queryable(joinExpression).Select(selectExpression).ToListAsync();
            }
            return await _db.Queryable(joinExpression).Where(whereLambda).Select(selectExpression).ToListAsync();
        }

        /// <summary>
        /// 两表联合查询-分页
        /// </summary>
        /// <typeparam name="T">实体1</typeparam>
        /// <typeparam name="T2">实体1</typeparam>
        /// <typeparam name="TResult">返回对象</typeparam>
        /// <param name="joinExpression">关联表达式</param>
        /// <param name="selectExpression">返回表达式</param>
        /// <param name="whereExpression">查询表达式</param>
        /// <param name="intPageIndex">页码</param>
        /// <param name="intPageSize">页大小</param>
        /// <param name="strOrderByFileds">排序字段</param>
        /// <returns></returns>
        public async Task<PageModel<TResult>> QueryTabsPage<T, T2, TResult>(
            Expression<Func<T, T2, object[]>> joinExpression,
            Expression<Func<T, T2, TResult>> selectExpression,
            Expression<Func<TResult, bool>> whereExpression,
            int intPageIndex = 1,
            int intPageSize = 10,
            string strOrderByFileds = null)
        {
            RefAsync<int> totalCount = 0;
            var list = await _db.Queryable<T, T2>(joinExpression)
             .Select(selectExpression)
             .OrderByIF(!string.IsNullOrEmpty(strOrderByFileds), strOrderByFileds)
             .WhereIF(whereExpression != null, whereExpression)
             .ToPageListAsync(intPageIndex, intPageSize, totalCount);
            int pageCount = 0;
            if (list != null && list.Count > 0)
            {
                pageCount = (Math.Ceiling(totalCount.ObjToDecimal() / intPageSize.ObjToDecimal())).ObjToInt();
            }
            return new PageModel<TResult>() { DataCount = totalCount, PageCount = pageCount, Page = intPageIndex, PageSize = intPageSize, Data = list };
        }

        /// <summary>
        /// 两表联合查询-分页-分组
        /// </summary>
        /// <typeparam name="T">实体1</typeparam>
        /// <typeparam name="T2">实体1</typeparam>
        /// <typeparam name="TResult">返回对象</typeparam>
        /// <param name="joinExpression">关联表达式</param>
        /// <param name="selectExpression">返回表达式</param>
        /// <param name="whereExpression">查询表达式</param>
        /// <param name="intPageIndex">页码</param>
        /// <param name="intPageSize">页大小</param>
        /// <param name="strOrderByFileds">排序字段</param>
        /// <returns></returns>
        public async Task<PageModel<TResult>> QueryTabsPage<T, T2, TResult>(
            Expression<Func<T, T2, object[]>> joinExpression,
            Expression<Func<T, T2, TResult>> selectExpression,
            Expression<Func<TResult, bool>> whereExpression,
            Expression<Func<T, object>> groupExpression,
            int intPageIndex = 1,
            int intPageSize = 10,
            string strOrderByFileds = null)
        {
            RefAsync<int> totalCount = 0;
            var list = await _db.Queryable<T, T2>(joinExpression).GroupBy(groupExpression)
             .Select(selectExpression)
             .OrderByIF(!string.IsNullOrEmpty(strOrderByFileds), strOrderByFileds)
             .WhereIF(whereExpression != null, whereExpression)
             .ToPageListAsync(intPageIndex, intPageSize, totalCount);
            int pageCount = 0;
            if (list != null && list.Count > 0)
            {
                pageCount = (Math.Ceiling(totalCount.ObjToDecimal() / intPageSize.ObjToDecimal())).ObjToInt();
            }
            return new PageModel<TResult>() { DataCount = totalCount, PageCount = pageCount, Page = intPageIndex, PageSize = intPageSize, Data = list };
        }

        #endregion 分页查询

        #region 新增

        /// <summary>
        /// 写入实体数据
        /// </summary>
        /// <param name="entity">博文实体类</param>
        /// <returns></returns>
        public async Task<TEntity> Add(TEntity entity)
        {
            SetCreatedBy(entity);
            var insert = _db.Insertable(entity);
            return await insert.ExecuteReturnEntityAsync();
        }

        /// <summary>
        /// 写入实体数据
        /// </summary>
        /// <param name="entity">实体类</param>
        /// <param name="insertColumns">指定只插入列</param>
        /// <returns>返回自增量列</returns>
        public async Task<int> Add(TEntity entity, Expression<Func<TEntity, object>> insertColumns = null)
        {
            var insert = _db.Insertable(entity);
            if (insertColumns == null)
            {
                return await insert.ExecuteReturnIdentityAsync();
            }
            else
            {
                return await insert.InsertColumns(insertColumns).ExecuteReturnIdentityAsync();
            }
        }

        /// <summary>
        /// 批量插入实体(速度快)
        /// </summary>
        /// <param name="listEntity">实体集合</param>
        /// <returns>影响行数</returns>
        public async Task<int> Add(List<TEntity> listEntity)
        {
            foreach (var item in listEntity)
            {
                SetCreatedBy(item);
            }
            return await _db.Insertable(listEntity.ToArray()).ExecuteCommandAsync();
        }

        #endregion 新增

        #region 编辑

        /// <summary>
        /// 更新实体数据
        /// </summary>
        /// <param name="entity">博文实体类</param>
        /// <returns></returns>
        public async Task<bool> Update(TEntity entity)
        {
            var list = SetUpdateBy(entity);
            return await _db.Updateable(entity).ExecuteCommandHasChangeAsync();
        }


        /// <summary>
        /// 批量更新实体数据
        /// </summary>
        /// <param name="listEntity"></param>
        /// <returns></returns>
        public async Task<bool> Update(List<TEntity> listEntity)
        {
            foreach (var item in listEntity)
            {
                SetCreatedBy(item);
            }
            return await _db.Updateable(listEntity.ToArray()).ExecuteCommandHasChangeAsync();
        }



        public async Task<bool> Update(TEntity entity, string strWhere)
        {
            var list = SetUpdateBy(entity);
            return await _db.Updateable(entity).Where(strWhere).ExecuteCommandHasChangeAsync();
        }

        public async Task<bool> Update(string strSql, SugarParameter[] parameters = null)
        {
            return await _db.Ado.ExecuteCommandAsync(strSql, parameters) > 0;
        }

        public async Task<bool> Update(object operateAnonymousObjects)
        {
            return await _db.Updateable<TEntity>(operateAnonymousObjects).ExecuteCommandAsync() > 0;
        }

        public async Task<bool> Update(
          TEntity entity,
          List<string> lstColumns = null,
          List<string> lstIgnoreColumns = null,
          string strWhere = ""
            )
        {
            IUpdateable<TEntity> up = _db.Updateable(entity);
            if (lstIgnoreColumns != null && lstIgnoreColumns.Count > 0)
            {
                up = up.IgnoreColumns(lstIgnoreColumns.ToArray());
            }
            var list = SetUpdateBy(entity);
            if (list.Count > 0)
            {
                if (lstColumns == null)
                {
                    lstColumns = list;
                }
                else
                {
                    lstColumns.AddRange(list);
                }
            }

            if (lstColumns != null && lstColumns.Count > 0)
            {
                up = up.UpdateColumns(lstColumns.ToArray());
            }
            if (!string.IsNullOrEmpty(strWhere))
            {
                up = up.Where(strWhere);
            }

            return await up.ExecuteCommandHasChangeAsync();
        }

        #endregion 编辑

        #region 删除

        /// <summary>
        /// 根据实体删除一条数据
        /// </summary>
        /// <param name="entity">博文实体类</param>
        /// <returns></returns>
        public async Task<bool> Delete(TEntity entity)
        {
            return await _db.Deleteable(entity).ExecuteCommandHasChangeAsync();
        }

        /// <summary>
        /// 删除指定ID的数据
        /// </summary>
        /// <param name="id">主键ID</param>
        /// <returns></returns>
        public async Task<bool> DeleteById(dynamic id)
        {
            return await _db.Deleteable<TEntity>(id).ExecuteCommandHasChangeAsync();
        }

        /// <summary>
        /// 删除指定ID集合的数据(批量删除)
        /// </summary>
        /// <param name="ids">主键ID集合</param>
        /// <returns></returns>
        public async Task<bool> DeleteByIds(dynamic[] ids)
        {
            return await _db.Deleteable<TEntity>().In(ids).ExecuteCommandHasChangeAsync();
        }

        /// <summary>
        /// 根据条实体删除
        /// </summary>
        /// <param name="whereExpression"></param>
        /// <returns></returns>
        public async Task<bool> Delete(Expression<Func<TEntity, bool>> whereExpression)
        {
            return await _db.Deleteable<TEntity>(whereExpression).ExecuteCommandHasChangeAsync();
        }

        /// <summary>
        /// 软删除
        /// </summary>
        /// <param name="id"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        public async Task<bool> SoftDeleteById(dynamic id, SYS_StatusEnum status = SYS_StatusEnum.Delete)
        {
            var entity = await _db.Queryable<TEntity>().Filter(null, isDisabledGobalFilter: true).In(id).SingleAsync();
            SetSoftDeleteBy(entity, status);
            return await _db.Updateable(entity).ExecuteCommandHasChangeAsync();
        }

        /// <summary>
        /// 软删除集合
        /// </summary>
        /// <param name="ids"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        public async Task<bool> SoftDeleteByIds(dynamic ids, SYS_StatusEnum status = SYS_StatusEnum.Delete)
        {
            bool bl = false;
            var entityList = await _db.Queryable<TEntity>().Filter(null, true).In(ids).ToListAsync();
            int i = 0;
            foreach (var item in entityList)
            {
                SetSoftDeleteBy(item, status);
                if (await _db.Updateable(item).ExecuteCommandHasChangeAsync())
                {
                    i++;
                };
            }
            //动态参数不能直接获取长度，需要判断其类型
            if (ids.GetType() == typeof(List<Guid>))
            {
                List<Guid> _l = new List<Guid>(ids);
                bl = i == _l.Count;
            }
            return bl;
        }

        /// <summary>
        /// 软删除
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public async Task<bool> SoftDelete(TEntity entity)
        {
            SetSoftDeleteBy(entity);
            return await _db.Updateable(entity).ExecuteCommandHasChangeAsync();
        }

        #endregion 删除

        /// <summary>
        /// 赋值创建人
        /// </summary>
        /// <param name="entity"></param>
        private void SetCreatedBy(TEntity entity)
        {
            Type pp = typeof(TEntity);
            foreach (PropertyInfo pro in pp.GetProperties())
            {
                if (pro.Name.Equals("CreateUserId") || pro.Name.Equals("LastUpUserId"))
                {
                    var createUserId = (Guid?)pro.GetValue(entity);
                    if (createUserId == null || createUserId == Guid.Empty)
                    {
                        pro.SetValue(entity, this._loginInfo.UserId);
                    }
                }
                if (pro.Name.Equals("CreateUser") || pro.Name.Equals("LastUpUser"))
                {
                    var createUser = (string)pro.GetValue(entity);
                    if (string.IsNullOrEmpty(createUser))
                    {
                        pro.SetValue(entity, this._loginInfo.RealName);
                    }
                }
            }
        }

        private List<string> SetUpdateBy(TEntity entity)
        {
            List<string> list = new List<string>() { };
            if (this._loginInfo != null)
            {
                Type pp = typeof(TEntity);
                foreach (PropertyInfo pro in pp.GetProperties())
                {
                    if (pro.Name.Equals("LastUpTime"))
                    {
                        pro.SetValue(entity, DateTime.Now);
                        list.Add("LastUpTime");
                    }
                    if (pro.Name.Equals("LastUpUserId"))
                    {
                        pro.SetValue(entity, this._loginInfo.UserId);
                        list.Add("LastUpUserId");
                    }
                    if (pro.Name.Equals("LastUpUser"))
                    {
                        pro.SetValue(entity, this._loginInfo.RealName);
                        list.Add("LastUpUser");
                    }
                }
            }
            return list;
        }

        private List<string> SetSoftDeleteBy(TEntity entity, SYS_StatusEnum status = SYS_StatusEnum.Delete)
        {
            List<string> list = new List<string>() { };
            if (this._loginInfo != null)
            {
                Type pp = typeof(TEntity);
                foreach (PropertyInfo pro in pp.GetProperties())
                {
                    if (pro.Name.Equals("Status"))
                    {
                        pro.SetValue(entity, (int)status);
                        list.Add("Status");
                    }
                    if (pro.Name.Equals("LastUpTime"))
                    {
                        pro.SetValue(entity, DateTime.Now);
                        list.Add("LastUpTime");
                    }
                    if (pro.Name.Equals("LastUpUserId"))
                    {
                        pro.SetValue(entity, this._loginInfo.UserId);
                        list.Add("LastUpUserId");
                    }
                    if (pro.Name.Equals("LastUpUser"))
                    {
                        pro.SetValue(entity, this._loginInfo.RealName);
                        list.Add("LastUpUser");
                    }
                }
            }
            return list;
        }

        /// <summary>
        /// 检查名称
        /// </summary>
        /// <param name="whereExpression"></param>
        /// <param name="PrimaryKey"></param>
        /// <returns></returns>
        public async Task<int> CheckName(Expression<Func<TEntity, bool>> whereExpression)
        {
            return await _db.Queryable<TEntity>().Where(whereExpression).CountAsync();
        }
    }
}