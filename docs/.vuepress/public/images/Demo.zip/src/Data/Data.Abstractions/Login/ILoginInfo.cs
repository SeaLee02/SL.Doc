﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Abstractions.Login
{
    public interface ILoginInfo
    {
        /// <summary>
        /// 用户Id
        /// </summary>
        public Guid UserId { get; }

        /// <summary>
        /// 用户名称
        /// </summary>
        public string RealName { get; }

        /// <summary>
        /// 所属公司
        /// </summary>
        public string CompanyId { get;}

        /// <summary>
        /// 是否超级管理员
        /// </summary>
        public bool IsSuperManager { get; }
    }
}
