﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Utils.Core.Helper;
using Utils.Core.Inject;
using Utils.Core.Options;

namespace Module.AspNetCore
{
    public static class ServiceCollectionExtensions
    {
        /// <summary>
        /// 添加模块
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        public static IServiceCollection AddModules(this IServiceCollection services, IHostEnvironment env)
        {
            //依赖注入
            var assemblies = AssemblyHelper.Load(m => m.Name.EndsWith(".Core"));
            foreach (var item in assemblies)
            {
                var serivce = item.GetTypes();
                var iservice = serivce.Where(t => t.FullName != null && t.IsInterface && typeof(IAutoInject).IsAssignableFrom(t));
                foreach (var serviceType in iservice)
                {
                    var implementationType = serivce.FirstOrDefault(m => m != serviceType && serviceType.IsAssignableFrom(m));
                    if (implementationType != null)
                    {
                        services.Add(new ServiceDescriptor(serviceType, implementationType, ServiceLifetime.Scoped));
                    }
                }
            }

            //注册模块信息
            var initializerType = AssemblyHelper.LoadByNameEndString(AssemblyHelper.GetMainAssemblyName()).GetTypes().FirstOrDefault(t => typeof(IModuleInitializer).IsAssignableFrom(t));
            if (initializerType != null)
            {
                services.AddSingleton(typeof(IModuleInitializer), initializerType);

                MethodInfo method = initializerType.GetMethod("ConfigureServices");
                object aPerson = Activator.CreateInstance(initializerType);
                method.Invoke(aPerson, new object[] { services, env });
            }
            return services;
        }
    }
}
