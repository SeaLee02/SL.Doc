﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utils.Core.Inject;

namespace Module.AspNetCore
{
    public static class ApplicationBuilderExtensions
    {
        public static IApplicationBuilder UseModules(this IApplicationBuilder app, IHostEnvironment env)
        {
            //解析服务,需要在服务里面进行注册,这里才能解析
            var module = app.ApplicationServices.GetService<IModuleInitializer>();
            module.Configure(app, env);

            return app;
        }
    }
}
