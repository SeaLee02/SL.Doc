﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Utils.Core.Helper
{
    public static class RegularHelper
    {
        /// <summary>
        /// 是否包含数字
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public static bool IsDigital(string name)
        {
            string regularExpression = @"(\d+)$";
            Regex rg = new Regex(regularExpression);
            if (rg.IsMatch(name))
            {
                return true;
            }
            return false;
        }


        public static (bool isMatch, string name, int num) GetMatch(string GroupName)
        {
            bool isMatch = false;
            string name = "";
            int num = -1;
            Regex regex = new Regex(@"(\d+)$", RegexOptions.Compiled | RegexOptions.CultureInvariant);
            Match match = regex.Match(GroupName);
            if (match.Success)
            {
                isMatch = true;

                int.TryParse(match.Groups[1].Value, out num);
                name = GroupName.Substring(0, GroupName.Length - match.Length);
            }
            return (isMatch, name, num);

        }
    }
}
