﻿using ICSharpCode.SharpZipLib.Zip;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utils.Core.Helper.Model;

namespace Utils.Core.Helper
{
    /// <summary>
    /// 文件帮助类
    /// </summary>
    public static class FileFactory
    {


        /// <summary>
        /// 生成缩略图
        /// </summary>
        /// <param name="srcImageStream">原始图片的字节数组</param>
        /// <param name="width">最终的图片宽度</param>
        /// <param name="height">最终的图片高度</param>
        /// <returns>压缩后的base64字符串</returns>
        public static string CutImage(string srcImage, int width, int height)
        {

            string[] data = srcImage.Split(',');//data:image/png;base64,
            byte[] bytes = Convert.FromBase64String(data[1]);
            MemoryStream msSource = new MemoryStream(bytes);
            Bitmap btImage = new Bitmap(msSource);
            msSource.Close();
            Image serverImage = btImage;
            //画板大小
            int finalWidth = width, finalHeight = height;
            int srcImageWidth = serverImage.Width;
            int srcImageHeight = serverImage.Height;
            if (srcImageWidth > srcImageHeight)
            {
                finalHeight = srcImageHeight * width / srcImageWidth;
            }
            else
            {
                finalWidth = srcImageWidth * height / srcImageHeight;
            }
            //新建一个bmp图片
            Image newImage = new Bitmap(width, height);
            //新建一个画板
            Graphics g = Graphics.FromImage(newImage);
            //设置高质量插值法
            g.InterpolationMode = InterpolationMode.High;
            //设置高质量,低速度呈现平滑程度
            g.SmoothingMode = SmoothingMode.HighQuality;
            //清空画布并以透明背景色填充
            g.Clear(Color.White);
            //在指定位置并且按指定大小绘制原图片的指定部分
            g.DrawImage(serverImage, new Rectangle((width - finalWidth) / 2, (height - finalHeight) / 2, finalWidth, finalHeight), 0, 0, srcImageWidth, srcImageHeight, GraphicsUnit.Pixel);
            //以jpg格式保存缩略图
            MemoryStream msSaveImage = new MemoryStream();
            newImage.Save(msSaveImage, ImageFormat.Jpeg);
            serverImage.Dispose();
            newImage.Dispose();
            g.Dispose();
            byte[] imageBytes = msSaveImage.ToArray();
            msSaveImage.Close();
            return Convert.ToBase64String(imageBytes);
        }

        //public static string FileCreate(string base64, string strDirPath, string fileName = "")
        //{
        //    string resultMessage = string.Empty;
        //    var files = Directory.GetCurrentDirectory();
        //    string date = DateTime.Now.ToString("yyyy-MM-dd");
        //    string TaskFilePath = string.Format(@"{0}/{1}/", files + strDirPath, date);

        //    string[] data = base64.Split(',');//data:image/png;base64,
        //    string ext = data[0].Split(';')[0];

        //    string strFileName = Guid.NewGuid().ToString();
        //    if (!fileName.IsNull())
        //    {
        //        strFileName = fileName;
        //    }
        //    string extName = ext.Substring(ext.LastIndexOf("/") + 1);
        //    strFileName += $".{extName}";
        //    byte[] bytes = Convert.FromBase64String(data[1]);
        //    //对图片进行压缩


        //    MemoryStream memStream = new MemoryStream(bytes);
        //    Image mImage = Image.FromStream(memStream);


        //    //带路径的完整文件名 
        //    // 创建文件夹
        //    if (!Directory.Exists(TaskFilePath)) Directory.CreateDirectory(TaskFilePath);

        //    // 完整路径
        //    string strFullFileName = string.Format(@"{0}/{1}", TaskFilePath, strFileName);


        //    #region 写入

        //    FileStream fs = new FileStream(strFullFileName, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite);

        //    try
        //    {

        //        BinaryWriter writer = new BinaryWriter(fs); // 写入对象

        //        long offset = fs.Length; // 字节偏移量

        //        writer.Seek((int)offset, SeekOrigin.Begin);

        //        writer.Write(bytes); // 读取传入的数据流,并写入buffer二进制数据中

        //        fs.Close();

        //        fs.Dispose();

        //    }
        //    catch (Exception ex)
        //    {

        //        resultMessage = ex.Message;

        //        return "";

        //    }
        //    finally
        //    {

        //        fs.Close();

        //        fs.Dispose();

        //    }

        //    #endregion

        //    return date + "/" + strFileName;
        //}

        /// <summary>
        /// 创建文件
        /// </summary>
        /// <param name="base64">图片</param>
        /// <param name="strDirPath">保存地址</param>
        /// <param name="fileName">文件主键</param>
        /// <param name="fileInfoDto"></param>
        public static void FileCreate(string base64, string strDirPath, Guid? fileName, out FileInfoDto fileInfoDto, string extFileName = "")
        {
            string resultMessage = string.Empty;
            var files = Directory.GetCurrentDirectory();
            string date = DateTime.Now.ToString("yyyy-MM-dd");
            string TaskFilePath = string.Format(@"{0}{1}", files + strDirPath, date);

            string[] data = base64.Split(',');//data:image/png;base64,
            string ext = data[0].Split(';')[0];
            string strFileName = Guid.NewGuid().ToString();
            if (!fileName.ToString().IsNull())
            {
                strFileName = fileName.ToString();
            }
            string extName = ext.Substring(ext.LastIndexOf("/") + 1);
            byte[] bytes = Convert.FromBase64String(data[1]);
            //对图片进行压缩
            //文件信息
            fileInfoDto = new FileInfoDto
            {
                FileId = Guid.Parse(strFileName),
                FileExtension = extName,
                FileName = $"{date}/{strFileName}.{extName}",
                FileUrl = TaskFilePath,
                FileSize = bytes.Length
            };

            MemoryStream memStream = new MemoryStream(bytes);
            Image mImage = Image.FromStream(memStream);


            //带路径的完整文件名 
            // 创建文件夹
            if (!Directory.Exists(TaskFilePath)) Directory.CreateDirectory(TaskFilePath);

            // 完整路径
            string strFullFileName = string.Format(@"{0}/{1}.{2}", TaskFilePath, strFileName, extName);


            #region 写入
            if (extFileName.NotNull())
            {
                string delFile = $"{TaskFilePath}/{strFileName}.{extFileName}";
                if (IsExistFile(delFile))
                {
                    DeleteFile(delFile);
                }
            }

            FileStream fs = new FileStream(strFullFileName, FileMode.CreateNew, FileAccess.ReadWrite, FileShare.ReadWrite);

            try
            {

                BinaryWriter writer = new BinaryWriter(fs); // 写入对象

                long offset = fs.Length; // 字节偏移量

                writer.Seek((int)offset, SeekOrigin.Begin);

                writer.Write(bytes); // 读取传入的数据流,并写入buffer二进制数据中

                fs.Close();

                fs.Dispose();
            }
            catch (Exception ex)
            {
                fileInfoDto = null;
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine(ex.Message);
                Console.ForegroundColor = ConsoleColor.White;
            }
            finally
            {
                fs.Close();
                fs.Dispose();
            }
            #endregion
        }

        public static string GetFile(string Filename, string strDirPath)
        {
            string resultMessage = string.Empty;
            var files = Directory.GetCurrentDirectory();
            if (!File.Exists(files + strDirPath + Filename))
            {
                return "";
            }
            FileStream fsForRead = new FileStream(files + strDirPath + Filename, FileMode.Open, FileAccess.Read);//文件路径
            string base64Str = "";
            try
            {
                //读写指针移到距开头字节处
                byte[] bt = new byte[fsForRead.Length];
                //调用read读取方法
                fsForRead.Read(bt, 0, bt.Length);
                base64Str = Convert.ToBase64String(bt);

            }
            catch (Exception ex)
            {

                base64Str = ex.Message;

            }
            finally
            {
                fsForRead.Close();

            }
            return "data:image/jpg;base64," + base64Str;
        }

        public static bool IsExistFile(string filePath)
        {
            return File.Exists(filePath);
        }

        public static void DeleteFile(string filePath)
        {
            if (IsExistFile(filePath))
            {
                File.Delete(filePath);
            }
        }


        /// <summary>
        /// 获取文件二进制数组
        /// </summary>
        /// <param name="sData"></param>
        /// <returns></returns>
        public static Byte[] GetFile(Stream sData)
        {
            byte[] buffer = new byte[sData.Length];
            try
            {
                sData.Read(buffer, 0, buffer.Length);
            }
            catch (Exception ex)
            {
            }
            return buffer;
        }

        /// <summary>
        /// 文件夹 - 权限连接
        /// </summary>
        public static bool FolderConnection(string dirPath, string userName, string password, out string resultMessage)
        {


            #region 声明

            resultMessage = string.Empty;
            //return true;

            bool ret = true;
            string strCmd = string.Empty;
            string resultCmd = string.Empty;
            Process process = new Process();

            #endregion

            #region 获取 - 权限

            try
            {

                // 获取 - 用户列表
                process.Init();
                process.Start();
                strCmd = "net use";
                process.StandardInput.WriteLine(strCmd);
                process.StandardInput.WriteLine("exit");
                process.StandardInput.AutoFlush = true;
                resultCmd = process.StandardOutput.ReadToEnd();
                resultMessage = process.StandardError.ReadToEnd();
                if (!string.IsNullOrEmpty(resultMessage))
                {
                    resultMessage = string.Format("获取 - 用户列表 {0}", resultMessage);
                    ret = false;
                    return ret;
                }
                if (resultCmd.IndexOf(dirPath) >= 0)
                {
                    resultMessage = resultCmd;
                    return ret;
                }
                // 删除 - 现有列表
                process.Init();
                process.Start();
                strCmd = @"net use * /del /y";
                process.StandardInput.WriteLine(strCmd);
                process.StandardInput.WriteLine("exit");
                process.StandardInput.AutoFlush = true;
                resultMessage = process.StandardError.ReadToEnd();
                resultCmd = process.StandardOutput.ReadToEnd();
                if (!string.IsNullOrEmpty(resultMessage))
                {
                    resultMessage = string.Format("删除 - 用户列表 {0}", resultMessage);
                    ret = false;
                    return ret;
                }

                // 获取 - 用户权限
                process.Init();
                process.Start();
                strCmd = string.Format(@"net use {0} /User:{1} {2} /PERSISTENT:YES", dirPath, userName, password);
                process.StandardInput.WriteLine(strCmd);
                process.StandardInput.WriteLine("exit");
                process.StandardInput.AutoFlush = true;
                resultCmd = process.StandardOutput.ReadToEnd();
                resultMessage = process.StandardError.ReadToEnd();
                if (!string.IsNullOrEmpty(resultMessage))
                {
                    resultMessage = string.Format("删除1 - 用户列表 {0}", dirPath + resultMessage);
                    ret = false;
                    return ret;
                }

            }
            catch (System.Exception ex)
            {

                resultMessage = ex.Message;

            }
            finally
            {

                process.WaitForExit();

                process.Close();

                process.Dispose();

            }

            #endregion

            return ret;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="process"></param>
        private static void Init(this Process process)
        {

            if (process == null) process = new Process();
            process.StartInfo.FileName = "cmd.exe";
            process.StartInfo.UseShellExecute = false;
            process.StartInfo.RedirectStandardInput = true;
            process.StartInfo.RedirectStandardOutput = true;
            process.StartInfo.RedirectStandardError = true;
            process.StartInfo.CreateNoWindow = true;

        }

        /// <summary>
        /// 复制 - 文件
        /// </summary>
        /// <param name="beforeFullUrl">复制前 - 文件地址</param>
        /// <param name="afterFullUrl">复制后 - 文件地址</param>
        /// <param name="resultMessage">执行结果描述</param>
        /// <returns>复制 - 是否成功</returns>
        public static void FileCopyByCmd(string beforeFullUrl, string afterFullUrl)
        {

            #region 声明

            string strCmd = string.Empty;
            Process process = new Process();

            #endregion

            #region 执行 - cmd

            try
            {
                process.Init();
                process.Start();
                strCmd = string.Format(@"xcopy {0} {1} /y/s{2}", string.Format("\"{0}\"", beforeFullUrl), string.Format("\"{0}\"", afterFullUrl), "\nf");
                process.StandardInput.WriteLine(strCmd);
            }
            catch (Exception)
            {
            }
            finally
            {
                process.Close();
                process.Dispose();
            }

            #endregion

        }

        /// <summary>
        /// 复制 - 文件
        /// </summary>
        /// <param name="beforeFullUrl">复制前 - 文件地址</param>
        /// <param name="afterFullUrl">复制后 - 文件地址</param>
        /// <returns>复制 - 是否成功</returns>
        public static bool FileCopyByIO(string beforeFullUrl, string afterFullUrl, out string errorMessage)
        {
            #region 执行 - File.Copy
            try
            {
                errorMessage = "";

                if (!File.Exists(beforeFullUrl)) return true;

                if (!Directory.Exists(Path.GetDirectoryName(afterFullUrl)))
                    Directory.CreateDirectory(Path.GetDirectoryName(afterFullUrl));

                if (!File.Exists(afterFullUrl))
                    File.Copy(beforeFullUrl, afterFullUrl, true);
                if (!File.Exists(afterFullUrl))
                    return false;
                return true;

            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return false;

            }
            #endregion

        }

        //写入文件
        public static string CreateFileTXT(string filePath, string filename, string content)
        {
            try
            {
                if (!Directory.Exists(filePath))
                    Directory.CreateDirectory(filePath);

                //创建文件
                StreamWriter sw;
                if (!File.Exists(filePath + filename))
                {
                    sw = File.CreateText(filePath + filename);
                }
                else
                {
                    sw = File.AppendText(filePath + filename);
                }
                if (!string.IsNullOrEmpty(content))
                    sw.WriteLine(content);

                sw.Close();

                //生成文件路径
                return filePath;
            }
            catch (Exception ex)
            {
                return "";
            }
        }

        /// <summary>
        /// 保存文件
        /// </summary>
        public static bool FileCreate(string strFilePath, string strFileName, Stream sData, out string resultMessage, string strDirPath = null, string strUserName = null, string strPassword = null)
        {
            resultMessage = string.Empty;
            if (!string.IsNullOrEmpty(strDirPath) && !string.IsNullOrEmpty(strUserName) && !string.IsNullOrEmpty(strPassword) && !FolderConnection(strDirPath, strUserName, strPassword, out resultMessage))
            {
                return false;
            }
            //是否存在地址目录,不存在则创建
            if (!Directory.Exists(strFilePath))
            {
                Directory.CreateDirectory(strFilePath);
            }
            //带路径的完整文件名
            string strFullFileName = strFilePath + strFileName;
            FileStream fs = new FileStream(strFullFileName, FileMode.OpenOrCreate);
            try
            {
                //读取对象
                BinaryReader reader = new BinaryReader(sData);
                byte[] buffer;
                //写入对象
                BinaryWriter writer = new BinaryWriter(fs);
                //字节偏移量
                long offset = fs.Length;
                writer.Seek((int)offset, SeekOrigin.Begin);
                //读取传入的数据流,并写入buffer二进制数据中
                do
                {
                    buffer = reader.ReadBytes(1024);
                    writer.Write(buffer);
                } while (buffer.Length > 0);

                fs.Close();
            }
            catch (System.Exception ex)
            {
                resultMessage = ex.Message;
                return false;
            }
            finally
            {
                fs.Close();
            }
            resultMessage = strFullFileName;
            return true;
        }

        /// <summary>
        /// 保存文件Image
        /// </summary>
        public static bool FileCreate(string strFilePath, string strFileName, Image sData, out string resultMessage, string strDirPath = null, string strUserName = null, string strPassword = null)
        {
            resultMessage = string.Empty;
            if (!string.IsNullOrEmpty(strDirPath) && !string.IsNullOrEmpty(strUserName) && !string.IsNullOrEmpty(strPassword) && !FolderConnection(strDirPath, strUserName, strPassword, out resultMessage))
            {
                return false;
            }
            //是否存在地址目录,不存在则创建
            if (!Directory.Exists(strFilePath))
            {
                Directory.CreateDirectory(strFilePath);
            }
            //带路径的完整文件名
            string strFullFileName = strFilePath + @"\" + strFileName;
            try
            {
                sData.Save(strFullFileName);
            }
            catch (System.Exception ex)
            {
                resultMessage = ex.Message;
                return false;
            }
            finally
            {
                sData.Dispose();
            }
            resultMessage = strFullFileName;
            return true;
        }

        /// <summary>
        /// 保存文件
        /// </summary>
        /// <param name="filePath">文件路径</param>
        /// <param name="fileName">文件名称</param>
        /// <param name="buffer">文件流</param>
        /// <param name="resultMessage">返回描述</param>
        /// <param name="dirPath"></param>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public static bool FileCreate(string filePath, string fileName, byte[] buffer, out string resultMessage, string dirPath = null, string userName = null, string password = null)
        {

            #region 声明

            // 返回描述
            resultMessage = string.Empty;
            if (!string.IsNullOrEmpty(dirPath) && !string.IsNullOrEmpty(userName) && !string.IsNullOrEmpty(password) && !FolderConnection(dirPath, userName, password, out resultMessage))
            {
                return false;
            }

            // 创建文件夹
            if (!Directory.Exists(filePath)) Directory.CreateDirectory(filePath);

            // 完整路径
            string strFullFileName = string.Format(@"{0}\{1}", filePath, fileName);

            #endregion

            #region 写入

            FileStream fs = new FileStream(strFullFileName, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite);

            try
            {

                BinaryWriter writer = new BinaryWriter(fs); // 写入对象

                long offset = fs.Length; // 字节偏移量

                writer.Seek((int)offset, SeekOrigin.Begin);

                writer.Write(buffer); // 读取传入的数据流,并写入buffer二进制数据中

                fs.Close();

                fs.Dispose();

            }
            catch (System.Exception ex)
            {

                resultMessage = ex.Message;

                return false;

            }
            finally
            {

                fs.Close();

                fs.Dispose();

            }

            #endregion

            return true;

        }

        /// <summary>
        /// 删除文件
        /// </summary>
        public static bool FileDelete(string strFilePath, out string resultMessage)
        {
            try
            {
                var filespath = Directory.GetCurrentDirectory();
                resultMessage = string.Empty;
                if (string.IsNullOrEmpty(strFilePath))
                {
                    resultMessage = "文件路径不可空";
                    return false;
                }
                if (System.IO.File.Exists(filespath + strFilePath))
                {
                    System.IO.File.Delete(filespath + strFilePath);

                    string strDirPath = Path.GetDirectoryName(strFilePath);
                    DirectoryInfo TheFolder = new DirectoryInfo(strDirPath);
                    System.IO.FileInfo[] files = TheFolder.GetFiles();
                    if (files == null || files.Length == 0)
                        Directory.Delete(strDirPath);
                    return true;
                }
                return false;

            }
            catch (System.Exception e)
            {
                resultMessage = e.Message;
                return false;
            }
        }

        /// <summary>
        /// 读取文件
        /// </summary>
        public static byte[] FileRead(string strFilePath, string strFileName, out string resultMessage)
        {
            resultMessage = string.Empty;
            //判断要取的文件路径是否存在
            if (!Directory.Exists(strFilePath))
            {
                return null;
            }
            //带路径的完整文件名
            string strFullFileName = strFilePath + @"\" + strFileName;
            FileStream fs = new FileStream(strFullFileName, FileMode.Open, FileAccess.Read);
            try
            {
                int b1;
                System.IO.MemoryStream tempStream = new System.IO.MemoryStream();
                while ((b1 = fs.ReadByte()) != -1)
                {
                    tempStream.WriteByte(((byte)b1));
                }
                return tempStream.ToArray();
            }
            catch (System.Exception ex)
            {
                resultMessage = ex.Message;
                return null;
            }
            finally
            {
                fs.Close();
            }
        }

        /// <summary>
        /// 图片比对（比对图片是否完全相同,速度慢但匹配精准）
        /// </summary>
        public static bool ImageEqualsByFile(Bitmap exImage, Bitmap image)
        {
            bool flag = true;
            string exPixel;
            string Pixel;
            if (exImage.Width == image.Width && exImage.Height == image.Height)
            {
                for (int i = 0; i < exImage.Width; i++)
                {
                    for (int j = 0; j < exImage.Height; j++)
                    {
                        exPixel = exImage.GetPixel(i, j).ToString();
                        Pixel = image.GetPixel(i, j).ToString();
                        if (exImage != image)
                        {
                            flag = false; break;
                        }
                    }
                }
                if (flag == false)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 图片比对（比对图片是否完全相同,速度快但对大图片可能有些误差）
        /// </summary>
        public static bool ImageEqualsByStream(Bitmap exImage, Bitmap image)
        {
            MemoryStream ms = new MemoryStream();
            exImage.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
            String firstBitmap = Convert.ToBase64String(ms.ToArray());
            ms.Position = 0;
            image.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
            String secondBitmap = Convert.ToBase64String(ms.ToArray());
            if (firstBitmap.Equals(secondBitmap))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 图片比对（比对图片是否完全相同,速度快但对大图片可能有些误差）
        /// </summary>
        /// <param name="firstImage">第一个图片</param>
        /// <param name="secondImage">第二个图片</param>
        /// <returns>是否相同</returns>
        public static bool EqualsImage(this Bitmap firstImage, Bitmap secondImage)
        {
            MemoryStream ms = new MemoryStream();
            firstImage.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
            String firstBitmap = Convert.ToBase64String(ms.ToArray());
            ms.Position = 0;
            secondImage.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
            String secondBitmap = Convert.ToBase64String(ms.ToArray());
            if (firstBitmap.Equals(secondBitmap))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>   
        /// 解压功能(解压压缩文件到指定目录)   
        /// </summary>   
        /// <param name="fileToUnZip">待解压的文件</param>   
        /// <param name="zipedFolder">指定解压目标目录</param>   
        /// <param name="password">密码</param>   
        /// <returns>解压结果</returns>   
        public static bool UnZip(string fileToUnZip, string zipedFolder, string password)
        {
            bool result = true;
            FileStream fs = null;
            ZipInputStream zipStream = null;
            ZipEntry ent = null;
            string fileName;

            if (!File.Exists(fileToUnZip))
                return false;

            if (!Directory.Exists(zipedFolder))
                Directory.CreateDirectory(zipedFolder);

            try
            {
                zipStream = new ZipInputStream(File.OpenRead(fileToUnZip));
                if (!string.IsNullOrEmpty(password)) zipStream.Password = password;
                while ((ent = zipStream.GetNextEntry()) != null)
                {
                    if (!string.IsNullOrEmpty(ent.Name))
                    {
                        fileName = Path.Combine(zipedFolder, ent.Name);
                        fileName = fileName.Replace('/', '\\');//change by Mr.HopeGi   

                        if (fileName.EndsWith("\\"))
                        {
                            Directory.CreateDirectory(fileName);
                            continue;
                        }

                        fs = File.Create(fileName);
                        int size = 2048;
                        byte[] data = new byte[size];
                        while (true)
                        {
                            size = zipStream.Read(data, 0, data.Length);
                            if (size > 0)
                                fs.Write(data, 0, data.Length);
                            else
                                break;
                        }
                    }
                }
            }
            catch
            {
                result = false;
            }
            finally
            {
                if (fs != null)
                {
                    fs.Close();
                    fs.Dispose();
                }
                if (zipStream != null)
                {
                    zipStream.Close();
                    zipStream.Dispose();
                }
                if (ent != null)
                {
                    ent = null;
                }
                GC.Collect();
                GC.Collect(1);
            }
            return result;
        }

        /// <summary>   
        /// 解压功能(解压压缩文件到指定目录)   
        /// </summary>   
        /// <param name="fileToUnZip">待解压的文件</param>   
        /// <param name="zipedFolder">指定解压目标目录</param>   
        /// <returns>解压结果</returns>   
        public static bool UnZip(string fileToUnZip, string zipedFolder)
        {
            bool result = UnZip(fileToUnZip, zipedFolder, null);
            return result;
        }

        /// <summary>
        /// 将格式为rar的压缩文件解压到指定的目录
        /// </summary>
        /// <param name="rarFileName">要解压rar文件的路径</param>
        /// <param name="saveDir">解压后要保存到的目录</param>
        public static void DeCompressRar(string rarFileName, string saveDir)
        {
            //string regKey = @"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\WinRAR.exe";
            //RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(regKey);
            //string winrarPath = registryKey.GetValue("").ToString();
            //registryKey.Close();
            //string winrarDir = System.IO.Path.GetDirectoryName(winrarPath);
            //String commandOptions = string.Format("x {0} {1} -y", rarFileName, saveDir);

            //ProcessStartInfo processStartInfo = new ProcessStartInfo();
            //processStartInfo.FileName = System.IO.Path.Combine(winrarDir, "rar.exe");
            //processStartInfo.Arguments = commandOptions;
            //processStartInfo.WindowStyle = ProcessWindowStyle.Hidden;

            //Process process = new Process();
            //process.StartInfo = processStartInfo;
            //process.Start();
            //process.WaitForExit();
            //process.Close();
        }

        /// <summary>
        /// 将image转化为二进制 
        /// </summary>
        /// <param name="img"></param>
        /// <returns></returns>
        public static byte[] ConvertToByte(this Image img)
        {

            byte[] bt = null;

            if (!img.Equals(null))
            {

                using (MemoryStream mostream = new MemoryStream())
                {

                    Bitmap bmp = new Bitmap(img);

                    bmp.Save(mostream, System.Drawing.Imaging.ImageFormat.Jpeg);//将图像以指定的格式存入缓存内存流

                    bt = new byte[mostream.Length];

                    mostream.Position = 0;//设置留的初始位置

                    mostream.Read(bt, 0, Convert.ToInt32(bt.Length));

                }

            }

            return bt;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="bytes"></param>
        /// <returns></returns>
        public static Bitmap ConvertToBitmap(this byte[] bytes)
        {

            MemoryStream ms = new MemoryStream(bytes);

            return new Bitmap(ms);

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="bytes"></param>
        /// <returns></returns>
        public static Image ConvertToImage(this byte[] bytes)
        {

            MemoryStream ms = new MemoryStream(bytes);

            Image image = Image.FromStream(ms);

            return image;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="image"></param>
        /// <param name="remark"></param>
        /// <param name="saveUrl"></param>
        /// <param name="resultMessage"></param>
        /// <returns></returns>
        public static bool SetRemark(this Image image, string remark, string saveUrl, out string resultMessage)
        {
            try
            {

                resultMessage = "";
                MemoryStream ms = new MemoryStream();
                image.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                Image img = Image.FromStream(ms);
                System.Drawing.Imaging.PropertyItem item;
                if (img.PropertyItems.Count(q => q.Id.Equals(40092)) > 0)
                    item = img.PropertyItems.Where(q => q.Id.Equals(40092)).ToList()[0];
                else item = img.PropertyItems[0];
                item.Id = 40092;
                item.Type = 1;
                item.Value = System.Text.Encoding.Unicode.GetBytes(string.IsNullOrEmpty(remark) ? string.Empty : remark);
                item.Len = item.Value.Length;
                img.SetPropertyItem(item);
                image.Dispose();

                if (!Directory.Exists(Path.GetDirectoryName(saveUrl)))
                    Directory.CreateDirectory(Path.GetDirectoryName(saveUrl));

                img.Save(saveUrl);
                return true;
            }
            catch (Exception ex)
            {
                resultMessage = ex.ToString();
                return false;
            }

        }

        /// <summary>
        /// 获取图片备注信息
        /// </summary>
        /// <param name="image"></param>
        /// <returns></returns>
        public static string GetReark(this Image image)
        {
            string result = string.Empty;
            foreach (var item in image.PropertyItems)
            {
                if (item.Id == 40092)
                {
                    return result = System.Text.Encoding.Unicode.GetString(item.Value);
                }
            }
            image.Dispose();
            return result;
        }

        /// <summary>
        /// 去除表中的空行数据
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static DataTable removeEmpty(DataTable dt)
        {
            List<DataRow> removelist = new List<DataRow>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                bool rowdataisnull = true;
                for (int j = 3; j < dt.Columns.Count; j++)
                {
                    if (!string.IsNullOrEmpty(dt.Rows[i][j].ToString().Trim()))
                    {

                        rowdataisnull = false;
                    }
                }
                if (rowdataisnull)
                {
                    removelist.Add(dt.Rows[i]);
                }

            }
            for (int i = 0; i < removelist.Count; i++)
            {
                dt.Rows.Remove(removelist[i]);
            }
            return dt;
        }



        /// <summary>
        /// 保存文件
        /// </summary>
        /// <param name="formFile">上次文件</param>
        /// <param name="strDirPath">图片保存路径</param>
        /// <param name="fileName">文件名称,修改使用</param>
        /// <param name="fileInfoDto">返回文件信息</param>
        /// <param name="extFileName">扩展名称</param>
        /// <returns></returns>
        public static void FileCreate(IFormFile formFile, string strDirPath, Guid? fileName, out FileInfoDto fileInfoDto)
        {
            var files = Directory.GetCurrentDirectory();
            string date = DateTime.Now.ToString("yyyy-MM-dd");
            string TaskFilePath = string.Format(@"{0}{1}", files + strDirPath, date);

            string strFileName = Guid.NewGuid().ToString();
            if (fileName.ToString().NotNull())
            {
                strFileName = fileName.ToString();
            }
            var oldName = formFile.FileName.Substring(0,formFile.FileName.LastIndexOf('.'));
            var extName = formFile.FileName.Substring(formFile.FileName.LastIndexOf('.')+1);
          

            //对图片进行压缩
            //文件信息
            fileInfoDto = new FileInfoDto
            {
                FileId = Guid.Parse(strFileName),
                FileExtension = extName,
                FileName = $"{date}/{strFileName}.{extName}",
                FileUrl = TaskFilePath,
                FileSize = (int)formFile.Length,
                Remark = oldName
            };

            if (!Directory.Exists(TaskFilePath))
            {

                Directory.CreateDirectory(TaskFilePath);
            }
            // 完整路径
            string strFullFileName = string.Format(@"{0}/{1}.{2}", TaskFilePath, strFileName, extName);

            if (IsExistFile(strFullFileName))
            {
                DeleteFile(strFullFileName);
            }

            FileStream fs = new FileStream(strFullFileName, FileMode.CreateNew, FileAccess.ReadWrite, FileShare.ReadWrite);

            try
            {
                using MemoryStream stream = new MemoryStream();
                formFile.CopyTo(stream);

                BinaryWriter writer = new BinaryWriter(fs); // 写入对象

                long offset = fs.Length; // 字节偏移量

                writer.Seek((int)offset, SeekOrigin.Begin);

                writer.Write(stream.ToArray()); // 读取传入的数据流,并写入buffer二进制数据中
            }
            catch (System.Exception ex)
            {
                fileInfoDto = null;
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine(ex.Message);
                Console.ForegroundColor = ConsoleColor.White;
            }
            finally
            {
                fs.Close();
                fs.Dispose();
            }


        }

        public static MemoryStream FileRead(string strFilePath, string strFileName)
        {
            string resultMessage = string.Empty;
            var files = Directory.GetCurrentDirectory();
            if (!File.Exists(files + strFilePath + strFileName))
            {
                return null;
            }
            FileStream fs = new FileStream(files + strFilePath + strFileName, FileMode.Open, FileAccess.Read);//文件路径
            try
            {
                int b1;
                System.IO.MemoryStream tempStream = new System.IO.MemoryStream();
                while ((b1 = fs.ReadByte()) != -1)
                {
                    tempStream.WriteByte(((byte)b1));
                }
                return tempStream;
            }
            catch (System.Exception ex)
            {
                return null;
            }
            finally
            {
                fs.Close();
            }
        }
    }
}