﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utils.Core.Inject
{
    /// <summary>
    /// 注入解析
    /// </summary>
    public static class InjectCore
    {
        private static IServiceProvider serviceProvider { get; set; }

        /// <summary>
        /// 初始化注入
        /// </summary>
        /// <param name="services"></param>
        public static void SetServiceProvider(this IServiceCollection services)
        {
            serviceProvider = services.BuildServiceProvider();
        }

        /// <summary>
        /// 解析注入(有问题，暂时不用)
        /// </summary>
        /// <typeparam name="T">Service Type</typeparam>
        public static T Resolve<T>() where T : class
        {
            return serviceProvider.GetRequiredService<T>();
        }


    }
}
