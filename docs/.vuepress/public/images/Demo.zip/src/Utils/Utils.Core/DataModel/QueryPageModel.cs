﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Utils.Core.DataModel
{
    /// <summary>
    /// 查询Model
    /// </summary>
    public abstract class QueryPageModel
    {

        private string _orderByFileds = "LastUpTime desc";

        /// <summary>
        /// 第几页
        /// </summary>
        public int PageIndex { get; set; } = 1;

        /// <summary>
        /// 每次取多少数据
        /// </summary>
        public int PageSize { get; set; } = 10;

        /// <summary>
        /// 别名
        /// </summary>
        [JsonIgnore]
        public string MainTableAlias { get; set; } = "";

        /// <summary>
        /// 排序字段
        /// </summary>
        [JsonIgnore]
        public string OrderByFileds
        {
            get
            {
                return $"{MainTableAlias}{_orderByFileds}";
            }
            set
            {
                _orderByFileds = value;
            }
        }

        /// <summary>
        /// 组织
        /// </summary>
        public Guid? OrganizationId { get; set; }

    }
}
