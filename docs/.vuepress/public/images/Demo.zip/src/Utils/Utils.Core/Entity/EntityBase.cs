﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utils.Core
{
    /// <summary>
    /// 基类
    /// </summary>
    public class EntityBase
    {
        /// <summary>
        /// 状态
        /// </summary>
        public virtual SYS_StatusEnum Status { get; set; } = SYS_StatusEnum.Effective;

        /// <summary>
        /// 备注
        /// </summary>
        public virtual string Remark { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public virtual DateTime CreateTime { get; set; } = DateTime.Now;

        /// <summary>
        /// 创建用户ID
        /// </summary>
        public virtual Guid CreateUserId { get; set; }

        /// <summary>
        /// 创建用户名称
        /// </summary>
        public virtual string CreateUser { get; set; }

        /// <summary>
        /// 更新时间
        /// </summary>
        public virtual DateTime LastUpTime { get; set; } = DateTime.Now;

        /// <summary>
        /// 更新用户Id
        /// </summary>
        public virtual Guid LastUpUserId { get; set; }

        /// <summary>
        /// 更新用户名称
        /// </summary>
        public virtual string LastUpUser { get; set; }
    }
}
