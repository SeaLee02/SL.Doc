﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utils.Core.Extensions
{
    public class DateTimeExtensions
    {
        /// <summary>
        /// 计算两个时间之间的月份集合
        /// </summary>
        /// <param name="stime"></param>
        /// <param name="etime"></param>
        /// <returns></returns>
        public static List<string> GetMonthDiff(DateTime stime, DateTime etime)
        {
            List<string> list = new List<string>();
            int i = 0;
            while ( (stime.AddMonths(i).Year == etime.Year && stime.AddMonths(i).Month <= etime.Month)|| stime.AddMonths(i).Year < etime.Year)
            {
                list.Add(stime.AddMonths(i).ToString("yyyy-MM"));
                i++;
            }
            return list;
        }

        /// <summary>
        /// 计算两个时间之间的周集合
        /// </summary>
        /// <param name="stime"></param>
        /// <param name="etime"></param>
        /// <returns></returns>
        public static List<List<DateTime>> GetWeekDiff(DateTime stime, DateTime etime)
        {
            List<List<DateTime>> datename = new List<List<DateTime>>();
            int i = 0;
            while (stime.AddDays(i) <= etime)
            {
                DateTime dt = stime.AddDays(i);
                DayOfWeek week = stime.AddDays(i).DayOfWeek;
                if (i == 0)
                {
                    if (week == DayOfWeek.Sunday)
                    {
                        datename.Add(new List<DateTime> { dt, dt});
                        i++;
                    }
                    else
                    {
                        int day = 7 - (int)week;
                        if (stime.AddDays(day) <= etime)
                        {
                            datename.Add(new List<DateTime> { dt, stime.AddDays(day) });
                        }
                        else
                        {
                            datename.Add(new List<DateTime> { dt, etime });
                        }
                        i += day + 1;
                    }
                }
                else
                {
                    List<DateTime> vs = new List<DateTime>() { stime.AddDays(i) };
                    if (dt.AddDays(7) <= etime)
                    {
                        vs.Add(dt.AddDays(6));
                    }
                    else
                    {
                        vs.Add(etime);
                    }
                    datename.Add(vs);
                    i += 7;
                }
            }
            return datename;
        }


        /// <summary>
        /// 计算两个时间之间的日集合
        /// </summary>
        /// <param name="stime"></param>
        /// <param name="etime"></param>
        /// <returns></returns>
        public static List<string> GetDayDiff(DateTime stime, DateTime etime)
        {
            List<string> list = new List<string>();
            int i = 0;
            while (stime.AddDays(i) <= etime)
            {
                list.Add(stime.AddDays(i).ToString("yyyy-MM-dd"));
                i++;
            }
            return list;
        }
    }
}
