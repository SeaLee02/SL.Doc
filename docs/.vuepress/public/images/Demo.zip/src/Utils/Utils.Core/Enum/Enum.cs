﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utils.Core
{

    /// <summary>
    /// 数据状态  0删除/1禁用/2有效
    /// </summary>
    public enum SYS_StatusEnum
    {
        /// <summary>
        /// 删除
        /// </summary>
        Delete = 0,
        /// <summary>
        /// 禁用
        /// </summary>
        Disable = 1,
        /// <summary>
        /// 有效
        /// </summary>
        Effective = 2,

        /// <summary>
        /// 包含1和2
        /// </summary>
        All = 3
    }

    /// <summary>
    /// 树形参数
    /// </summary>
    public enum SYS_TreeEnum
    {
        公司 = 1,
        部门 = 2,
        权限配置 = 3
    }

    /// <summary>
    /// 所属系统|10-SaaS-Public|11-SaaS-HR|12-SaaS-CRM
    /// </summary>
    public enum SYS_ManageSysEnum
    {
        SaaS = 0,

        SaaSPublic = 10,

        /// <summary>
        /// 人事系统
        /// </summary>
        SaaSHR = 11,

        /// <summary>
        /// 客户系统
        /// </summary>
        SaaSCRM = 12,

        /// <summary>
        /// 流程平台
        /// </summary>
        SaaSWORK = 13,

        /// <summary>
        /// 运营平台
        /// </summary>
        SaaSOMS = 14,

        /// <summary>
        /// 控制台
        /// </summary>
        SaaSCONTROL = 15

    }

    /// <summary>
    /// 社保类型
    /// </summary>
    public enum SYS_SocialSecurityEnum
    {
        继续在本地购买 = 111901,
        转入调入地购买 = 111902,
        其他 = 111903
    }


    /// <summary>
    /// 权限模块类型|100301-模块|100302-菜单|100303-按钮|100304-接口
    /// </summary>
    public enum SYS_PermissionTypeEnum
    {
        模块 = 100301,

        菜单 = 100302,

        按钮 = 100303,

        接口 = 100304

    }

    /// <summary>
    /// 组织架构类型|100101-总公司|100102-战略区域|100103-分公司|100104-子公司|100105-门店|100111-职能中心|100112-部门
    /// </summary>
    public enum SYS_OrganizationTypeEnum
    {
        总公司 = 100101,

        战略区域 = 100102,

        分公司 = 100103,

        子公司 = 100104,

        门店 = 100105,

        职能中心 = 100111,

        部门 = 100112

    }

    /// <summary>
    /// 生成类型|0-自定义|1-自动
    /// </summary>
    public enum SYS_GenerateEnum
    {

        自定义 = 0,

        自动生成 = 1

    }

    /// <summary>
    /// 文件类型|100701-Logo|100702-头像|100703-合同|100711-证书|100712-简历
    /// </summary>
    public enum SYS_FileTypeEnum
    {
        Logo = 100701,

        头像 = 100702,

        合同 = 100703,

        证书 = 100711,

        简历 = 100712,

        员工入职相关 = 100713,

        员工其他 = 100714,

        机构Logo = 100715,

        机构证件 = 100716,

        员工转正 = 100717,

        员工离职 = 100718,

        员工转正审批 = 100719,

        员工离职审批 = 100720,

        员工预转正审批 = 100721,

    }


    /// <summary>
    /// 性别|110101-男|110102-女
    /// </summary>
    public enum SYS_EmployeeSexEnum
    {
        [Description("未知")]
        UnKnown = 0,
        [Description("先生")]
        男 = 110101,
        [Description("女士")]
        女 = 110102

    }

    /// <summary>
    /// 民族|110201-汉族|110202-蒙古族|110203-回族|110204-苗族|110205-维吾尔族|110206-彝族|110207-壮族|110208-布依族|110209-白族|110210-朝鲜族|110211-侗族|110212-哈尼族|110213-哈萨克族|110214-满族|110215-土家族|110216-瑶族|110217-达斡尔族|110218-东乡族|110219-高山族|110220-景颇族|110221-柯尔克孜族|110222-纳西族|110223-畲族|110224-拉祜族|110225-傣族|110226-黎族|110227-傈僳族|110228-仫佬族|110229-羌族|110230-水族|110231-土族|110232-佤族|110233-阿昌族|110234-布朗族|110235-毛南族|110236-普米族|110237-撒拉族|110238-塔吉克族|110239-锡伯族|110240-仡佬族|110241-保安族|110242-德昂族|110243-俄罗斯族|110244-鄂温克族|110245-京族|110246-怒族|110247-乌孜别克族|110248-裕固族|110249-独龙族|110250-鄂伦春族|110251-赫哲族|110252-基诺族|110253-珞巴族|110254-门巴族|110255-塔塔尔族|110256-藏族|110257-其他
    /// </summary>
    public enum SYS_NationEnum
    {
        汉族 = 110201,

        蒙古族 = 110202,

        回族 = 110203,

        苗族 = 110204,

        维吾尔族 = 110205,

        彝族 = 110206,

        壮族 = 110207,

        布依族 = 110208,

        白族 = 110209,

        朝鲜族 = 110210,

        侗族 = 110211,

        哈尼族 = 110212,

        哈萨克族 = 110213,

        满族 = 110214,

        土家族 = 110215,

        瑶族 = 110216,

        达斡尔族 = 110217,

        东乡族 = 110218,

        高山族 = 110219,

        景颇族 = 110220,

        柯尔克孜族 = 110221,

        纳西族 = 110222,

        畲族 = 110223,

        拉祜族 = 110224,

        傣族 = 110225,

        黎族 = 110226,

        傈僳族 = 110227,

        仫佬族 = 110228,

        羌族 = 110229,

        水族 = 110230,

        土族 = 110231,

        佤族 = 110232,

        阿昌族 = 110233,

        布朗族 = 110234,

        毛南族 = 110235,

        普米族 = 110236,

        撒拉族 = 110237,

        塔吉克族 = 110238,

        锡伯族 = 110239,

        仡佬族 = 110240,

        保安族 = 110241,

        德昂族 = 110242,

        俄罗斯族 = 110243,

        鄂温克族 = 110244,

        京族 = 110245,

        怒族 = 110246,

        乌孜别克族 = 110247,

        裕固族 = 110248,

        独龙族 = 110249,

        鄂伦春族 = 110250,

        赫哲族 = 110251,

        基诺族 = 110252,

        珞巴族 = 110253,

        门巴族 = 110254,

        塔塔尔族 = 110255,

        藏族 = 110256,

        其他 = 110257

    }

    /// <summary>
    /// 政治面貌|110301-共青团员|110302-中共党员|110303-预备党员|110304-其他民主党派|110305-群众
    /// </summary>
    public enum SYS_PoliticalStatusEnum
    {
        共青团员 = 110301,

        中共党员 = 110302,

        预备党员 = 110303,

        其他民主党派 = 110304,

        群众 = 110305

    }

    /// <summary>
    /// 婚姻状态|110401-未婚|110402-已婚|110403-离异|110404-丧偶
    /// </summary>
    public enum SYS_MaritalStatusIdEnum
    {
        未婚 = 110401,

        已婚 = 110402,

        离异 = 110403,

        丧偶 = 110404

    }

    /// <summary>
    /// 学历|110501-高中及以下|110502-大专|110503-本科|110504-硕士|110505-MBA/EMBA|110506-博士
    /// </summary>
    public enum SYS_EmployeeEducationEnum
    {
        [Description("UnKnown")]
        UnKnown = 0,
        [Description("高中以下")]
        高中以下 = 110501,
        [Description("大专")]
        大专 = 110502,
        [Description("本科")]
        本科 = 110503,
        [Description("硕士")]
        硕士 = 110504,
        [Description("MBAEMBA")]
        MBAEMBA = 110505,
        [Description("博士")]
        博士 = 110506,
        [Description("大专（自考）")]
        大专自考 = 110507,
        [Description("本科（自考）")]
        本科自考 = 110508,
        [Description("高中")]
        高中 = 110509,
        [Description("中专")]
        中专 = 110510
    }

    /// <summary>
    /// 员工状态|110601-在职|110602-离职
    /// </summary>
    public enum HR_EmployeeStatusEnum
    {
        在职 = 110601,

        离职 = 110602

    }

    /// <summary>
    /// 合同类型|111301-临时用工合同|111302-固定期限合同|111303-无固定期极限合同
    /// </summary>
    public enum HR_ContractTypeEnum
    {
        临时用工合同 = 111301,

        固定期限合同 = 111302,

        无固定期极限合同 = 111303

    }

    /// <summary>
    /// 员工关系|111201-全职|111202-兼职|111203-实习|111204-劳务派遣|111205-劳务外包|111206-返聘
    /// </summary>
    public enum HR_EmployeeRelationshipEnum
    {
        UnKnown = 0,
        全职 = 111201,

        兼职 = 111202,

        实习 = 111203,

        劳务派遣 = 111204,

        劳务外包 = 111205,

        返聘 = 111206

    }

    /// <summary>
    /// 人事变动类型|111101-预转正|111102-转正|111103-离职|111104-入职
    /// </summary>
    public enum HR_ChangeTypeEnum
    {
        UnKnown = 0,

        预转正 = 111101,

        转正 = 111102,

        离职 = 111103,

        入职 = 111104,

        晋升 = 111105,

        晋级 = 111106,
        降级 = 111107,
        借调 = 111108,
        外派 = 111109,
        转岗 = 111110,
        调动 = 111111,
        其他 = 111112

    }

    /// <summary>
    /// 人事变动状态|111001-待处理|111002-已通过|111003-未通过|111004-已撤销
    /// </summary>
    public enum HR_ChangeStatusEnum
    {
        UnKnown = 0,
        待处理 = 111001,

        已通过 = 111002,

        未通过 = 111003,

        已撤销 = 111004

    }

    /// <summary>
    /// 是否是自动生成|0-否|1-是
    /// </summary>
    public enum SYS_IsAotoEnum : byte
    {
        否 = 0,

        是 = 1

    }

    /// <summary>
    /// 人事变动类型|111101-预转正|111102-转正|111103-离职|111104-入职
    /// </summary>
    public enum HR_BecomeTypeEnum
    {
        预转正 = 111101,

        转正 = 111102,

        离职 = 111103,

        入职 = 111104

    }
    /// <summary>
    /// 是否校验|1-已校验|0-未校验|2全部
    /// </summary>
    public enum HR_CompanyVerifyEnum
    {
        [Description("未校验")]
        未校验 = 0,
        [Description("已校验")]
        已校验 = 1,
        [Description("全部")]
        全部 = 2

    }
    /// <summary>
    /// 是否启用流程|0-禁用|1-启用
    /// </summary>
    public enum SYS_IsProcessEnum
    {
        禁用 = 0,

        启用 = 1

    }

    /// <summary>
    /// 证书类型|110901-身份证|110902-税务师|110903-注册测绘师|110904-注册会计师|110905-房地产估价师|110906-土地估价师|110907-资产估价师
    /// </summary>
    public enum HR_CertificateTypeEnum
    {
        身份证 = 110901,

        税务师 = 110902,

        注册测绘师 = 110903,

        注册会计师 = 110904,

        房地产估价师 = 110905,

        土地估价师 = 110906,

        资产估价师 = 110907

    }

    /// <summary>
    /// 单位|1-年|2-月|3-天
    /// </summary>
    public enum HR_UnitEnum
    {
        年 = 1,

        月 = 2,

        天 = 3

    }

    /// <summary>
    /// 教育类型|110801-全日制教育|110802-培训教育
    /// </summary>
    public enum HR_EducationaTypeEnum
    {
        全日制教育 = 110801,

        培训教育 = 110802

    }

    /// <summary>
    /// 关系|110701-父母|110702-兄妹|110703-夫妻|110704-子女|110705-亲戚|110706-其他
    /// </summary>
    public enum HR_RelationshipEnum
    {
        父母 = 110701,

        兄妹 = 110702,

        夫妻 = 110703,

        子女 = 110704,

        亲戚 = 110705,

        其他 = 110706

    }


    /// <summary>
    /// 账号类型|100401-平台管理员|100402-平台用户|100403-平台OpenId|100404-租户管理员|100405-租户用户|100406-租户OpenId|100407-游客
    /// </summary>
    public enum SYS_UserTypeEnum
    {
        平台管理员 = 100401,

        平台用户 = 100402,

        平台OpenId = 100403,

        租户管理员 = 100404,

        租户用户 = 100405,

        租户OpenId = 100406,

        游客 = 100407

    }

    /// <summary>
    /// 是否实名|0-否|1-是
    /// </summary>
    public enum SYS_IsRealEnum
    {
        否 = 0,

        是 = 1

    }

    //编制人数|100201-1-50|100202-51-100|100203-101-200|100204-201-500|100205-501-1000|100206-1001及以上

    public enum SYS_StaffNumEnum
    {
        [Description("未知")]
        UnKnown = -1,
        [Description("1-50")]
        Level1 = 100201,
        [Description("51-100")]
        Level2 = 100202,
        [Description("101-200")]
        Level3 = 100203,
        [Description("201-500")]
        Level4 = 100204,
        [Description("501-1000")]
        Level5 = 100205,
        [Description("1001及以上")]
        Level6 = 100206
    }

    public enum FMIS_FinancialEnum
    {
        部门 = 1,

        人员 = 2,

        银行档案 = 3,

        银行类别 = 4
    }
    /// <summary>
    /// 财务系统银行类型
    /// </summary>
    public enum EBankTypeEnum
    {
        BankType = 1117
    }
    /// <summary>
    /// 财务系统成本代码
    /// </summary>
    public enum EFIMSCostEnum
    {
        CompanyCost = 1116,
        DepartmentCost = 1118
    }

    /// <summary>
    /// 队列类型|0-无效|1-AD_创建OU|2-AD_修改OU|3-AD_删除OU|4-AD_创建群组|5-AD_修改群组|6-AD_删除群组|7-AD_群组添加子群组|8-AD_群组添加用户|9-AD_群组移除用户|10-AD_群组移除子群组|11-AD_创建CN|12-AD_修改CN|13-AD_删除CN|14-AD_禁用CN|15-Exmail_创建组织|16-Exmail_修改组织|17-Exmail_删除组织|18-Exmail_创建群组|19-Exmail_修改群组|20-Exmail_删除群组|21-Exmail_创建用户|22-Exmail_修改用户|23-Exmail_删除用户
    /// </summary>
    public enum EPushQueueType
    {
        #region AD
        /// <summary>
        /// AD_添加公司/部门OU
        /// </summary>
        AD_CreateOU = 1,
        /// <summary>
        /// AD_修改公司/部门OU
        /// </summary>
        AD_UpdateOU = 2,
        /// <summary>
        /// AD_删除公司/部门OU
        /// </summary>
        AD_DeleteOU = 3,
        /// <summary>
        /// AD_添加公司/部门Group
        /// </summary>
        AD_CreateGroup = 4,
        /// <summary>
        /// AD_修改公司/部门Group
        /// </summary>
        AD_UpdateGroup = 5,
        /// <summary>
        /// AD_删除公司/部门Group
        /// </summary>
        AD_DeleteGroup = 6,
        /// <summary>
        /// AD_添加子Group到Group
        /// </summary>
        AD_MoveGroupToGroup = 7,
        /// <summary>
        /// AD_添加CN到Group
        /// </summary>
        AD_MoveUserToGroup = 8,
        /// <summary>
        /// AD_从Group里移除CN
        /// </summary>
        AD_RemoveUserToGroup = 9,
        /// <summary>
        /// AD_从Group里移除子Group
        /// </summary>
        AD_RemoveGroupToGroup = 10,
        /// <summary>
        /// AD_添加人员CN
        /// </summary>
        AD_CreateCN = 11,
        /// <summary>
        /// AD_修改人员CN
        /// </summary>
        AD_UpdateCN = 12,
        /// <summary>
        /// AD_删除人员CN
        /// </summary>
        AD_DeleteCN = 13,
        /// <summary>
        /// AD_启用/禁用人员CN
        /// </summary>
        AD_DisableCN = 14,
        /// <summary>
        /// AD_移动CN到OU
        /// </summary>
        AD_MoveUserToOU = 37,
        #endregion

        #region Exmail
        /// <summary>
        /// Exmail_添加公司/部门组织
        /// </summary>
        Exmail_CreateDepartment = 15,
        /// <summary>
        /// Exmail_修改公司/部门组织
        /// </summary>
        Exmail_UpdateDepartment = 16,
        /// <summary>
        /// Exmail_删公司/部门组织
        /// </summary>
        Exmail_DeleteDepartment = 17,
        /// <summary>
        /// Exmail_添加Group
        /// </summary>
        Exmail_CreateGroup = 18,
        /// <summary>
        /// Exmail_修改Group
        /// </summary>
        Exmail_UpdateGroup = 19,
        /// <summary>
        /// Exmail_删除Group
        /// </summary>
        Exmail_DeleteGroup = 20,
        /// <summary>
        /// Exmail_添加用户
        /// </summary>
        Exmail_CreateUser = 21,
        /// <summary>
        /// Exmail_修改用户
        /// </summary>
        Exmail_UpdateUser = 22,
        /// <summary>
        /// Exmail_删除用户
        /// </summary>
        Exmail_DeleteUser = 23,
        #endregion

        #region FMIS
        /// <summary>
        /// Exmail_添加公司/部门组织
        /// </summary>
        FMIS_CreateDepartment = 24,
        /// <summary>
        /// Exmail_修改公司/部门组织
        /// </summary>
        FMIS_UpdateDepartment = 25,
        /// <summary>
        /// Exmail_删公司/部门组织
        /// </summary>
        FMIS_DeleteDepartment = 26,
        /// <summary>
        /// Exmail_添加用户
        /// </summary>
        FMIS_CreateUser = 27,
        /// <summary>
        /// Exmail_修改用户
        /// </summary>
        FMIS_UpdateUser = 28,
        /// <summary>
        /// Exmail_删除用户
        /// </summary>
        FMIS_DeleteUser = 29,
        /// <summary>
        /// Exmail_添加银行类别
        /// </summary>
        FMIS_CreateBankType = 30,
        /// <summary>
        /// Exmail_修改银行类别
        /// </summary>
        FMIS_UpdateBankType = 31,
        /// <summary>
        /// Exmail_删除银行类别
        /// </summary>
        FMIS_DeleteBankType = 32,
        /// <summary>
        /// Exmail_添加银行档案
        /// </summary>
        FMIS_CreateBank = 33,
        /// <summary>
        /// Exmail_修改银行档案
        /// </summary>
        FMIS_UpdateBank = 34,
        /// <summary>
        /// Exmail_删除银行档案
        /// </summary>
        FMIS_DeleteBank = 35,
        /// <summary>
        /// Exmail_批量添加用户
        /// </summary>
        FMIS_BatchCreateUser = 36,
        #endregion

        Default = 0
    }


    #region CRM
    /// <summary>
    /// 机构类型|120101-国企|120102-央企|120103-政府|120104-法院|120105-保险|120106-证券|120107-开发商|120108-按揭|120109-资产管理|120110-评估公司|120111-个人|120112-国有银行|120113-股份银行|120114-外资银行|120115-城商银行|120116-金融租赁|120117-其他银行|120118-地产中介|120119-担保|120120-信托|120121-基金管理|120122-其他
    /// </summary>
    public enum CR_CompanyTypeEnum
    {
        [Description("未知")]
        UnKnown = -1,

        国企 = 120101,

        央企 = 120102,

        政府 = 120103,

        法院 = 120104,

        保险 = 120105,

        证券 = 120106,

        开发商 = 120107,

        按揭 = 120108,

        资产管理 = 120109,

        评估公司 = 120110,

        个人 = 120111,

        国有银行 = 120112,

        股份银行 = 120113,

        外资银行 = 120114,

        城商银行 = 120115,

        金融租赁 = 120116,

        其他银行 = 120117,

        地产中介 = 120118,

        担保 = 120119,

        信托 = 120120,

        基金管理 = 120121,

        其他 = 120122

    }



    /// <summary>
    /// 职务|120201-项目经理|120202-部门总监|120203-其他
    /// </summary>
    public enum CR_CustomerJobTypeEnum
    {
        [Description("未知")]
        UnKnown = -1,
        [Description("项目经理")]
        项目经理 = 120201,
        [Description("部门总监")]
        部门总监 = 120202,
        [Description("其他")]
        其他 = 120203

    }

    /// <summary>
    /// 客户等级|120301-S|120302-A|120303-B|120304-C|120305-其他|
    /// </summary>
    public enum CR_CustomerGradeEnum
    {
        [Description("未知")]
        UnKnown = -1,
        [Description("S")]
        S = 120301,
        [Description("A")]
        A = 120302,
        [Description("B")]
        B = 120303,
        [Description("C")]
        C = 120304,
        [Description("其他")]
        其他 = 120305
    }

    /// <summary>
    /// 拜访选项|120401-项目拜访|120402-事件拜访
    /// </summary>
    public enum CR_VisitOptionsEnum
    {
        [Description("未知")]
        UnKnown = -1,
        [Description("项目拜访")]
        项目拜访 = 120401,
        [Description("事件拜访")]
        事件拜访 = 120402

    }

    /// <summary>
    /// 拜访方式|120501-面谈|120502-微信或短信|120503-电话
    /// </summary>
    public enum CR_VisitWayEnum
    {
        [Description("面谈")]
        面谈 = 120501,
        [Description("微信或短信")]
        微信或短信 = 120502,
        [Description("电话")]
        电话 = 120503

    }

    /// <summary>
    /// 拜访目的|120601-项目跟踪|120602-余款催收|120603-其他
    /// </summary>
    public enum CR_VisitPurposeEnum
    {
        [Description("项目跟踪")]
        项目跟踪 = 12040101,
        [Description("余款催收")]
        余款催收 = 12040102,
        [Description("其他")]
        其他 = 12040103,
        [Description("合作洽谈")]
        合作洽谈 = 12040201,
        [Description("其他")]
        事件拜访其他 = 12040202

    }

    /// <summary>
    /// 角色判断
    /// </summary>
    public enum CR_RoleEnum
    {
        [Description("未知")]
        UnKnown = -1,
        [Description("员工,实习")]
        员工 = 0,
        [Description("项目经理，高级经理")]
        主管 = 1,
        [Description("核心层")]
        管理员 = 2,
        超级管理员 = 3
    }

    #endregion
}
