﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utils.Core.Query
{
    public abstract class QueryAbstract
    {
        /// <summary>
        /// 组织架构
        /// </summary>
       [Required]
        public Guid OrganizationId { get; set; }
    }
}
