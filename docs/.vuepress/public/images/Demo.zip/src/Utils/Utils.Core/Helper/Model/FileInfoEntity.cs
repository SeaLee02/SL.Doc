﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utils.Core.Helper.Model
{
	/// <summary>
	/// 文件Dto
	/// </summary>
    public class FileInfoDto
    {

		/// <summary>
		/// 主键
		/// </summary>
		public Guid FileId { get; set; }	


		/// <summary>
		/// 文件名称
		/// </summary>	
		public string FileName { get; set; }

		/// <summary>
		/// 文件地址
		/// </summary>	
		public string FileUrl { get; set; }

		/// <summary>
		/// 文件后缀
		/// </summary>	
		public string FileExtension { get; set; }


		/// <summary>
		/// 文件大小
		/// </summary>	
		public int FileSize { get; set; }

		/// <summary>
		/// 备注
		/// </summary>
        public string Remark { get; set; }
    }

	/// <summary>
	/// 图片显示
	/// </summary>
	public class FileView 
	{
		/// <summary>
		/// 主键
		/// </summary>
		public Guid? FileId { get; set; }

		/// <summary>
		/// 文件名称
		/// </summary>	
		public string FileName { get; set; }


		/// <summary>
		/// base64为图片信息
		/// </summary>	
		public string Base64Str { get; set; }

	}
}
