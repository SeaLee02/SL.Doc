﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utils.Core.Helper
{
    /// <summary>
    /// 流帮助类
    /// </summary>
    public class StreamHelper
    {
        /// <summary>
        /// 文件路径转byte[]
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public static async Task<byte[]> PathByByte(string path)
        {
            var fileStream = new FileStream(path, FileMode.Open, FileAccess.Read);
            var _byte = await StreamToBytes(fileStream);
            return _byte;
        }

        /// <summary>
        /// 把流转Byte[]
        /// </summary>
        /// <param name="stream"></param>
        /// <returns></returns>
        public static async Task<byte[]> StreamToBytes(Stream stream)
        {
            byte[] bytes = new byte[stream.Length];
            await stream.ReadAsync(bytes, 0, bytes.Length);
            // 设置当前流的位置为流的开始 
            stream.Seek(0, SeekOrigin.Begin);
            return bytes;
        }
    }
}
