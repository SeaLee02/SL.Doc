﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utils.Core.Helper
{
    /// <summary>
    /// 扩展名帮助类
    /// </summary>
    public class ExtHelper
    {
        /// <summary>
        /// 根据扩展名获取文件类型，只能在windows上面使用
        /// </summary>
        /// <param name="ext"></param>
        /// <returns></returns>
        public static string GetMimeType(string ext)
        {
            string mimeType = "application/unknown";
            RegistryKey regKey = Registry.ClassesRoot.OpenSubKey(ext);
            if (regKey != null && regKey.GetValue("Content Type") != null)
                mimeType = regKey.GetValue("Content Type").ToString();
            return mimeType;
        }

    }
}
