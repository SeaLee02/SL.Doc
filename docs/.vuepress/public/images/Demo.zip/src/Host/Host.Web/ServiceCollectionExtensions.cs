﻿using AspectCore.Extensions.DependencyInjection;
using Auth.AspectCore;
using Cache.AspNetCore;
using Config.Core.Configuration;
using Config.Core.RegisterFind;
using Data.AspNetCore;
using Host.Web.Filter;
using IdentityModel.AspNetCore.AccessTokenValidation;
using Mapper.AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using Module.AspNetCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utils.Core.Attributes;
using Utils.Core.Options;

namespace Host.Web
{
    public static class ServiceCollectionExtensions
    {

        public static IServiceCollection AddID4(this IServiceCollection services, IConfiguration cfg)
        {
            #region Token,ID4验证以及控制器模型验证
            //关闭自动验证
            services.Configure<ApiBehaviorOptions>(options =>
            {
                options.SuppressModelStateInvalidFilter = true;
            });
            //添加接口
            services.AddControllers(options =>
            {
                //模型验证
                options.Filters.Add<ModelActionFilte>();
            });

            // 接受identity server颁发的任何访问令牌
            services.AddAuthentication("token")
                //JWT tokens
                .AddJwtBearer("token", options =>
                {
                    options.Authority = cfg.GetSection("AuthorityURL").Value;
                    options.RequireHttpsMetadata = false;//不使用HTTPS

                    options.TokenValidationParameters.ValidTypes = new[] { "at+jwt" };
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        //是否验证受众
                        ValidateAudience = false
                    };
                });

            services.AddScopeTransformation();

            // 添加授权策略以确保令牌用于作用域“api1”
            services.AddAuthorization(options =>
            {
                options.AddPolicy("ApiScope", policy =>
                {
                    policy.RequireAuthenticatedUser();
                    policy.RequireClaim("scope", "InsideSystem");
                });
            });
            //允许跨域请求
            services.AddCors(options =>
            {
                options.AddPolicy("default", policy =>
                {
                    policy.AllowAnyOrigin() //允许任意的客户端跨域访问。
                        .AllowAnyHeader()
                        .AllowAnyMethod();
                });
            });
            #endregion
            return services;
        }


      

    }
}
