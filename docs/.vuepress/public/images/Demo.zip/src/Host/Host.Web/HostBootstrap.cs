﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utils.Core;
using Utils.Core.Options;
using Config.Core.RegisterFind;
using Auth.AspectCore;
using System.Reflection;
using Serilog.Sinks.MSSqlServer;
using Serilog.Events;
using System.Collections.ObjectModel;
using System.Data;

namespace Host.Web
{
    public class HostBootstrap
    {
        private readonly string[] _args;

        public HostBootstrap(string[] args)
        {
            _args = args;
        }

        /// <summary>
        /// 创建IHost
        /// </summary>
        /// <returns></returns>
        public void Run<TStartup>() where TStartup : StartupAbstract
        {
            Microsoft.Extensions.Hosting.Host.CreateDefaultBuilder(_args)
                 .AppConfiguration()
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    var options = LoadOptions();

                    //使用Serilog日志
                    webBuilder.UseSerilog((hostingContext, loggerConfiguration) =>
                    {
                        var dbCon = hostingContext.Configuration["HRSQLConnection"];
                        var _loggerConfiguration = loggerConfiguration
                            .ReadFrom
                            .Configuration(hostingContext.Configuration)
                            .Enrich
                            .FromLogContext();
                        
                        ////是否添加数据库
                        //if (!hostingContext.HostingEnvironment.EnvironmentName.Equals("Development"))
                        //{ }
                        //var columnOptions = new ColumnOptions();
                        //    //xml
                        //    columnOptions.Store.Remove(StandardColumn.Properties);
                        //    columnOptions.Store.Remove(StandardColumn.MessageTemplate);
                        //    //json格式
                        //    columnOptions.Store.Add(StandardColumn.LogEvent);

                        //    //添加自定义列
                        //    columnOptions.AdditionalColumns = new Collection<SqlColumn>{
                        //    new SqlColumn { DataType = SqlDbType.NVarChar, ColumnName = "IP" },
                        //    new SqlColumn { DataType = SqlDbType.NVarChar, ColumnName = "ActionName",PropertyName = "ActionName" },
                        //    new SqlColumn { DataType = SqlDbType.NVarChar, ColumnName = "RequestPath",PropertyName = "RequestPath" }
                        //  };


                        //    _loggerConfiguration.WriteTo.MSSqlServer(
                        //      connectionString: dbCon,
                        //       sinkOptions: new MSSqlServerSinkOptions { TableName = "Sys_Log", AutoCreateSqlTable = true },
                        //       restrictedToMinimumLevel: LogEventLevel.Error,
                        //       columnOptions: columnOptions
                        //      );
                      
                    });

                    //将宿主配置项注入容器
                    webBuilder.ConfigureServices(services =>
                    {
                        services.AddSingleton(options);
                    });

                    //绑定启动类
                    webBuilder.UseStartup<TStartup>();

                    //绑定URL
                    webBuilder.UseUrls(HostModel.Urls);

                }).AddAspCoreIoc()
                .Build()
                .Run();
        }

        /// <summary>
        /// 加载宿主配置项
        /// </summary>
        /// <returns></returns>
        private HostModel LoadOptions()
        {
            var configBuilder = new ConfigurationBuilder()
                .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
                .AddJsonFile("appsettings.json", false);

            var environmentVariable = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
            if (environmentVariable.NotNull())
            {
                configBuilder.AddJsonFile($"appsettings.{environmentVariable}.json", false);
            }

            var config = configBuilder.Build();

            var hostModel = new HostModel();
            config.GetSection("Host").Bind(hostModel);

            //Console.ForegroundColor = ConsoleColor.Blue;
            //Console.WriteLine($"CreateBuilder:Start:{HostModel.Urls}");
            //Console.ForegroundColor = ConsoleColor.White;

            if (HostModel.Urls.IsNull())
                HostModel.Urls = "http://*:5000";

            return hostModel;


        }
    }
}
