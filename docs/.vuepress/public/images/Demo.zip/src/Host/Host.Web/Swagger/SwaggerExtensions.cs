﻿using Host.Web.Swagger.Filters;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerUI;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utils.Core.Helper;
using Utils.Core.Options;

namespace Host.Web.Swagger
{
    public static class SwaggerExtensions
    {

        /// <summary>
        /// 添加Swagger
        /// </summary>
        /// <param name="services"></param>
        /// <param name="modules">模块集合</param>
        /// <returns></returns>
        public static IServiceCollection AddSwagger(this IServiceCollection services)
        {
            //读取配置
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = HostModel.Name, Version = $"v{HostModel.Version}" });


                // 为 Swagger 设置xml文档注释路径
                var xmlFile = $"{AssemblyHelper.LoadByNameEndString(AssemblyHelper.GetMainAssemblyName()).GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                c.IncludeXmlComments(xmlPath);

                var assemblies = AssemblyHelper.Load(m => m.Name.EndsWith(".Core"));
                foreach (var item in assemblies)
                {
                    var xmlPath2 = Path.Combine(AppContext.BaseDirectory, $"{item.GetName().Name}.xml");
                    if (File.Exists(xmlPath2))
                    {
                        c.IncludeXmlComments(xmlPath2);
                    }
                }


                //控制器注释,（方法,实体走XML）
                c.DocumentFilter<DescriptionDocumentFilter>();

                #region 启用swagger验证功能
                //添加一个必须的全局安全信息，和AddSecurityDefinition方法指定的方案名称一致即可，CoreAPI。
                c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    Description = "JWT授权(数据将在请求头中进行传输) 在下方输入Bearer {token} 即可，注意两者之间有空格",
                    Name = "Authorization",//jwt默认的参数名称
                    In = ParameterLocation.Header,//jwt默认存放Authorization信息的位置(请求头中)
                    Type = SecuritySchemeType.ApiKey
                });
                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                    {
                                {
                                    new OpenApiSecurityScheme
                                    {
                                        Reference = new OpenApiReference {
                                            Type = ReferenceType.SecurityScheme,
                                            Id = "Bearer"
                                        }
                                    },
                                    new string[] { }
                                }
                    });
                #endregion
            });

            return services;
        }


        /// <summary>
        /// 自定义Swagger
        /// </summary>
        /// <param name="app"></param>
        /// <param name="pathBase"></param>
        /// <returns></returns>
        public static IApplicationBuilder UseCustomSwagger(this IApplicationBuilder app)
        {

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", $"{HostModel.Name} API V1");
                //启用过滤
                c.EnableFilter();
                //是否展开
                c.DocExpansion(DocExpansion.None);
                //model删除
                c.DefaultModelsExpandDepth(-1);
            });
            return app;
        }

    }
}
