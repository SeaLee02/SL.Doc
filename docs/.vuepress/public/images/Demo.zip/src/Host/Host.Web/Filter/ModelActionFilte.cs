﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utils.Core;

namespace Host.Web.Filter
{
    /// <summary>
    /// 模型验证器
    /// </summary>
    public class ModelActionFilte : IActionFilter
    {

        public void OnActionExecuted(ActionExecutedContext context)
        {
        }

        public void OnActionExecuting(ActionExecutingContext context)
        {
            if (!context.ModelState.IsValid)
            {

                //获取验证失败的模型字段
                var errors = context.ModelState
                    .Where(e => e.Value.Errors.Count > 0)
                    .Select(e => new ErrorModel { Key = e.Key, Value = e.Value.Errors.First().ErrorMessage })
                    .ToList();
                string err = string.Empty;
                foreach (var item in errors)
                {
                    err += $"{item.Key}----{item.Value}";
                }
                var result = ResultModel.Failed(err);              
                context.Result = new JsonResult(result);

            }
        }
    }


    public class ErrorModel
    {
        public string Key { get; set; }

        public string Value { get; set; }
    }
}
