﻿using Auth.AspectCore;
using Config.Core.Configuration;
using Config.Core.Consts;
using Config.Core.RegisterFind;
using Host.Web.Middleware;
using Host.Web.Swagger;
using Mapper.AutoMapper;
using MediatR.Core;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Hosting;
using Module.AspNetCore;
using System;
using System.IO;
using System.Text;
using Utils.Core.Attributes;
using Utils.Core.Options;

namespace Host.Web
{
    public class StartupAbstract
    {
        private readonly IHostEnvironment _env;
        private readonly IConfiguration _cfg;

        public StartupAbstract(IHostEnvironment env, IConfiguration cfg)
        {
            _env = env;
            _cfg = cfg;
        }

        public virtual void ConfigureServices(IServiceCollection services)
        {
            //注册所有的自定义服务服务,属性注入
            services.AddModularServices();

            //管理全局配置文件
            services.AddSingleton(new Appsettings(_cfg));
            //初始化静态字段
            ConfigInit.Init();

            //上下文,获取当前等人信息使用,需要显示声明
            services.AddHttpContextAccessor();
            //注册Eureka
            if (!_env.IsDevelopment())
            {
                services.AddRegisterFind(_cfg);
            }

            //ID4配置
            services.AddID4(_cfg);

            //添加Swagger配置
            services.AddSwagger();

            //Dto2Entity 相互映射
            services.AddMappers();

            //注册服务，服务层,仓储层
            services.AddModules(_env);

            //添加AOP
            services.AddAop();

            //初始化解析服务(解析不统一,弃用)
            //services.SetServiceProvider();

            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            //监听配置更新
            services.CheckChangeToken(_cfg);

            //添加事件发布/订阅
            services.AddMediatRService();
        }

        public virtual void Configure(IApplicationBuilder app, IHostApplicationLifetime appLifetime)
        {
            //异常处理
            app.UseExceptionHandle();
            app.UseMiddleware<ResponseTimeMiddleware>();
            app.UseCustomSwagger();
            if (!_env.IsDevelopment())
            {
                app.DiscoveryClient();
            }

            //使用静态文件  得到 HRImageFile 文件
            // @"HRImageFile"
            string parentPath = Directory.GetCurrentDirectory();
            string fullName = parentPath + CustomConsts.PictureRootDirectoryPath;
            if (!Directory.Exists(fullName))
            {
                Directory.CreateDirectory(fullName);
            }
            app.UseFileServer(new FileServerOptions()
            {
                FileProvider = new PhysicalFileProvider(fullName), //静态文件指定到那个目录
                RequestPath = new PathString("/StaticFiles"), //请求的地址
                EnableDirectoryBrowsing = true //是否开启浏览器查看
            });

            string fileTemplate = parentPath + CustomConsts.FileTemplate;
            if (!Directory.Exists(fileTemplate))
            {
                Directory.CreateDirectory(fileTemplate);
            }
            app.UseFileServer(new FileServerOptions()
            {
                FileProvider = new PhysicalFileProvider(fileTemplate), //静态文件指定到那个目录
                RequestPath = new PathString("/FileTemplate"), //请求的地址
                EnableDirectoryBrowsing = true //是否开启浏览器查看
            });

            app.UseCors("default");//将跨域配置放入管道
            //路由
            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                 name: "default",
                 pattern: "{controller=Home}/{action=Index}/{id?}");

                endpoints.MapAreaControllerRoute(
                    name: "areas", "areas",
                    pattern: "api/{area:exists}/{controller=Home}/{action=Index}/{id?}");
            });
            app.UseModules(_env);


            appLifetime.ApplicationStarted.Register(() =>
            {
                //显示启动Banner
                //var options = app.ApplicationServices.GetService<HostModel>();
                ConsoleBanner();
            });
        }



        /// <summary>
        /// 启动后打印Banner图案
        /// </summary>
        private void ConsoleBanner()
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine();
            Console.WriteLine(@" ***************************************************************************************************************");
            Console.WriteLine(@" *                                                                                                             *");
            Console.WriteLine(@" *                                       $$$$$$\   $$$$$$\   $$$$$$\   $$$$$$\                                 *");
            Console.WriteLine(@" *                                      $$  __$$\ $$  __$$\ $$  __$$\ $$  __$$\                                *");
            Console.WriteLine(@" *                                      $$ /  \__|$$ /  $$ |$$ /  $$ |$$ /  \__|                               *");
            Console.WriteLine(@" *                                      \$$$$$$\  $$$$$$$$ |$$$$$$$$ |\$$$$$$\                                 *");
            Console.WriteLine(@" *                                       \____$$\ $$  __$$ |$$  __$$ | \____$$\                                *");
            Console.WriteLine(@" *                                      $$\   $$ |$$ |  $$ |$$ |  $$ |$$\   $$ |                               *");
            Console.WriteLine(@" *                                      \$$$$$$  |$$ |  $$ |$$ |  $$ |\$$$$$$  |                               *");
            Console.WriteLine(@" *                                       \______/ \__|  \__|\__|  \__| \______/                                *");
            Console.WriteLine(@" *                                                                                                             *");
            Console.WriteLine(@" *                                                                                                             *");
            Console.Write(@" *                                      ");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write(@$"启动成功，欢迎使用 SAAS平台-{HostModel.Name}~");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine(@"                             *");
            Console.WriteLine(@" *                                                                                                             *");
            Console.Write(@" *                                      ");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write(@"接口地址：" + HostModel.Urls);
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine(@"                                                *");
            Console.WriteLine(@" *                                                                                                             *");
            Console.WriteLine(@" ***************************************************************************************************************");
            Console.WriteLine();
        }
    }
}