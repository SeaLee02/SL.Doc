﻿using AutoMapper;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Linq;
using Utils.Core.Annotations;
using Utils.Core.DataModel;
using Utils.Core.Helper;

namespace Mapper.AutoMapper
{
    public static class ServiceCollectionExtensions
    {
        /// <summary>
        /// 添加对象映射
        /// </summary>
        /// <param name="services"></param>
        /// <param name="modules">模块集合</param>
        /// <returns></returns>
        public static IServiceCollection AddMappers(this IServiceCollection services)
        {
            var config = new MapperConfiguration(cfg =>
            {
                var assemblies = AssemblyHelper.Load(m => m.Name.EndsWith(".Core"));
                foreach (var item in assemblies)
                {
                    //走配置管理
                    var services = item.GetTypes().Where(t => typeof(IMapperConfig).IsAssignableFrom(t));
                    if (services != null)
                    {
                        foreach (var service in services)
                        {
                            ((IMapperConfig)Activator.CreateInstance(service)).Bind(cfg);
                        }
                    }
                    //走特性映射
                    var types = item.GetTypes();
                    foreach (var type in types)
                    {
                        var map = (ObjectMapAttribute)Attribute.GetCustomAttribute(type, typeof(ObjectMapAttribute));
                        if (map != null)
                        {
                            cfg.CreateMap(type, map.TargetType);

                            if (map.TwoWay)
                            {
                                cfg.CreateMap(map.TargetType, type);
                            }
                        }
                    }
                }
                //分页泛型自映射
                cfg.CreateMap(typeof(PageModel<>), typeof(PageModel<>));
            });
            //注入官方方法
            services.AddSingleton(config.CreateMapper());
            services.AddSingleton<Utils.Core.Map.IObjectMapper, DefaultMapper>();

            return services;
        }
    }
}