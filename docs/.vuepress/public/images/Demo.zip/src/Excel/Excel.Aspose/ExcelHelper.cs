﻿using Aspose.Cells;
using Excel.Aspose.Annotations;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Excel.Aspose
{
    /// <summary>
    /// 操作Excel
    /// </summary>
    public class ExcelHelper
    {
        /// <summary>
        /// 文件流转DataTable
        /// </summary>
        /// <param name="stram"></param>
        /// <returns></returns>
        public static DataTable Excel2Table(Stream stram, int index = 0)
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

            Workbook book = new Workbook(stram);
            Worksheet worksheet = book.Worksheets[index];
            Cells cells = worksheet.Cells;
            DataTable dataTable = cells.ExportDataTableAsString(0, 0, cells.MaxDataRow + 1, cells.MaxDataColumn + 1, true);
            return dataTable;
        }


        public static byte[] GetExcelForList<T>(List<T> entitys) where T : class
        {
            Workbook workbook = new Workbook(); //工作簿 
            Worksheet sheet = workbook.Worksheets[0];
            
            Cells cells = sheet.Cells;//单元格  
            Type tAtt= typeof(T);

            //标题
            var headTitle = (ImporterHeaderAttribute)Attribute.GetCustomAttribute(tAtt, typeof(ImporterHeaderAttribute));
            if (headTitle != null)
            {
                sheet.Name = headTitle.Name;
            }

            //头部信息
            Style styleHead = workbook.CreateStyle();//新增样式 
            styleHead.HorizontalAlignment = TextAlignmentType.Center;//文字居中 
            styleHead.VerticalAlignment = TextAlignmentType.Center;//文字居中 
            styleHead.Font.Name = "微软雅黑";//文字字体 
            styleHead.Font.Size = 12;//文字大小 
            styleHead.Font.Color = Color.White;
            styleHead.ForegroundColor = Color.CadetBlue;
            styleHead.Pattern = BackgroundType.Solid;
            PropertyInfo[] pro = tAtt.GetProperties(BindingFlags.Public | BindingFlags.Instance); // 获取当前type公共属性pp.GetProperties();
            int z = 0;
            foreach (PropertyInfo p in pro)
            {
                var head = (ImporterHeaderAttribute)p.GetCustomAttribute(typeof(ImporterHeaderAttribute));
                if (head!=null)
                {
                    cells[0, z].PutValue(head.Name);
                    cells[0, z].SetStyle(styleHead);
                    cells.SetColumnWidth(z, head.Name.Length*4);//设置列宽
                    cells.SetRowHeight(z, 24);//设置列宽
                }
                z++;
            }

            Style styleBody = workbook.CreateStyle();//新增样式 
            styleBody.HorizontalAlignment = TextAlignmentType.Center;//文字居中 
            styleBody.VerticalAlignment= TextAlignmentType.Center;//文字居中 
            styleBody.Font.Name = "微软雅黑";//文字字体 
            styleBody.Font.Size = 12;//文字大小 
            int y = 1;
            foreach (T t in entitys)
            {
                for (int j = 0; j < pro.Length; j++)
                {
                    var head = (ImporterHeaderAttribute)pro[j].GetCustomAttribute(typeof(ImporterHeaderAttribute));
                    if (head!=null)
                    {
                        object obj = pro[j].GetValue(t);
                        if (obj is byte)
                        {
                            if ((byte)obj == 0)
                            {
                                obj = "否";
                            }
                            else
                            {
                                obj = "是";
                            }
                        }
                        if (obj is decimal)
                        {
                            obj = ((decimal)obj).ToString("F");
                        }
                        if (obj is Enum && obj.ToString() == "None")
                        {
                            obj = string.Empty;
                        }
                        if (obj is DateTime)
                        {
                            obj = ((DateTime)obj).ToString("yyyy-MM-dd");
                        }
                        cells[y, j].PutValue(obj);
                        cells[y, j].SetStyle(styleBody);
                        cells.SetRowHeight(y, 24);//设置列宽
                    }                   
                }
                y++;
            }
            WorkbookDesigner designer = new WorkbookDesigner(workbook);
            var xlsStream = new MemoryStream();
            SaveFormat format = new SaveFormat();
            format = SaveFormat.Xlsx;
            designer.Workbook.Save(xlsStream, format);
            byte[] buff = xlsStream.ToArray();
            return buff;
        }





        //根据List<T> 返回流

        public static byte[] ExportExcel()
        {
            Workbook workbook = new Workbook(); //工作簿 
            Worksheet sheet = workbook.Worksheets[0]; //工作表 
            //workbook.Worksheets.Add("测试");



            //sheet.IsGridlinesVisible = false;//去掉初始单元线
            //Cells cells = sheet.Cells;//单元格 
            //                          //为标题设置样式     
            //                          //Style styleTitle = workbook.CreateStyle();//新增样式 
            //                          //styleTitle.HorizontalAlignment = TextAlignmentType.Center;//文字居中 
            //                          //styleTitle.Font.Name = "微软雅黑";//文字字体 
            //                          //styleTitle.Font.Size = 18;//文字大小 
            //                          //styleTitle.Font.IsBold = true;//粗体 
            //                          //样式1 标题下方的日期
            //                          //Style style1 = workbook.CreateStyle();//新增样式 
            //                          //style1.HorizontalAlignment = TextAlignmentType.Center;//文字居中 
            //                          //style1.Font.Name = "微软雅黑";//文字字体 
            //                          //style1.Font.Size = 12;//文字大小 
            //                          //样式2 列名
            //Style style2 = workbook.CreateStyle();//新增样式 
            //style2.HorizontalAlignment = TextAlignmentType.Center;//文字居中 
            //style2.Font.Name = "微软雅黑";//文字字体 
            //style2.Font.Size = 12;//文字大小 
            //style2.Font.IsBold = true;//粗体 
            ////style2.BackgroundColor = new System.Drawing.Color();
            //style2.Borders[BorderType.LeftBorder].LineStyle = CellBorderType.Thin;
            //style2.Borders[BorderType.RightBorder].LineStyle = CellBorderType.Thin;
            //style2.Borders[BorderType.TopBorder].LineStyle = CellBorderType.Thin;
            //style2.Borders[BorderType.BottomBorder].LineStyle = CellBorderType.Thin;
            ////样式3 数据的样式
            //Style style3 = workbook.CreateStyle();//新增样式 
            //style3.HorizontalAlignment = TextAlignmentType.Center;//文字居中 
            //style3.Font.Name = "微软雅黑";//文字字体 
            //style3.Font.Size = 10;//文字大小 
            //style3.Borders[BorderType.LeftBorder].LineStyle = CellBorderType.Thin;
            //style3.Borders[BorderType.RightBorder].LineStyle = CellBorderType.Thin;
            //style3.Borders[BorderType.TopBorder].LineStyle = CellBorderType.Thin;
            //style3.Borders[BorderType.BottomBorder].LineStyle = CellBorderType.Thin;


            //cells[0, 0].PutValue("机构全称");
            //cells[0, 0].SetStyle(style2);
            //cells.SetColumnWidth(0, 12);//设置列宽

            //cells[0, 1].PutValue("机构简称");
            //cells[0, 1].SetStyle(style2);
            //cells.SetColumnWidth(1, 12);//设置列宽


            //cells[0, 0].PutValue("英文名称");
            //cells[0, 0].SetStyle(style2);
            //cells.SetColumnWidth(2, 12);//设置列

            MemoryStream memoryStream = workbook.SaveToStream();
            return memoryStream.ToArray();


            //if (list.Count == 0) return;

            //var t = list.First().GetType();//获取列表的类的属性
            //var properties = t.GetProperties().Where(x => GetAttribute<IgnoreDataMemberAttribute>(x) == null);//筛选出需要导出的字段
            //var title = GetAttribute<DisplayNameAttribute>(t)?.DisplayName;
            //int Colnum = properties.Count();//表格列数 
            //int Rownum = list.Count;//表格行数 

            ////生成行1 标题行    
            //cells.Merge(0, 0, 1, Colnum);//合并单元格 
            //cells[0, 0].PutValue(title);//填写内容 
            //cells[0, 0].SetStyle(styleTitle);
            //cells.SetRowHeight(0, 38);//行高
            //                          //生成行2 日期    
            //cells.Merge(1, 0, 1, Colnum);//合并单元格 
            //cells[1, 0].PutValue(DateTime.Now.ToShortDateString());//填写内容 
            //cells[1, 0].SetStyle(style1);
            //cells.SetRowHeight(1, 20);//行高
            //                          //列名及数据行





            //int i = 0;
            //foreach (var item in properties)
            //{
            //    var colName = GetAttribute<DisplayNameAttribute>(item)?.DisplayName;//反射获取字段的DisplayName特性值
            //    cells[2, i].PutValue(colName);
            //    cells[2, i].SetStyle(style2);
            //    cells.SetColumnWidth(i, colName.Length * 3);//设置列宽
            //    int k = 0;
            //    foreach (var rowdata in list)
            //    {
            //        //反射遍历添加数据
            //        object value = item.GetValue(rowdata, null);
            //        string ss = value == null ? "" : value.ToString();
            //        cells[3 + k, i].PutValue(ss);
            //        cells[3 + k, i].SetStyle(style3);
            //        cells.SetRowHeight(3 + k, 18);//设置行高
            //        k++;
            //    }
            //    i++;
            //}
            //workbook.SaveToStream();

            //workbook.Save(path);//生成Excel


        }


        #region XSSFWorkbook 导出文件


        //public static byte[] GetExcelForList<T>(List<T> entitys, Dictionary<string, string> dicTitleCol) where T : class
        //{
        //    Dictionary<string, string> dicColTitle = new Dictionary<string, string>();
        //    foreach (KeyValuePair<string, string> keyValuePair in dicTitleCol)
        //    {
        //        dicColTitle.Add(keyValuePair.Value, keyValuePair.Key);
        //    }
        //    Func<string, string> getColumnName = delegate (string x)
        //    {
        //        if (dicColTitle.Keys.Any((string y) => y == x))
        //        {
        //            return dicColTitle[x];
        //        }
        //        return null;
        //    };
        //    return ExcelHelper.GetExcelForTable(ExcelHelper.ListToDataTable<T>(entitys, getColumnName));
        //}

        //public static byte[] GetExcelForList<T>(List<T> entitys, Func<string, string> getColumnName) where T : class
        //{
        //    return ExcelHelper.GetExcelForTable(ExcelHelper.ListToDataTable<T>(entitys, getColumnName));
        //}

        //public static byte[] GetExcelForTable(DataTable dt)
        //{
        //    XSSFWorkbook xssfworkbook = new XSSFWorkbook();
        //    ISheet sheet = xssfworkbook.CreateSheet("Sheet");
        //    IRow row = sheet.CreateRow(0);
        //    for (int i = 0; i < dt.Columns.Count; i++)
        //    {
        //        string columnName = dt.Columns[i].ColumnName;
        //        row.CreateCell(i).SetCellValue(columnName);
        //    }
        //    for (int j = 0; j < dt.Rows.Count; j++)
        //    {
        //        IRow row2 = sheet.CreateRow(j + 1);
        //        for (int k = 0; k < dt.Columns.Count; k++)
        //        {
        //            row2.CreateCell(k).SetCellValue(dt.Rows[j][k].ToString());
        //        }
        //    }
        //    MemoryStream memoryStream = new MemoryStream();
        //    xssfworkbook.Write(memoryStream);
        //    return memoryStream.ToArray();
        //}

        //private static DataTable ListToDataTable<T>(List<T> entitys, Func<string, string> getColumnName) where T : class
        //{
        //    DataTable dataTable = new DataTable();
        //    if (entitys == null || entitys.Count < 1)
        //    {
        //        return dataTable;
        //    }
        //    Dictionary<string, string> dictionary = new Dictionary<string, string>();
        //    PropertyInfo[] properties = entitys[0].GetType().GetProperties();
        //    for (int i = 0; i < properties.Length; i++)
        //    {
        //        string text = getColumnName(properties[i].Name);
        //        if (!string.IsNullOrEmpty(text) && !dictionary.ContainsValue(text))
        //        {
        //            dataTable.Columns.Add(text);
        //            dictionary.Add(properties[i].Name, text);
        //        }
        //    }
        //    foreach (T t in entitys)
        //    {
        //        DataRow dataRow = dataTable.NewRow();
        //        for (int j = 0; j < properties.Length; j++)
        //        {
        //            object obj = properties[j].GetValue(t);
        //            if (obj is byte)
        //            {
        //                if ((byte)obj == 0)
        //                {
        //                    obj = "否";
        //                }
        //                else
        //                {
        //                    obj = "是";
        //                }
        //            }
        //            if (obj is decimal)
        //            {
        //                obj = ((decimal)obj).ToString("F");
        //            }
        //            if (obj is Enum && obj.ToString() == "None")
        //            {
        //                obj = string.Empty;
        //            }
        //            foreach (string text2 in dictionary.Keys)
        //            {
        //                if (text2 == properties[j].Name)
        //                {
        //                    dataRow[dictionary[text2]] = obj;
        //                }
        //            }
        //        }
        //        dataTable.Rows.Add(dataRow);
        //    }
        //    return dataTable;
        //}

        #endregion
















    }
}
