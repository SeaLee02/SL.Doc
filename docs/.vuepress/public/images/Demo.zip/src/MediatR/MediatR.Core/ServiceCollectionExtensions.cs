﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Reflection;
using Utils.Core.Helper;

namespace MediatR.Core
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddMediatRService(this IServiceCollection services)
        {
            services.AddMediatR(AssemblyHelper.GetMainAssembly());
            return services;
        }
    }
}
